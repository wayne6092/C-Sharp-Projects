﻿namespace Barber_Shop
{
    partial class QueryThree
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label first_NameLabel;
            System.Windows.Forms.Label last_NameLabel;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label cityLabel;
            System.Windows.Forms.Label wholesale_PriceLabel;
            System.Windows.Forms.Label retail_PriceLabel;
            System.Windows.Forms.Label possible_ProfitLabel;
            System.Windows.Forms.Label first_NameLabel1;
            System.Windows.Forms.Label last_NameLabel1;
            System.Windows.Forms.Label phoneLabel1;
            System.Windows.Forms.Label cityLabel1;
            System.Windows.Forms.Label wholesale_PriceLabel1;
            System.Windows.Forms.Label retail_PriceLabel1;
            System.Windows.Forms.Label possible_ProfitLabel1;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(QueryThree));
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.barbershopDataSet = new Barber_Shop.barbershopDataSet();
            this.possibleProfitBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.possibleProfitTableAdapter = new Barber_Shop.barbershopDataSetTableAdapters.PossibleProfitTableAdapter();
            this.tableAdapterManager = new Barber_Shop.barbershopDataSetTableAdapters.TableAdapterManager();
            this.possibleProfitBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.possibleProfitBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.first_NameTextBox = new System.Windows.Forms.TextBox();
            this.last_NameTextBox = new System.Windows.Forms.TextBox();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.wholesale_PriceTextBox = new System.Windows.Forms.TextBox();
            this.retail_PriceTextBox = new System.Windows.Forms.TextBox();
            this.possible_ProfitTextBox = new System.Windows.Forms.TextBox();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonStartQuery = new System.Windows.Forms.Button();
            this.buttonResetTable = new System.Windows.Forms.Button();
            this.profitOverThreeBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.profitOverThreeTableAdapter = new Barber_Shop.barbershopDataSetTableAdapters.ProfitOverThreeTableAdapter();
            this.first_NameTextBox1 = new System.Windows.Forms.TextBox();
            this.last_NameTextBox1 = new System.Windows.Forms.TextBox();
            this.phoneTextBox1 = new System.Windows.Forms.TextBox();
            this.cityTextBox1 = new System.Windows.Forms.TextBox();
            this.wholesale_PriceTextBox1 = new System.Windows.Forms.TextBox();
            this.retail_PriceTextBox1 = new System.Windows.Forms.TextBox();
            this.possible_ProfitTextBox1 = new System.Windows.Forms.TextBox();
            this.toolStripContainer2 = new System.Windows.Forms.ToolStripContainer();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonStartQueryTwo = new System.Windows.Forms.Button();
            this.buttonResetTableTwo = new System.Windows.Forms.Button();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            first_NameLabel = new System.Windows.Forms.Label();
            last_NameLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            cityLabel = new System.Windows.Forms.Label();
            wholesale_PriceLabel = new System.Windows.Forms.Label();
            retail_PriceLabel = new System.Windows.Forms.Label();
            possible_ProfitLabel = new System.Windows.Forms.Label();
            first_NameLabel1 = new System.Windows.Forms.Label();
            last_NameLabel1 = new System.Windows.Forms.Label();
            phoneLabel1 = new System.Windows.Forms.Label();
            cityLabel1 = new System.Windows.Forms.Label();
            wholesale_PriceLabel1 = new System.Windows.Forms.Label();
            retail_PriceLabel1 = new System.Windows.Forms.Label();
            possible_ProfitLabel1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.barbershopDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.possibleProfitBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.possibleProfitBindingNavigator)).BeginInit();
            this.possibleProfitBindingNavigator.SuspendLayout();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profitOverThreeBindingSource)).BeginInit();
            this.toolStripContainer2.ContentPanel.SuspendLayout();
            this.toolStripContainer2.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // first_NameLabel
            // 
            first_NameLabel.AutoSize = true;
            first_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            first_NameLabel.Location = new System.Drawing.Point(28, 23);
            first_NameLabel.Name = "first_NameLabel";
            first_NameLabel.Size = new System.Drawing.Size(102, 22);
            first_NameLabel.TabIndex = 16;
            first_NameLabel.Text = "First Name:";
            // 
            // last_NameLabel
            // 
            last_NameLabel.AutoSize = true;
            last_NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            last_NameLabel.Location = new System.Drawing.Point(28, 55);
            last_NameLabel.Name = "last_NameLabel";
            last_NameLabel.Size = new System.Drawing.Size(101, 22);
            last_NameLabel.TabIndex = 18;
            last_NameLabel.Text = "Last Name:";
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            phoneLabel.Location = new System.Drawing.Point(28, 88);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(67, 22);
            phoneLabel.TabIndex = 20;
            phoneLabel.Text = "Phone:";
            // 
            // cityLabel
            // 
            cityLabel.AutoSize = true;
            cityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            cityLabel.Location = new System.Drawing.Point(28, 118);
            cityLabel.Name = "cityLabel";
            cityLabel.Size = new System.Drawing.Size(46, 22);
            cityLabel.TabIndex = 22;
            cityLabel.Text = "City:";
            // 
            // wholesale_PriceLabel
            // 
            wholesale_PriceLabel.AutoSize = true;
            wholesale_PriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            wholesale_PriceLabel.Location = new System.Drawing.Point(28, 151);
            wholesale_PriceLabel.Name = "wholesale_PriceLabel";
            wholesale_PriceLabel.Size = new System.Drawing.Size(145, 22);
            wholesale_PriceLabel.TabIndex = 24;
            wholesale_PriceLabel.Text = "Wholesale Price:";
            // 
            // retail_PriceLabel
            // 
            retail_PriceLabel.AutoSize = true;
            retail_PriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            retail_PriceLabel.Location = new System.Drawing.Point(28, 183);
            retail_PriceLabel.Name = "retail_PriceLabel";
            retail_PriceLabel.Size = new System.Drawing.Size(107, 22);
            retail_PriceLabel.TabIndex = 26;
            retail_PriceLabel.Text = "Retail Price:";
            // 
            // possible_ProfitLabel
            // 
            possible_ProfitLabel.AutoSize = true;
            possible_ProfitLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            possible_ProfitLabel.Location = new System.Drawing.Point(28, 215);
            possible_ProfitLabel.Name = "possible_ProfitLabel";
            possible_ProfitLabel.Size = new System.Drawing.Size(130, 22);
            possible_ProfitLabel.TabIndex = 28;
            possible_ProfitLabel.Text = "Possible Profit:";
            // 
            // first_NameLabel1
            // 
            first_NameLabel1.AutoSize = true;
            first_NameLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            first_NameLabel1.Location = new System.Drawing.Point(21, 18);
            first_NameLabel1.Name = "first_NameLabel1";
            first_NameLabel1.Size = new System.Drawing.Size(102, 22);
            first_NameLabel1.TabIndex = 30;
            first_NameLabel1.Text = "First Name:";
            // 
            // last_NameLabel1
            // 
            last_NameLabel1.AutoSize = true;
            last_NameLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            last_NameLabel1.Location = new System.Drawing.Point(21, 49);
            last_NameLabel1.Name = "last_NameLabel1";
            last_NameLabel1.Size = new System.Drawing.Size(101, 22);
            last_NameLabel1.TabIndex = 32;
            last_NameLabel1.Text = "Last Name:";
            // 
            // phoneLabel1
            // 
            phoneLabel1.AutoSize = true;
            phoneLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            phoneLabel1.Location = new System.Drawing.Point(21, 82);
            phoneLabel1.Name = "phoneLabel1";
            phoneLabel1.Size = new System.Drawing.Size(67, 22);
            phoneLabel1.TabIndex = 34;
            phoneLabel1.Text = "Phone:";
            // 
            // cityLabel1
            // 
            cityLabel1.AutoSize = true;
            cityLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            cityLabel1.Location = new System.Drawing.Point(21, 114);
            cityLabel1.Name = "cityLabel1";
            cityLabel1.Size = new System.Drawing.Size(46, 22);
            cityLabel1.TabIndex = 36;
            cityLabel1.Text = "City:";
            // 
            // wholesale_PriceLabel1
            // 
            wholesale_PriceLabel1.AutoSize = true;
            wholesale_PriceLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            wholesale_PriceLabel1.Location = new System.Drawing.Point(21, 146);
            wholesale_PriceLabel1.Name = "wholesale_PriceLabel1";
            wholesale_PriceLabel1.Size = new System.Drawing.Size(145, 22);
            wholesale_PriceLabel1.TabIndex = 38;
            wholesale_PriceLabel1.Text = "Wholesale Price:";
            // 
            // retail_PriceLabel1
            // 
            retail_PriceLabel1.AutoSize = true;
            retail_PriceLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            retail_PriceLabel1.Location = new System.Drawing.Point(21, 178);
            retail_PriceLabel1.Name = "retail_PriceLabel1";
            retail_PriceLabel1.Size = new System.Drawing.Size(107, 22);
            retail_PriceLabel1.TabIndex = 40;
            retail_PriceLabel1.Text = "Retail Price:";
            // 
            // possible_ProfitLabel1
            // 
            possible_ProfitLabel1.AutoSize = true;
            possible_ProfitLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            possible_ProfitLabel1.Location = new System.Drawing.Point(21, 209);
            possible_ProfitLabel1.Name = "possible_ProfitLabel1";
            possible_ProfitLabel1.Size = new System.Drawing.Size(130, 22);
            possible_ProfitLabel1.TabIndex = 42;
            possible_ProfitLabel1.Text = "Possible Profit:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(5, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(569, 17);
            this.label2.TabIndex = 14;
            this.label2.Text = "Compare possible profits to be made when purchasing wholesale from nearby";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(5, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(374, 17);
            this.label1.TabIndex = 15;
            this.label1.Text = "vendors to save money on transportation of goods";
            // 
            // barbershopDataSet
            // 
            this.barbershopDataSet.DataSetName = "barbershopDataSet";
            this.barbershopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // possibleProfitBindingSource
            // 
            this.possibleProfitBindingSource.DataMember = "PossibleProfit";
            this.possibleProfitBindingSource.DataSource = this.barbershopDataSet;
            // 
            // possibleProfitTableAdapter
            // 
            this.possibleProfitTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CategoryTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.customerorderTableAdapter = null;
            this.tableAdapterManager.CustomerTableAdapter = null;
            this.tableAdapterManager.EmployeeTableAdapter = null;
            this.tableAdapterManager.order_productsTableAdapter = null;
            this.tableAdapterManager.order_servicesTableAdapter = null;
            this.tableAdapterManager.PersonTableAdapter = null;
            this.tableAdapterManager.productTableAdapter = null;
            this.tableAdapterManager.serviceTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Barber_Shop.barbershopDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VendorTableAdapter = null;
            // 
            // possibleProfitBindingNavigator
            // 
            this.possibleProfitBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.possibleProfitBindingNavigator.BindingSource = this.possibleProfitBindingSource;
            this.possibleProfitBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.possibleProfitBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.possibleProfitBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.possibleProfitBindingNavigator.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.possibleProfitBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.possibleProfitBindingNavigatorSaveItem});
            this.possibleProfitBindingNavigator.Location = new System.Drawing.Point(4, 0);
            this.possibleProfitBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.possibleProfitBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.possibleProfitBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.possibleProfitBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.possibleProfitBindingNavigator.Name = "possibleProfitBindingNavigator";
            this.possibleProfitBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.possibleProfitBindingNavigator.Size = new System.Drawing.Size(382, 38);
            this.possibleProfitBindingNavigator.TabIndex = 16;
            this.possibleProfitBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(34, 33);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(54, 33);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(34, 33);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(34, 33);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(34, 33);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 38);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 31);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 38);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(34, 33);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(34, 33);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 38);
            // 
            // possibleProfitBindingNavigatorSaveItem
            // 
            this.possibleProfitBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.possibleProfitBindingNavigatorSaveItem.Enabled = false;
            this.possibleProfitBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("possibleProfitBindingNavigatorSaveItem.Image")));
            this.possibleProfitBindingNavigatorSaveItem.Name = "possibleProfitBindingNavigatorSaveItem";
            this.possibleProfitBindingNavigatorSaveItem.Size = new System.Drawing.Size(34, 33);
            this.possibleProfitBindingNavigatorSaveItem.Text = "Save Data";
            // 
            // first_NameTextBox
            // 
            this.first_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.possibleProfitBindingSource, "First Name", true));
            this.first_NameTextBox.Location = new System.Drawing.Point(192, 22);
            this.first_NameTextBox.Name = "first_NameTextBox";
            this.first_NameTextBox.Size = new System.Drawing.Size(210, 26);
            this.first_NameTextBox.TabIndex = 17;
            // 
            // last_NameTextBox
            // 
            this.last_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.possibleProfitBindingSource, "Last Name", true));
            this.last_NameTextBox.Location = new System.Drawing.Point(192, 54);
            this.last_NameTextBox.Name = "last_NameTextBox";
            this.last_NameTextBox.Size = new System.Drawing.Size(210, 26);
            this.last_NameTextBox.TabIndex = 19;
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.possibleProfitBindingSource, "Phone", true));
            this.phoneTextBox.Location = new System.Drawing.Point(192, 86);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(210, 26);
            this.phoneTextBox.TabIndex = 21;
            // 
            // cityTextBox
            // 
            this.cityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.possibleProfitBindingSource, "City", true));
            this.cityTextBox.Location = new System.Drawing.Point(192, 117);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(210, 26);
            this.cityTextBox.TabIndex = 23;
            // 
            // wholesale_PriceTextBox
            // 
            this.wholesale_PriceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.possibleProfitBindingSource, "Wholesale Price", true));
            this.wholesale_PriceTextBox.Location = new System.Drawing.Point(192, 149);
            this.wholesale_PriceTextBox.Name = "wholesale_PriceTextBox";
            this.wholesale_PriceTextBox.Size = new System.Drawing.Size(210, 26);
            this.wholesale_PriceTextBox.TabIndex = 25;
            // 
            // retail_PriceTextBox
            // 
            this.retail_PriceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.possibleProfitBindingSource, "Retail Price", true));
            this.retail_PriceTextBox.Location = new System.Drawing.Point(192, 182);
            this.retail_PriceTextBox.Name = "retail_PriceTextBox";
            this.retail_PriceTextBox.Size = new System.Drawing.Size(210, 26);
            this.retail_PriceTextBox.TabIndex = 27;
            // 
            // possible_ProfitTextBox
            // 
            this.possible_ProfitTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.possibleProfitBindingSource, "Possible Profit", true));
            this.possible_ProfitTextBox.Location = new System.Drawing.Point(192, 214);
            this.possible_ProfitTextBox.Name = "possible_ProfitTextBox";
            this.possible_ProfitTextBox.Size = new System.Drawing.Size(210, 26);
            this.possible_ProfitTextBox.TabIndex = 29;
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label4);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.buttonStartQuery);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.buttonResetTable);
            this.toolStripContainer1.ContentPanel.Controls.Add(first_NameLabel);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.possible_ProfitTextBox);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.first_NameTextBox);
            this.toolStripContainer1.ContentPanel.Controls.Add(possible_ProfitLabel);
            this.toolStripContainer1.ContentPanel.Controls.Add(last_NameLabel);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.retail_PriceTextBox);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.last_NameTextBox);
            this.toolStripContainer1.ContentPanel.Controls.Add(retail_PriceLabel);
            this.toolStripContainer1.ContentPanel.Controls.Add(phoneLabel);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.wholesale_PriceTextBox);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.phoneTextBox);
            this.toolStripContainer1.ContentPanel.Controls.Add(wholesale_PriceLabel);
            this.toolStripContainer1.ContentPanel.Controls.Add(cityLabel);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.cityTextBox);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(687, 245);
            this.toolStripContainer1.Location = new System.Drawing.Point(8, 60);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(687, 283);
            this.toolStripContainer1.TabIndex = 30;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.possibleProfitBindingNavigator);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(408, 151);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(232, 22);
            this.label4.TabIndex = 32;
            this.label4.Text = "*Where clause + Subquery*";
            // 
            // buttonStartQuery
            // 
            this.buttonStartQuery.Location = new System.Drawing.Point(410, 32);
            this.buttonStartQuery.Name = "buttonStartQuery";
            this.buttonStartQuery.Size = new System.Drawing.Size(99, 57);
            this.buttonStartQuery.TabIndex = 31;
            this.buttonStartQuery.Text = "Start Query";
            this.buttonStartQuery.UseVisualStyleBackColor = true;
            this.buttonStartQuery.Click += new System.EventHandler(this.buttonStartQuery_Click);
            // 
            // buttonResetTable
            // 
            this.buttonResetTable.Location = new System.Drawing.Point(515, 32);
            this.buttonResetTable.Name = "buttonResetTable";
            this.buttonResetTable.Size = new System.Drawing.Size(99, 57);
            this.buttonResetTable.TabIndex = 30;
            this.buttonResetTable.Text = "Reset Table";
            this.buttonResetTable.UseVisualStyleBackColor = true;
            this.buttonResetTable.Click += new System.EventHandler(this.buttonResetTable_Click);
            // 
            // profitOverThreeBindingSource
            // 
            this.profitOverThreeBindingSource.DataMember = "ProfitOverThree";
            this.profitOverThreeBindingSource.DataSource = this.barbershopDataSet;
            // 
            // profitOverThreeTableAdapter
            // 
            this.profitOverThreeTableAdapter.ClearBeforeFill = true;
            // 
            // first_NameTextBox1
            // 
            this.first_NameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.profitOverThreeBindingSource, "First Name", true));
            this.first_NameTextBox1.Location = new System.Drawing.Point(182, 14);
            this.first_NameTextBox1.Name = "first_NameTextBox1";
            this.first_NameTextBox1.Size = new System.Drawing.Size(217, 26);
            this.first_NameTextBox1.TabIndex = 31;
            // 
            // last_NameTextBox1
            // 
            this.last_NameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.profitOverThreeBindingSource, "Last Name", true));
            this.last_NameTextBox1.Location = new System.Drawing.Point(182, 46);
            this.last_NameTextBox1.Name = "last_NameTextBox1";
            this.last_NameTextBox1.Size = new System.Drawing.Size(217, 26);
            this.last_NameTextBox1.TabIndex = 33;
            // 
            // phoneTextBox1
            // 
            this.phoneTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.profitOverThreeBindingSource, "Phone", true));
            this.phoneTextBox1.Location = new System.Drawing.Point(182, 77);
            this.phoneTextBox1.Name = "phoneTextBox1";
            this.phoneTextBox1.Size = new System.Drawing.Size(217, 26);
            this.phoneTextBox1.TabIndex = 35;
            // 
            // cityTextBox1
            // 
            this.cityTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.profitOverThreeBindingSource, "City", true));
            this.cityTextBox1.Location = new System.Drawing.Point(182, 109);
            this.cityTextBox1.Name = "cityTextBox1";
            this.cityTextBox1.Size = new System.Drawing.Size(217, 26);
            this.cityTextBox1.TabIndex = 37;
            // 
            // wholesale_PriceTextBox1
            // 
            this.wholesale_PriceTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.profitOverThreeBindingSource, "Wholesale Price", true));
            this.wholesale_PriceTextBox1.Location = new System.Drawing.Point(182, 142);
            this.wholesale_PriceTextBox1.Name = "wholesale_PriceTextBox1";
            this.wholesale_PriceTextBox1.Size = new System.Drawing.Size(217, 26);
            this.wholesale_PriceTextBox1.TabIndex = 39;
            // 
            // retail_PriceTextBox1
            // 
            this.retail_PriceTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.profitOverThreeBindingSource, "Retail Price", true));
            this.retail_PriceTextBox1.Location = new System.Drawing.Point(182, 174);
            this.retail_PriceTextBox1.Name = "retail_PriceTextBox1";
            this.retail_PriceTextBox1.Size = new System.Drawing.Size(217, 26);
            this.retail_PriceTextBox1.TabIndex = 41;
            // 
            // possible_ProfitTextBox1
            // 
            this.possible_ProfitTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.profitOverThreeBindingSource, "Possible Profit", true));
            this.possible_ProfitTextBox1.Location = new System.Drawing.Point(182, 206);
            this.possible_ProfitTextBox1.Name = "possible_ProfitTextBox1";
            this.possible_ProfitTextBox1.Size = new System.Drawing.Size(217, 26);
            this.possible_ProfitTextBox1.TabIndex = 43;
            // 
            // toolStripContainer2
            // 
            // 
            // toolStripContainer2.ContentPanel
            // 
            this.toolStripContainer2.ContentPanel.Controls.Add(this.label5);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.buttonStartQueryTwo);
            this.toolStripContainer2.ContentPanel.Controls.Add(first_NameLabel1);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.buttonResetTableTwo);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.first_NameTextBox1);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.possible_ProfitTextBox1);
            this.toolStripContainer2.ContentPanel.Controls.Add(last_NameLabel1);
            this.toolStripContainer2.ContentPanel.Controls.Add(possible_ProfitLabel1);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.last_NameTextBox1);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.retail_PriceTextBox1);
            this.toolStripContainer2.ContentPanel.Controls.Add(phoneLabel1);
            this.toolStripContainer2.ContentPanel.Controls.Add(retail_PriceLabel1);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.phoneTextBox1);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.wholesale_PriceTextBox1);
            this.toolStripContainer2.ContentPanel.Controls.Add(cityLabel1);
            this.toolStripContainer2.ContentPanel.Controls.Add(wholesale_PriceLabel1);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.cityTextBox1);
            this.toolStripContainer2.ContentPanel.Size = new System.Drawing.Size(678, 245);
            this.toolStripContainer2.Location = new System.Drawing.Point(8, 40);
            this.toolStripContainer2.Name = "toolStripContainer2";
            this.toolStripContainer2.Size = new System.Drawing.Size(678, 283);
            this.toolStripContainer2.TabIndex = 44;
            this.toolStripContainer2.Text = "toolStripContainer2";
            // 
            // toolStripContainer2.TopToolStripPanel
            // 
            this.toolStripContainer2.TopToolStripPanel.Controls.Add(this.bindingNavigator1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(405, 165);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(232, 22);
            this.label5.TabIndex = 46;
            this.label5.Text = "*Where clause + Subquery*";
            // 
            // buttonStartQueryTwo
            // 
            this.buttonStartQueryTwo.Location = new System.Drawing.Point(410, 32);
            this.buttonStartQueryTwo.Name = "buttonStartQueryTwo";
            this.buttonStartQueryTwo.Size = new System.Drawing.Size(99, 62);
            this.buttonStartQueryTwo.TabIndex = 31;
            this.buttonStartQueryTwo.Text = "Start Query";
            this.buttonStartQueryTwo.UseVisualStyleBackColor = true;
            this.buttonStartQueryTwo.Click += new System.EventHandler(this.buttonStartQueryTwo_Click);
            // 
            // buttonResetTableTwo
            // 
            this.buttonResetTableTwo.Location = new System.Drawing.Point(515, 32);
            this.buttonResetTableTwo.Name = "buttonResetTableTwo";
            this.buttonResetTableTwo.Size = new System.Drawing.Size(99, 62);
            this.buttonResetTableTwo.TabIndex = 30;
            this.buttonResetTableTwo.Text = "Reset Table";
            this.buttonResetTableTwo.UseVisualStyleBackColor = true;
            this.buttonResetTableTwo.Click += new System.EventHandler(this.buttonResetTableTwo_Click);
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = this.toolStripButton1;
            this.bindingNavigator1.BindingSource = this.profitOverThreeBindingSource;
            this.bindingNavigator1.CountItem = this.toolStripLabel1;
            this.bindingNavigator1.DeleteItem = this.toolStripButton2;
            this.bindingNavigator1.Dock = System.Windows.Forms.DockStyle.None;
            this.bindingNavigator1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator1,
            this.toolStripTextBox1,
            this.toolStripLabel1,
            this.toolStripSeparator2,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripSeparator3,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton7});
            this.bindingNavigator1.Location = new System.Drawing.Point(4, 0);
            this.bindingNavigator1.MoveFirstItem = this.toolStripButton3;
            this.bindingNavigator1.MoveLastItem = this.toolStripButton6;
            this.bindingNavigator1.MoveNextItem = this.toolStripButton5;
            this.bindingNavigator1.MovePreviousItem = this.toolStripButton4;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.toolStripTextBox1;
            this.bindingNavigator1.Size = new System.Drawing.Size(382, 38);
            this.bindingNavigator1.TabIndex = 16;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.RightToLeftAutoMirrorImage = true;
            this.toolStripButton1.Size = new System.Drawing.Size(34, 33);
            this.toolStripButton1.Text = "Add new";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(54, 33);
            this.toolStripLabel1.Text = "of {0}";
            this.toolStripLabel1.ToolTipText = "Total number of items";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripButton2.Size = new System.Drawing.Size(34, 33);
            this.toolStripButton2.Text = "Delete";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.RightToLeftAutoMirrorImage = true;
            this.toolStripButton3.Size = new System.Drawing.Size(34, 33);
            this.toolStripButton3.Text = "Move first";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.RightToLeftAutoMirrorImage = true;
            this.toolStripButton4.Size = new System.Drawing.Size(34, 33);
            this.toolStripButton4.Text = "Move previous";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 38);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AccessibleName = "Position";
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(50, 31);
            this.toolStripTextBox1.Text = "0";
            this.toolStripTextBox1.ToolTipText = "Current position";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 38);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.RightToLeftAutoMirrorImage = true;
            this.toolStripButton5.Size = new System.Drawing.Size(34, 33);
            this.toolStripButton5.Text = "Move next";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.RightToLeftAutoMirrorImage = true;
            this.toolStripButton6.Size = new System.Drawing.Size(34, 33);
            this.toolStripButton6.Text = "Move last";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 38);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Enabled = false;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(34, 33);
            this.toolStripButton7.Text = "Save Data";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(8, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(400, 17);
            this.label3.TabIndex = 45;
            this.label3.Text = "Query where possible profits of Vendors is over $3.00";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.toolStripContainer1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(702, 354);
            this.groupBox1.TabIndex = 46;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Query #1";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.toolStripContainer2);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Location = new System.Drawing.Point(12, 372);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(702, 329);
            this.groupBox2.TabIndex = 47;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Query #2";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // QueryThree
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(723, 713);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "QueryThree";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QueryThree";
            this.Load += new System.EventHandler(this.QueryThree_Load);
            ((System.ComponentModel.ISupportInitialize)(this.barbershopDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.possibleProfitBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.possibleProfitBindingNavigator)).EndInit();
            this.possibleProfitBindingNavigator.ResumeLayout(false);
            this.possibleProfitBindingNavigator.PerformLayout();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ContentPanel.PerformLayout();
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.profitOverThreeBindingSource)).EndInit();
            this.toolStripContainer2.ContentPanel.ResumeLayout(false);
            this.toolStripContainer2.ContentPanel.PerformLayout();
            this.toolStripContainer2.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer2.TopToolStripPanel.PerformLayout();
            this.toolStripContainer2.ResumeLayout(false);
            this.toolStripContainer2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private barbershopDataSet barbershopDataSet;
        private System.Windows.Forms.BindingSource possibleProfitBindingSource;
        private barbershopDataSetTableAdapters.PossibleProfitTableAdapter possibleProfitTableAdapter;
        private barbershopDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator possibleProfitBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton possibleProfitBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox first_NameTextBox;
        private System.Windows.Forms.TextBox last_NameTextBox;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.TextBox wholesale_PriceTextBox;
        private System.Windows.Forms.TextBox retail_PriceTextBox;
        private System.Windows.Forms.TextBox possible_ProfitTextBox;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.Button buttonStartQuery;
        private System.Windows.Forms.Button buttonResetTable;
        private System.Windows.Forms.BindingSource profitOverThreeBindingSource;
        private barbershopDataSetTableAdapters.ProfitOverThreeTableAdapter profitOverThreeTableAdapter;
        private System.Windows.Forms.TextBox first_NameTextBox1;
        private System.Windows.Forms.TextBox last_NameTextBox1;
        private System.Windows.Forms.TextBox phoneTextBox1;
        private System.Windows.Forms.TextBox cityTextBox1;
        private System.Windows.Forms.TextBox wholesale_PriceTextBox1;
        private System.Windows.Forms.TextBox retail_PriceTextBox1;
        private System.Windows.Forms.TextBox possible_ProfitTextBox1;
        private System.Windows.Forms.ToolStripContainer toolStripContainer2;
        private System.Windows.Forms.Button buttonStartQueryTwo;
        private System.Windows.Forms.Button buttonResetTableTwo;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}