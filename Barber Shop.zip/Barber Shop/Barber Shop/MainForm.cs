﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barber_Shop
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void categoryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {

        }

        private void buttonShowQueries_Click(object sender, EventArgs e)
        {
            queries queries = new queries(); //Create form in memory

            //Display details form
            queries.ShowDialog();

            //when user closes form, update database
            //this.productTableAdapter.Fill(this.productDataSet.Product);
        }

        private void buttonShowTables_Click(object sender, EventArgs e)
        {
            Tables tables = new Tables();
            tables.ShowDialog();


        }

        private void buttonDetails_Click(object sender, EventArgs e)
        {
            Details details = new Details();
            details.ShowDialog();
        }

        private void buttonShowQueryTwo_Click(object sender, EventArgs e)
        {
            QueryTwo query = new QueryTwo();
            query.ShowDialog();
            
        }

        private void buttonShowQueryThree_Click(object sender, EventArgs e)
        {
            QueryThree query = new QueryThree();
            query.ShowDialog();
        }

        private void buttonSearchForm_Click(object sender, EventArgs e)
        {
            SearchForm search = new SearchForm();
            search.ShowDialog();
        }

        private void buttonSearchOrders_Click(object sender, EventArgs e)
        {
            SearchOrders sOrders = new SearchOrders();
            sOrders.ShowDialog();
        }

        private void buttonSearchWholesale_Click(object sender, EventArgs e)
        {
            PossibleProfit pProfit = new PossibleProfit();  
            pProfit.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      
    }  
}
