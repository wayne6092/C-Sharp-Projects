﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barber_Shop
{
    public partial class queries : Form
    {
        public queries()
        {
            InitializeComponent();
        }

        private void buttonQueryOne_Click(object sender, EventArgs e)
        {
            this.totalQueryTableAdapter.FillTotal(this.barbershopDataSet.TotalQuery);
        }

        private void QueriesForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'barbershopDataSet.PaymentTypes' table. You can move, or remove it, as needed.
            this.paymentTypesTableAdapter.FillPaymentTypes(this.barbershopDataSet.PaymentTypes);


            // TODO: This line of code loads data into the 'barbershopDataSet.ShampooService' table. You can move, or remove it, as needed.

            this.shampooServiceTableAdapter.FillByTable(this.barbershopDataSet.ShampooService);
            // TODO: This line of code loads data into the 'barbershopDataSet.TotalQuery' table. You can move, or remove it, as needed.
            this.totalQueryTableAdapter.FillByTotalStart(this.barbershopDataSet.TotalQuery);

        }

        private void buttonResetTotalTable_Click(object sender, EventArgs e)
        {
            this.totalQueryTableAdapter.FillByTotalStart(this.barbershopDataSet.TotalQuery);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.shampooServiceTableAdapter.EmployeeShampooAndService(this.barbershopDataSet.ShampooService);
        }

        private void buttonQueryThree_Click(object sender, EventArgs e)
        {
            this.paymentTypesTableAdapter.FillByCashOrCredit(this.barbershopDataSet.PaymentTypes);
        }


        private void buttonResetQueryTwo_Click(object sender, EventArgs e)
        {

            this.shampooServiceTableAdapter.FillByTable(this.barbershopDataSet.ShampooService);
        }

        private void buttonResetQueryThree_Click(object sender, EventArgs e)
        {
            this.paymentTypesTableAdapter.FillPaymentTypes(this.barbershopDataSet.PaymentTypes);
        }

        private void toolStripContainer3_ContentPanel_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.paymentTypesTableAdapter.FillByCheckOrDebit(this.barbershopDataSet.PaymentTypes);
        }
    }
}
