﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barber_Shop
{
    public partial class Tables : Form
    {
        public Tables()
        {
            InitializeComponent();
        }

        private void categoryBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.categoryBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.barbershopDataSet);

        }

        private void Tables_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'barbershopDataSet.Category' table. You can move, or remove it, as needed.
            this.categoryTableAdapter.Fill(this.barbershopDataSet.Category);
            // TODO: This line of code loads data into the 'barbershopDataSet.Vendor' table. You can move, or remove it, as needed.
            this.vendorTableAdapter.Fill(this.barbershopDataSet.Vendor);
            // TODO: This line of code loads data into the 'barbershopDataSet.service' table. You can move, or remove it, as needed.
            this.serviceTableAdapter.Fill(this.barbershopDataSet.service);
            // TODO: This line of code loads data into the 'barbershopDataSet.product' table. You can move, or remove it, as needed.
            this.productTableAdapter.Fill(this.barbershopDataSet.product);
            // TODO: This line of code loads data into the 'barbershopDataSet.Person' table. You can move, or remove it, as needed.
            this.personTableAdapter.Fill(this.barbershopDataSet.Person);
            // TODO: This line of code loads data into the 'barbershopDataSet.order_services' table. You can move, or remove it, as needed.
            this.order_servicesTableAdapter.Fill(this.barbershopDataSet.order_services);
            // TODO: This line of code loads data into the 'barbershopDataSet.order_products' table. You can move, or remove it, as needed.
            this.order_productsTableAdapter.Fill(this.barbershopDataSet.order_products);
            // TODO: This line of code loads data into the 'barbershopDataSet.Employee' table. You can move, or remove it, as needed.
            this.employeeTableAdapter.Fill(this.barbershopDataSet.Employee);
            // TODO: This line of code loads data into the 'barbershopDataSet.customerorder' table. You can move, or remove it, as needed.
            this.customerorderTableAdapter.Fill(this.barbershopDataSet.customerorder);
            // TODO: This line of code loads data into the 'barbershopDataSet.Customer' table. You can move, or remove it, as needed.
            this.customerTableAdapter.Fill(this.barbershopDataSet.Customer);
            

        }
    }
}
