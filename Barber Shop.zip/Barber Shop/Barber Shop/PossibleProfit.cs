﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barber_Shop
{
    public partial class PossibleProfit : Form
    {
        public PossibleProfit()
        {
            InitializeComponent();
        }

        private void PossibleProfit_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'barbershopDataSet.SearchPossibleProfit' table. You can move, or remove it, as needed.
            this.searchPossibleProfitTableAdapter.Fill(this.barbershopDataSet.SearchPossibleProfit);

        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            this.searchPossibleProfitTableAdapter.FillByName(this.barbershopDataSet.SearchPossibleProfit,
                textBoxSearchFirst.Text, textBoxSearchLast.Text);
        }

        private void buttonSearchCity_Click(object sender, EventArgs e)
        {
            this.searchPossibleProfitTableAdapter.FillByCity(this.barbershopDataSet.SearchPossibleProfit,
                textBoxCity.Text);
        }

        private void buttonPhoneNumber_Click(object sender, EventArgs e)
        {
            this.searchPossibleProfitTableAdapter.FillByPhone(this.barbershopDataSet.SearchPossibleProfit,
                textBoxPhoneNumber.Text);
        }

        private void buttonProductName_Click(object sender, EventArgs e)
        {
            this.searchPossibleProfitTableAdapter.FillByProductName(this.barbershopDataSet.SearchPossibleProfit,
                textBoxProductName.Text);
        }

        private void buttonShowAll_Click(object sender, EventArgs e)
        {
            this.searchPossibleProfitTableAdapter.Fill(this.barbershopDataSet.SearchPossibleProfit);
        }
    }
}
