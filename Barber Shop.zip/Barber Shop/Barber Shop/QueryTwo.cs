﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barber_Shop
{
    public partial class QueryTwo : Form
    {
        public QueryTwo()
        {
            InitializeComponent();
        }

        private void QueryTwo_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'barbershopDataSet.NearbyVendors' table. You can move, or remove it, as needed.
            this.nearbyVendorsTableAdapter.FillStart(this.barbershopDataSet.NearbyVendors);
            // TODO: This line of code loads data into the 'barbershopDataSet.Employee_Services' table. You can move, or remove it, as needed.
            this.employee_ServicesTableAdapter.FillStart(this.barbershopDataSet.Employee_Services);
            // TODO: This line of code loads data into the 'barbershopDataSet.CustomerServices' table. You can move, or remove it, as needed.
            this.customerServicesTableAdapter.FillStart(this.barbershopDataSet.CustomerServices);

        }

        private void buttonShowCustomers_Click(object sender, EventArgs e)
        {
            this.customerServicesTableAdapter.FillByShowAllCustomers(this.barbershopDataSet.CustomerServices);
        }

        private void buttonResetTable_Click(object sender, EventArgs e)
        {
            this.customerServicesTableAdapter.FillStart(this.barbershopDataSet.CustomerServices);
        }

        private void buttonShowEmployees_Click(object sender, EventArgs e)
        {
            this.employee_ServicesTableAdapter.FillByServices(this.barbershopDataSet.Employee_Services);
        }

        private void buttonResetTableTwo_Click(object sender, EventArgs e)
        {
            this.employee_ServicesTableAdapter.FillStart(this.barbershopDataSet.Employee_Services);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.nearbyVendorsTableAdapter.FillByNearbyVendors(this.barbershopDataSet.NearbyVendors);

        }

        private void buttonResetTableThree_Click(object sender, EventArgs e)
        {
            this.nearbyVendorsTableAdapter.FillStart(this.barbershopDataSet.NearbyVendors);

        }
    }
}
