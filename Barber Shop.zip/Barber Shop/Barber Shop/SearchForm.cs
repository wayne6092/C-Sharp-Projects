﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barber_Shop
{
    public partial class SearchForm : Form
    {
        public SearchForm()
        {
            InitializeComponent();
        }

        private void personBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.personBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.barbershopDataSet);

        }

        private void SearchForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'barbershopDataSet.Person' table. You can move, or remove it, as needed.
            this.personTableAdapter.Fill(this.barbershopDataSet.Person);

        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            this.personTableAdapter.FillByName(this.barbershopDataSet.Person, 
                textBoxSearchFirst.Text, textBoxSearchLast.Text);
        }

        private void buttonShowAll_Click(object sender, EventArgs e)
        {
            this.personTableAdapter.Fill(this.barbershopDataSet.Person);
        }

        private void buttonSearchCity_Click(object sender, EventArgs e)
        {
            this.personTableAdapter.FillByCity(this.barbershopDataSet.Person,
                textBoxCity.Text);
        }

        private void buttonSearchThree_Click(object sender, EventArgs e)
        {
            this.personTableAdapter.FillByPhone(this.barbershopDataSet.Person,
                textBoxPhoneNumber.Text);
        }

        private void buttonSearchPeopleType_Click(object sender, EventArgs e)
        {
            this.personTableAdapter.FillByPeopleType(this.barbershopDataSet.Person,
                textBoxPeopleType.Text);
        }

        private void buttonSearchZip_Click(object sender, EventArgs e)
        {
            this.personTableAdapter.FillByZip(this.barbershopDataSet.Person,
                textBoxZip.Text);
        }

        private void buttonSearchEmail_Click(object sender, EventArgs e)
        {
            this.personTableAdapter.FillByEmail(this.barbershopDataSet.Person,
                textBoxEmail.Text);
        }
    }
}
