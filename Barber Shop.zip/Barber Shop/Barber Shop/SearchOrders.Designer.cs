﻿namespace Barber_Shop
{
    partial class SearchOrders
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SearchOrders));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxSearchLast = new System.Windows.Forms.TextBox();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.textBoxSearchFirst = new System.Windows.Forms.TextBox();
            this.buttonShowAll = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonSearchOrderNumber = new System.Windows.Forms.Button();
            this.textBoxOrderID = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.buttonProductService = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonSearchType = new System.Windows.Forms.Button();
            this.textBoxType = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.buttonSearchAbove = new System.Windows.Forms.Button();
            this.textBoxTotalBelow = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonTotal = new System.Windows.Forms.Button();
            this.textBoxTotalAbove = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.textBoxEmployeeLastName = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.buttonSearchEmployeeName = new System.Windows.Forms.Button();
            this.textBoxEmployeeFirstName = new System.Windows.Forms.TextBox();
            this.searchOrderTablesBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.searchOrderTablesBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.searchOrderTablesDataGridView = new System.Windows.Forms.DataGridView();
            this.buttonServiceName = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.searchOrderTablesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.barbershopDataSet = new Barber_Shop.barbershopDataSet();
            this.tableAdapterManager = new Barber_Shop.barbershopDataSetTableAdapters.TableAdapterManager();
            this.searchOrderTablesTableAdapter = new Barber_Shop.barbershopDataSetTableAdapters.SearchOrderTablesTableAdapter();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.searchOrderTablesBindingNavigator)).BeginInit();
            this.searchOrderTablesBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.searchOrderTablesDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchOrderTablesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barbershopDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.textBoxSearchLast);
            this.groupBox1.Controls.Add(this.buttonSearch);
            this.groupBox1.Controls.Add(this.textBoxSearchFirst);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(13, 341);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(297, 129);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(100, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Last Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "First Name: ";
            // 
            // textBoxSearchLast
            // 
            this.textBoxSearchLast.Location = new System.Drawing.Point(164, 57);
            this.textBoxSearchLast.Name = "textBoxSearchLast";
            this.textBoxSearchLast.Size = new System.Drawing.Size(114, 26);
            this.textBoxSearchLast.TabIndex = 3;
            // 
            // buttonSearch
            // 
            this.buttonSearch.Location = new System.Drawing.Point(196, 91);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(82, 32);
            this.buttonSearch.TabIndex = 2;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // textBoxSearchFirst
            // 
            this.textBoxSearchFirst.Location = new System.Drawing.Point(164, 25);
            this.textBoxSearchFirst.Name = "textBoxSearchFirst";
            this.textBoxSearchFirst.Size = new System.Drawing.Size(114, 26);
            this.textBoxSearchFirst.TabIndex = 0;
            // 
            // buttonShowAll
            // 
            this.buttonShowAll.Location = new System.Drawing.Point(13, 487);
            this.buttonShowAll.Name = "buttonShowAll";
            this.buttonShowAll.Size = new System.Drawing.Size(122, 32);
            this.buttonShowAll.TabIndex = 5;
            this.buttonShowAll.Text = "Show All Items";
            this.buttonShowAll.UseVisualStyleBackColor = true;
            this.buttonShowAll.Click += new System.EventHandler(this.buttonShowAll_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.buttonSearchOrderNumber);
            this.groupBox2.Controls.Add(this.textBoxOrderID);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(341, 341);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(297, 129);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Search OrderID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(27, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Order Number: ";
            // 
            // buttonSearchOrderNumber
            // 
            this.buttonSearchOrderNumber.Location = new System.Drawing.Point(196, 91);
            this.buttonSearchOrderNumber.Name = "buttonSearchOrderNumber";
            this.buttonSearchOrderNumber.Size = new System.Drawing.Size(82, 32);
            this.buttonSearchOrderNumber.TabIndex = 2;
            this.buttonSearchOrderNumber.Text = "Search";
            this.buttonSearchOrderNumber.UseVisualStyleBackColor = true;
            this.buttonSearchOrderNumber.Click += new System.EventHandler(this.buttonSearchOrderNumber_Click);
            // 
            // textBoxOrderID
            // 
            this.textBoxOrderID.Location = new System.Drawing.Point(164, 25);
            this.textBoxOrderID.Name = "textBoxOrderID";
            this.textBoxOrderID.Size = new System.Drawing.Size(114, 26);
            this.textBoxOrderID.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.buttonServiceName);
            this.groupBox3.Controls.Add(this.buttonProductService);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(667, 341);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(297, 129);
            this.groupBox3.TabIndex = 9;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Search Product/Service:";
            // 
            // buttonProductService
            // 
            this.buttonProductService.Location = new System.Drawing.Point(52, 28);
            this.buttonProductService.Name = "buttonProductService";
            this.buttonProductService.Size = new System.Drawing.Size(195, 32);
            this.buttonProductService.TabIndex = 2;
            this.buttonProductService.Text = "Show Services";
            this.buttonProductService.UseVisualStyleBackColor = true;
            this.buttonProductService.Click += new System.EventHandler(this.buttonProductService_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Controls.Add(this.buttonSearchType);
            this.groupBox4.Controls.Add(this.textBoxType);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(988, 341);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(297, 129);
            this.groupBox4.TabIndex = 10;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Search Quantity";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(77, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Quantity:";
            // 
            // buttonSearchType
            // 
            this.buttonSearchType.Location = new System.Drawing.Point(196, 91);
            this.buttonSearchType.Name = "buttonSearchType";
            this.buttonSearchType.Size = new System.Drawing.Size(82, 32);
            this.buttonSearchType.TabIndex = 2;
            this.buttonSearchType.Text = "Search";
            this.buttonSearchType.UseVisualStyleBackColor = true;
            this.buttonSearchType.Click += new System.EventHandler(this.buttonSearchType_Click);
            // 
            // textBoxType
            // 
            this.textBoxType.Location = new System.Drawing.Point(164, 28);
            this.textBoxType.Name = "textBoxType";
            this.textBoxType.Size = new System.Drawing.Size(114, 26);
            this.textBoxType.TabIndex = 0;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.buttonSearchAbove);
            this.groupBox5.Controls.Add(this.textBoxTotalBelow);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.buttonTotal);
            this.groupBox5.Controls.Add(this.textBoxTotalAbove);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(820, 487);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(465, 129);
            this.groupBox5.TabIndex = 11;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Filter Total Price ";
            // 
            // buttonSearchAbove
            // 
            this.buttonSearchAbove.Location = new System.Drawing.Point(290, 63);
            this.buttonSearchAbove.Name = "buttonSearchAbove";
            this.buttonSearchAbove.Size = new System.Drawing.Size(156, 32);
            this.buttonSearchAbove.TabIndex = 7;
            this.buttonSearchAbove.Text = "Search Above";
            this.buttonSearchAbove.UseVisualStyleBackColor = true;
            this.buttonSearchAbove.Click += new System.EventHandler(this.buttonSearchAbove_Click);
            // 
            // textBoxTotalBelow
            // 
            this.textBoxTotalBelow.Location = new System.Drawing.Point(170, 31);
            this.textBoxTotalBelow.Name = "textBoxTotalBelow";
            this.textBoxTotalBelow.Size = new System.Drawing.Size(114, 26);
            this.textBoxTotalBelow.TabIndex = 6;
            this.textBoxTotalBelow.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 20);
            this.label7.TabIndex = 5;
            this.label7.Text = "Show Above: $";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(27, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(126, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "Show Below: $";
            // 
            // buttonTotal
            // 
            this.buttonTotal.Location = new System.Drawing.Point(290, 25);
            this.buttonTotal.Name = "buttonTotal";
            this.buttonTotal.Size = new System.Drawing.Size(156, 32);
            this.buttonTotal.TabIndex = 2;
            this.buttonTotal.Text = "Search Below";
            this.buttonTotal.UseVisualStyleBackColor = true;
            this.buttonTotal.Click += new System.EventHandler(this.buttonTotal_Click);
            // 
            // textBoxTotalAbove
            // 
            this.textBoxTotalAbove.Location = new System.Drawing.Point(170, 65);
            this.textBoxTotalAbove.Name = "textBoxTotalAbove";
            this.textBoxTotalAbove.Size = new System.Drawing.Size(114, 26);
            this.textBoxTotalAbove.TabIndex = 0;
            this.textBoxTotalAbove.Text = "0";
            this.textBoxTotalAbove.TextChanged += new System.EventHandler(this.textBoxTotalAbove_TextChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.textBoxEmployeeLastName);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.buttonSearchEmployeeName);
            this.groupBox6.Controls.Add(this.textBoxEmployeeFirstName);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(341, 487);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(465, 129);
            this.groupBox6.TabIndex = 12;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Search For Employee";
            // 
            // textBoxEmployeeLastName
            // 
            this.textBoxEmployeeLastName.Location = new System.Drawing.Point(164, 62);
            this.textBoxEmployeeLastName.Name = "textBoxEmployeeLastName";
            this.textBoxEmployeeLastName.Size = new System.Drawing.Size(114, 26);
            this.textBoxEmployeeLastName.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(46, 65);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 20);
            this.label8.TabIndex = 5;
            this.label8.Text = "Last Name:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(46, 31);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(101, 20);
            this.label9.TabIndex = 4;
            this.label9.Text = "First Name:";
            // 
            // buttonSearchEmployeeName
            // 
            this.buttonSearchEmployeeName.Location = new System.Drawing.Point(293, 28);
            this.buttonSearchEmployeeName.Name = "buttonSearchEmployeeName";
            this.buttonSearchEmployeeName.Size = new System.Drawing.Size(156, 32);
            this.buttonSearchEmployeeName.TabIndex = 2;
            this.buttonSearchEmployeeName.Text = "Search";
            this.buttonSearchEmployeeName.UseVisualStyleBackColor = true;
            this.buttonSearchEmployeeName.Click += new System.EventHandler(this.buttonSearchEmployeeName_Click);
            // 
            // textBoxEmployeeFirstName
            // 
            this.textBoxEmployeeFirstName.Location = new System.Drawing.Point(164, 28);
            this.textBoxEmployeeFirstName.Name = "textBoxEmployeeFirstName";
            this.textBoxEmployeeFirstName.Size = new System.Drawing.Size(114, 26);
            this.textBoxEmployeeFirstName.TabIndex = 0;
            // 
            // searchOrderTablesBindingNavigator
            // 
            this.searchOrderTablesBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.searchOrderTablesBindingNavigator.BindingSource = this.searchOrderTablesBindingSource;
            this.searchOrderTablesBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.searchOrderTablesBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.searchOrderTablesBindingNavigator.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.searchOrderTablesBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.searchOrderTablesBindingNavigatorSaveItem});
            this.searchOrderTablesBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.searchOrderTablesBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.searchOrderTablesBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.searchOrderTablesBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.searchOrderTablesBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.searchOrderTablesBindingNavigator.Name = "searchOrderTablesBindingNavigator";
            this.searchOrderTablesBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.searchOrderTablesBindingNavigator.Size = new System.Drawing.Size(1390, 33);
            this.searchOrderTablesBindingNavigator.TabIndex = 13;
            this.searchOrderTablesBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(54, 28);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 33);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 31);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 33);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 33);
            // 
            // searchOrderTablesBindingNavigatorSaveItem
            // 
            this.searchOrderTablesBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.searchOrderTablesBindingNavigatorSaveItem.Enabled = false;
            this.searchOrderTablesBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("searchOrderTablesBindingNavigatorSaveItem.Image")));
            this.searchOrderTablesBindingNavigatorSaveItem.Name = "searchOrderTablesBindingNavigatorSaveItem";
            this.searchOrderTablesBindingNavigatorSaveItem.Size = new System.Drawing.Size(34, 28);
            this.searchOrderTablesBindingNavigatorSaveItem.Text = "Save Data";
            // 
            // searchOrderTablesDataGridView
            // 
            this.searchOrderTablesDataGridView.AutoGenerateColumns = false;
            this.searchOrderTablesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.searchOrderTablesDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.searchOrderTablesDataGridView.DataSource = this.searchOrderTablesBindingSource;
            this.searchOrderTablesDataGridView.Location = new System.Drawing.Point(12, 36);
            this.searchOrderTablesDataGridView.Name = "searchOrderTablesDataGridView";
            this.searchOrderTablesDataGridView.RowHeadersWidth = 62;
            this.searchOrderTablesDataGridView.RowTemplate.Height = 28;
            this.searchOrderTablesDataGridView.Size = new System.Drawing.Size(1335, 299);
            this.searchOrderTablesDataGridView.TabIndex = 13;
            // 
            // buttonServiceName
            // 
            this.buttonServiceName.Location = new System.Drawing.Point(52, 77);
            this.buttonServiceName.Name = "buttonServiceName";
            this.buttonServiceName.Size = new System.Drawing.Size(195, 32);
            this.buttonServiceName.TabIndex = 6;
            this.buttonServiceName.Text = "Show Products";
            this.buttonServiceName.UseVisualStyleBackColor = true;
            this.buttonServiceName.Click += new System.EventHandler(this.buttonServiceName_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "OrderID";
            this.dataGridViewTextBoxColumn1.HeaderText = "OrderID";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Customer Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "Customer Name";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Products/Service Total";
            this.dataGridViewTextBoxColumn3.HeaderText = "Products/Service Total";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 150;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Product/Service Name";
            this.dataGridViewTextBoxColumn4.HeaderText = "Product/Service Name";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Quantity";
            this.dataGridViewTextBoxColumn5.HeaderText = "Quantity";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Employee Name";
            this.dataGridViewTextBoxColumn6.HeaderText = "Employee Name";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 150;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Type";
            this.dataGridViewTextBoxColumn7.HeaderText = "Type";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 150;
            // 
            // searchOrderTablesBindingSource
            // 
            this.searchOrderTablesBindingSource.DataMember = "SearchOrderTables";
            this.searchOrderTablesBindingSource.DataSource = this.barbershopDataSet;
            // 
            // barbershopDataSet
            // 
            this.barbershopDataSet.DataSetName = "barbershopDataSet";
            this.barbershopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CategoryTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.customerorderTableAdapter = null;
            this.tableAdapterManager.CustomerTableAdapter = null;
            this.tableAdapterManager.EmployeeTableAdapter = null;
            this.tableAdapterManager.order_productsTableAdapter = null;
            this.tableAdapterManager.order_servicesTableAdapter = null;
            this.tableAdapterManager.PersonTableAdapter = null;
            this.tableAdapterManager.productTableAdapter = null;
            this.tableAdapterManager.serviceTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Barber_Shop.barbershopDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VendorTableAdapter = null;
            // 
            // searchOrderTablesTableAdapter
            // 
            this.searchOrderTablesTableAdapter.ClearBeforeFill = true;
            // 
            // SearchOrders
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1390, 668);
            this.Controls.Add(this.searchOrderTablesDataGridView);
            this.Controls.Add(this.searchOrderTablesBindingNavigator);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonShowAll);
            this.Name = "SearchOrders";
            this.Text = "Search Orders";
            this.Load += new System.EventHandler(this.SearchOrders_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.searchOrderTablesBindingNavigator)).EndInit();
            this.searchOrderTablesBindingNavigator.ResumeLayout(false);
            this.searchOrderTablesBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.searchOrderTablesDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.searchOrderTablesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barbershopDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxSearchLast;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.TextBox textBoxSearchFirst;
        private System.Windows.Forms.Button buttonShowAll;
        private barbershopDataSet barbershopDataSet;
        private barbershopDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonSearchOrderNumber;
        private System.Windows.Forms.TextBox textBoxOrderID;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button buttonProductService;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button buttonSearchType;
        private System.Windows.Forms.TextBox textBoxType;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonTotal;
        private System.Windows.Forms.TextBox textBoxTotalAbove;
        private System.Windows.Forms.TextBox textBoxTotalBelow;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonSearchAbove;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.TextBox textBoxEmployeeLastName;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button buttonSearchEmployeeName;
        private System.Windows.Forms.TextBox textBoxEmployeeFirstName;
        private System.Windows.Forms.BindingSource searchOrderTablesBindingSource;
        private barbershopDataSetTableAdapters.SearchOrderTablesTableAdapter searchOrderTablesTableAdapter;
        private System.Windows.Forms.BindingNavigator searchOrderTablesBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton searchOrderTablesBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView searchOrderTablesDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Button buttonServiceName;
    }
}