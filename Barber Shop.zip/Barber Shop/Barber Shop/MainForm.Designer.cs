﻿namespace Barber_Shop
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonShowQueries = new System.Windows.Forms.Button();
            this.buttonShowTables = new System.Windows.Forms.Button();
            this.buttonDetails = new System.Windows.Forms.Button();
            this.buttonShowQueryTwo = new System.Windows.Forms.Button();
            this.buttonShowQueryThree = new System.Windows.Forms.Button();
            this.buttonSearchForm = new System.Windows.Forms.Button();
            this.buttonSearchOrders = new System.Windows.Forms.Button();
            this.buttonSearchWholesale = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonShowQueries
            // 
            this.buttonShowQueries.Location = new System.Drawing.Point(26, 28);
            this.buttonShowQueries.Name = "buttonShowQueries";
            this.buttonShowQueries.Size = new System.Drawing.Size(150, 57);
            this.buttonShowQueries.TabIndex = 44;
            this.buttonShowQueries.Text = "Show Queries Page 1";
            this.buttonShowQueries.UseVisualStyleBackColor = true;
            this.buttonShowQueries.Click += new System.EventHandler(this.buttonShowQueries_Click);
            // 
            // buttonShowTables
            // 
            this.buttonShowTables.Location = new System.Drawing.Point(52, 25);
            this.buttonShowTables.Name = "buttonShowTables";
            this.buttonShowTables.Size = new System.Drawing.Size(150, 38);
            this.buttonShowTables.TabIndex = 45;
            this.buttonShowTables.Text = "Show Tables";
            this.buttonShowTables.UseVisualStyleBackColor = true;
            this.buttonShowTables.Click += new System.EventHandler(this.buttonShowTables_Click);
            // 
            // buttonDetails
            // 
            this.buttonDetails.Location = new System.Drawing.Point(208, 25);
            this.buttonDetails.Name = "buttonDetails";
            this.buttonDetails.Size = new System.Drawing.Size(150, 38);
            this.buttonDetails.TabIndex = 46;
            this.buttonDetails.Text = "Show Details";
            this.buttonDetails.UseVisualStyleBackColor = true;
            this.buttonDetails.Click += new System.EventHandler(this.buttonDetails_Click);
            // 
            // buttonShowQueryTwo
            // 
            this.buttonShowQueryTwo.Location = new System.Drawing.Point(26, 91);
            this.buttonShowQueryTwo.Name = "buttonShowQueryTwo";
            this.buttonShowQueryTwo.Size = new System.Drawing.Size(150, 55);
            this.buttonShowQueryTwo.TabIndex = 47;
            this.buttonShowQueryTwo.Text = "Show Queries Page 2";
            this.buttonShowQueryTwo.UseVisualStyleBackColor = true;
            this.buttonShowQueryTwo.Click += new System.EventHandler(this.buttonShowQueryTwo_Click);
            // 
            // buttonShowQueryThree
            // 
            this.buttonShowQueryThree.Location = new System.Drawing.Point(26, 154);
            this.buttonShowQueryThree.Name = "buttonShowQueryThree";
            this.buttonShowQueryThree.Size = new System.Drawing.Size(150, 55);
            this.buttonShowQueryThree.TabIndex = 48;
            this.buttonShowQueryThree.Text = "Show Queries Page 3";
            this.buttonShowQueryThree.UseVisualStyleBackColor = true;
            this.buttonShowQueryThree.Click += new System.EventHandler(this.buttonShowQueryThree_Click);
            // 
            // buttonSearchForm
            // 
            this.buttonSearchForm.Location = new System.Drawing.Point(23, 29);
            this.buttonSearchForm.Name = "buttonSearchForm";
            this.buttonSearchForm.Size = new System.Drawing.Size(150, 50);
            this.buttonSearchForm.TabIndex = 49;
            this.buttonSearchForm.Text = "Search People";
            this.buttonSearchForm.UseVisualStyleBackColor = true;
            this.buttonSearchForm.Click += new System.EventHandler(this.buttonSearchForm_Click);
            // 
            // buttonSearchOrders
            // 
            this.buttonSearchOrders.Location = new System.Drawing.Point(23, 91);
            this.buttonSearchOrders.Name = "buttonSearchOrders";
            this.buttonSearchOrders.Size = new System.Drawing.Size(150, 50);
            this.buttonSearchOrders.TabIndex = 50;
            this.buttonSearchOrders.Text = "Search Orders";
            this.buttonSearchOrders.UseVisualStyleBackColor = true;
            this.buttonSearchOrders.Click += new System.EventHandler(this.buttonSearchOrders_Click);
            // 
            // buttonSearchWholesale
            // 
            this.buttonSearchWholesale.Location = new System.Drawing.Point(23, 153);
            this.buttonSearchWholesale.Name = "buttonSearchWholesale";
            this.buttonSearchWholesale.Size = new System.Drawing.Size(150, 56);
            this.buttonSearchWholesale.TabIndex = 51;
            this.buttonSearchWholesale.Text = "Search Wholesale";
            this.buttonSearchWholesale.UseVisualStyleBackColor = true;
            this.buttonSearchWholesale.Click += new System.EventHandler(this.buttonSearchWholesale_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonShowTables);
            this.groupBox1.Controls.Add(this.buttonDetails);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(24, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(412, 85);
            this.groupBox1.TabIndex = 52;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Barbershop Database";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonShowQueryTwo);
            this.groupBox2.Controls.Add(this.buttonShowQueries);
            this.groupBox2.Controls.Add(this.buttonShowQueryThree);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(24, 110);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(200, 226);
            this.groupBox2.TabIndex = 53;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Query Database";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.buttonSearchForm);
            this.groupBox3.Controls.Add(this.buttonSearchOrders);
            this.groupBox3.Controls.Add(this.buttonSearchWholesale);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox3.Location = new System.Drawing.Point(240, 110);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(196, 226);
            this.groupBox3.TabIndex = 54;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Search Database";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(24, 352);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(107, 38);
            this.button1.TabIndex = 55;
            this.button1.Text = "&Exit App";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(448, 407);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "MainForm";
            this.Text = "Barber Shop";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonShowQueries;
        private System.Windows.Forms.Button buttonShowTables;
        private System.Windows.Forms.Button buttonDetails;
        private System.Windows.Forms.Button buttonShowQueryTwo;
        private System.Windows.Forms.Button buttonShowQueryThree;
        private System.Windows.Forms.Button buttonSearchForm;
        private System.Windows.Forms.Button buttonSearchOrders;
        private System.Windows.Forms.Button buttonSearchWholesale;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button1;
    }
}

