﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barber_Shop
{
    public partial class SearchOrders : Form
    {
        public SearchOrders()
        {
            InitializeComponent();
        }

        private void SearchOrders_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'barbershopDataSet.SearchOrderTables' table. You can move, or remove it, as needed.
            this.searchOrderTablesTableAdapter.Fill(this.barbershopDataSet.SearchOrderTables);
            // TODO: This line of code loads data into the 'barbershopDataSet.SearchOrderTable' table. You can move, or remove it, as needed.
            this.searchOrderTablesTableAdapter.Fill(this.barbershopDataSet.SearchOrderTables);

        }

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            this.searchOrderTablesTableAdapter.FillByName(this.barbershopDataSet.SearchOrderTables, 
                textBoxSearchFirst.Text, textBoxSearchLast.Text);
        }

        private void buttonShowAll_Click(object sender, EventArgs e)
        {
            this.searchOrderTablesTableAdapter.Fill(this.barbershopDataSet.SearchOrderTables);
        }

        private void buttonSearchOrderNumber_Click(object sender, EventArgs e)
        {
            this.searchOrderTablesTableAdapter.FillByOrderID(this.barbershopDataSet.SearchOrderTables, 
                int.Parse(textBoxOrderID.Text));
        }

        private void buttonProductService_Click(object sender, EventArgs e)
        {
            this.searchOrderTablesTableAdapter.FillByService(this.barbershopDataSet.SearchOrderTables,
                "");
        }

        private void buttonSearchType_Click(object sender, EventArgs e)
        {
            this.searchOrderTablesTableAdapter.FillByQuantity(this.barbershopDataSet.SearchOrderTables,
                int.Parse(textBoxType.Text));
        }

        private void buttonTotal_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxTotalBelow.Text, out int numberValue) && numberValue > 0)
            {
                this.searchOrderTablesTableAdapter.FillByPrice(this.barbershopDataSet.SearchOrderTables,
                numberValue);
            }
            else
            {
                MessageBox.Show("Please enter an INT number more than zero.");
            }
            



        }

        private void buttonSearchEmployeeName_Click(object sender, EventArgs e)
        {
            this.searchOrderTablesTableAdapter.FillByEmployee(this.barbershopDataSet.SearchOrderTables,
                textBoxEmployeeFirstName.Text, textBoxEmployeeLastName.Text);
        }

        private void textBoxTotalAbove_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonSearchAbove_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxTotalBelow.Text, out int numberValue) && numberValue > 0)
            {
                this.searchOrderTablesTableAdapter.FilterTotalAbove(this.barbershopDataSet.SearchOrderTables,
                numberValue);
            }
            else
            {
                MessageBox.Show("Please enter an INT number more than zero.");
            }

            
        }

        private void buttonServiceName_Click(object sender, EventArgs e)
        {
            this.searchOrderTablesTableAdapter.FillByProduct(this.barbershopDataSet.SearchOrderTables,
                "");
        }
    }
}
