﻿namespace Barber_Shop
{


    partial class barbershopDataSet
    {
    }
}

namespace Barber_Shop.barbershopDataSetTableAdapters {
    
    
    public partial class SearchOrderTableTableAdapter {
    }
}
