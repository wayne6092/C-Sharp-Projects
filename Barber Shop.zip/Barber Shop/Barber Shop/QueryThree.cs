﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Barber_Shop
{
    public partial class QueryThree : Form
    {
        public QueryThree()
        {
            InitializeComponent();
        }

        private void QueryThree_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'barbershopDataSet.ProfitOverThree' table. You can move, or remove it, as needed.
            this.profitOverThreeTableAdapter.FillTable(this.barbershopDataSet.ProfitOverThree);
            // TODO: This line of code loads data into the 'barbershopDataSet.PossibleProfit' table. You can move, or remove it, as needed.
            this.possibleProfitTableAdapter.FillTable(this.barbershopDataSet.PossibleProfit);

        }

        private void buttonStartQuery_Click(object sender, EventArgs e)
        {
            this.possibleProfitTableAdapter.TotalProfitNearby(this.barbershopDataSet.PossibleProfit);
        }

        private void buttonResetTable_Click(object sender, EventArgs e)
        {
            this.possibleProfitTableAdapter.FillTable(this.barbershopDataSet.PossibleProfit);
        }

        private void buttonStartQueryTwo_Click(object sender, EventArgs e)
        {
            this.profitOverThreeTableAdapter.ProfitOver3(this.barbershopDataSet.ProfitOverThree);
        }

        private void buttonResetTableTwo_Click(object sender, EventArgs e)
        {
            this.profitOverThreeTableAdapter.FillTable(this.barbershopDataSet.ProfitOverThree);
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
