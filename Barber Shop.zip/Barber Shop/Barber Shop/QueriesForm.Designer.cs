﻿namespace Barber_Shop
{
    partial class queries
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label product_NameLabel;
            System.Windows.Forms.Label total_SoldLabel;
            System.Windows.Forms.Label quantityLabel;
            System.Windows.Forms.Label first_NameLabel;
            System.Windows.Forms.Label last_NameLabel;
            System.Windows.Forms.Label product_Service_NameLabel;
            System.Windows.Forms.Label descriptionLabel;
            System.Windows.Forms.Label first_NameLabel1;
            System.Windows.Forms.Label last_NameLabel1;
            System.Windows.Forms.Label product_Service_NameLabel1;
            System.Windows.Forms.Label paymentLabel;
            System.Windows.Forms.Label priceLabel;
            System.Windows.Forms.Label orderDateLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(queries));
            this.totalQueryBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.totalQueryBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.barbershopDataSet = new Barber_Shop.barbershopDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.totalQueryBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.buttonResetTotalTable = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonQueryOne = new System.Windows.Forms.Button();
            this.product_NameTextBox = new System.Windows.Forms.TextBox();
            this.total_SoldTextBox = new System.Windows.Forms.TextBox();
            this.quantityTextBox = new System.Windows.Forms.TextBox();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.toolStripContainer2 = new System.Windows.Forms.ToolStripContainer();
            this.label5 = new System.Windows.Forms.Label();
            this.buttonResetQueryTwo = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.first_NameTextBox = new System.Windows.Forms.TextBox();
            this.shampooServiceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.last_NameTextBox = new System.Windows.Forms.TextBox();
            this.product_Service_NameTextBox = new System.Windows.Forms.TextBox();
            this.descriptionTextBox = new System.Windows.Forms.TextBox();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.label2 = new System.Windows.Forms.Label();
            this.toolStripContainer3 = new System.Windows.Forms.ToolStripContainer();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.buttonResetQueryThree = new System.Windows.Forms.Button();
            this.buttonQueryThree = new System.Windows.Forms.Button();
            this.first_NameTextBox1 = new System.Windows.Forms.TextBox();
            this.paymentTypesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.last_NameTextBox1 = new System.Windows.Forms.TextBox();
            this.product_Service_NameTextBox1 = new System.Windows.Forms.TextBox();
            this.paymentTextBox = new System.Windows.Forms.TextBox();
            this.priceTextBox = new System.Windows.Forms.TextBox();
            this.orderDateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.bindingNavigator2 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.totalQueryTableAdapter = new Barber_Shop.barbershopDataSetTableAdapters.TotalQueryTableAdapter();
            this.tableAdapterManager = new Barber_Shop.barbershopDataSetTableAdapters.TableAdapterManager();
            this.shampooServiceTableAdapter = new Barber_Shop.barbershopDataSetTableAdapters.ShampooServiceTableAdapter();
            this.paymentTypesTableAdapter = new Barber_Shop.barbershopDataSetTableAdapters.PaymentTypesTableAdapter();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            product_NameLabel = new System.Windows.Forms.Label();
            total_SoldLabel = new System.Windows.Forms.Label();
            quantityLabel = new System.Windows.Forms.Label();
            first_NameLabel = new System.Windows.Forms.Label();
            last_NameLabel = new System.Windows.Forms.Label();
            product_Service_NameLabel = new System.Windows.Forms.Label();
            descriptionLabel = new System.Windows.Forms.Label();
            first_NameLabel1 = new System.Windows.Forms.Label();
            last_NameLabel1 = new System.Windows.Forms.Label();
            product_Service_NameLabel1 = new System.Windows.Forms.Label();
            paymentLabel = new System.Windows.Forms.Label();
            priceLabel = new System.Windows.Forms.Label();
            orderDateLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.totalQueryBindingNavigator)).BeginInit();
            this.totalQueryBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.totalQueryBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barbershopDataSet)).BeginInit();
            this.toolStripContainer1.ContentPanel.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            this.toolStripContainer2.ContentPanel.SuspendLayout();
            this.toolStripContainer2.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shampooServiceBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            this.toolStripContainer3.ContentPanel.SuspendLayout();
            this.toolStripContainer3.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paymentTypesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator2)).BeginInit();
            this.bindingNavigator2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // product_NameLabel
            // 
            product_NameLabel.AutoSize = true;
            product_NameLabel.Location = new System.Drawing.Point(39, 17);
            product_NameLabel.Name = "product_NameLabel";
            product_NameLabel.Size = new System.Drawing.Size(114, 20);
            product_NameLabel.TabIndex = 59;
            product_NameLabel.Text = "Product Name:";
            // 
            // total_SoldLabel
            // 
            total_SoldLabel.AutoSize = true;
            total_SoldLabel.Location = new System.Drawing.Point(39, 48);
            total_SoldLabel.Name = "total_SoldLabel";
            total_SoldLabel.Size = new System.Drawing.Size(84, 20);
            total_SoldLabel.TabIndex = 61;
            total_SoldLabel.Text = "Total Sold:";
            // 
            // quantityLabel
            // 
            quantityLabel.AutoSize = true;
            quantityLabel.Location = new System.Drawing.Point(39, 81);
            quantityLabel.Name = "quantityLabel";
            quantityLabel.Size = new System.Drawing.Size(72, 20);
            quantityLabel.TabIndex = 63;
            quantityLabel.Text = "Quantity:";
            // 
            // first_NameLabel
            // 
            first_NameLabel.AutoSize = true;
            first_NameLabel.Location = new System.Drawing.Point(15, 12);
            first_NameLabel.Name = "first_NameLabel";
            first_NameLabel.Size = new System.Drawing.Size(90, 20);
            first_NameLabel.TabIndex = 0;
            first_NameLabel.Text = "First Name:";
            // 
            // last_NameLabel
            // 
            last_NameLabel.AutoSize = true;
            last_NameLabel.Location = new System.Drawing.Point(15, 45);
            last_NameLabel.Name = "last_NameLabel";
            last_NameLabel.Size = new System.Drawing.Size(90, 20);
            last_NameLabel.TabIndex = 2;
            last_NameLabel.Text = "Last Name:";
            // 
            // product_Service_NameLabel
            // 
            product_Service_NameLabel.AutoSize = true;
            product_Service_NameLabel.Location = new System.Drawing.Point(15, 77);
            product_Service_NameLabel.Name = "product_Service_NameLabel";
            product_Service_NameLabel.Size = new System.Drawing.Size(170, 20);
            product_Service_NameLabel.TabIndex = 4;
            product_Service_NameLabel.Text = "Product/Service Name:";
            // 
            // descriptionLabel
            // 
            descriptionLabel.AutoSize = true;
            descriptionLabel.Location = new System.Drawing.Point(15, 109);
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new System.Drawing.Size(93, 20);
            descriptionLabel.TabIndex = 6;
            descriptionLabel.Text = "Description:";
            // 
            // first_NameLabel1
            // 
            first_NameLabel1.AutoSize = true;
            first_NameLabel1.Location = new System.Drawing.Point(18, 25);
            first_NameLabel1.Name = "first_NameLabel1";
            first_NameLabel1.Size = new System.Drawing.Size(90, 20);
            first_NameLabel1.TabIndex = 0;
            first_NameLabel1.Text = "First Name:";
            // 
            // last_NameLabel1
            // 
            last_NameLabel1.AutoSize = true;
            last_NameLabel1.Location = new System.Drawing.Point(18, 57);
            last_NameLabel1.Name = "last_NameLabel1";
            last_NameLabel1.Size = new System.Drawing.Size(90, 20);
            last_NameLabel1.TabIndex = 2;
            last_NameLabel1.Text = "Last Name:";
            // 
            // product_Service_NameLabel1
            // 
            product_Service_NameLabel1.AutoSize = true;
            product_Service_NameLabel1.Location = new System.Drawing.Point(18, 89);
            product_Service_NameLabel1.Name = "product_Service_NameLabel1";
            product_Service_NameLabel1.Size = new System.Drawing.Size(170, 20);
            product_Service_NameLabel1.TabIndex = 4;
            product_Service_NameLabel1.Text = "Product/Service Name:";
            // 
            // paymentLabel
            // 
            paymentLabel.AutoSize = true;
            paymentLabel.Location = new System.Drawing.Point(18, 122);
            paymentLabel.Name = "paymentLabel";
            paymentLabel.Size = new System.Drawing.Size(75, 20);
            paymentLabel.TabIndex = 6;
            paymentLabel.Text = "Payment:";
            // 
            // priceLabel
            // 
            priceLabel.AutoSize = true;
            priceLabel.Location = new System.Drawing.Point(18, 152);
            priceLabel.Name = "priceLabel";
            priceLabel.Size = new System.Drawing.Size(47, 20);
            priceLabel.TabIndex = 8;
            priceLabel.Text = "price:";
            // 
            // orderDateLabel
            // 
            orderDateLabel.AutoSize = true;
            orderDateLabel.Location = new System.Drawing.Point(18, 186);
            orderDateLabel.Name = "orderDateLabel";
            orderDateLabel.Size = new System.Drawing.Size(92, 20);
            orderDateLabel.TabIndex = 10;
            orderDateLabel.Text = "Order Date:";
            // 
            // totalQueryBindingNavigator
            // 
            this.totalQueryBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.totalQueryBindingNavigator.BindingSource = this.totalQueryBindingSource;
            this.totalQueryBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.totalQueryBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.totalQueryBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.totalQueryBindingNavigator.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.totalQueryBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.totalQueryBindingNavigatorSaveItem});
            this.totalQueryBindingNavigator.Location = new System.Drawing.Point(4, 0);
            this.totalQueryBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.totalQueryBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.totalQueryBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.totalQueryBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.totalQueryBindingNavigator.Name = "totalQueryBindingNavigator";
            this.totalQueryBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.totalQueryBindingNavigator.Size = new System.Drawing.Size(382, 33);
            this.totalQueryBindingNavigator.TabIndex = 49;
            this.totalQueryBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // totalQueryBindingSource
            // 
            this.totalQueryBindingSource.DataMember = "TotalQuery";
            this.totalQueryBindingSource.DataSource = this.barbershopDataSet;
            // 
            // barbershopDataSet
            // 
            this.barbershopDataSet.DataSetName = "barbershopDataSet";
            this.barbershopDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(54, 28);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 33);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 31);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 33);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 33);
            // 
            // totalQueryBindingNavigatorSaveItem
            // 
            this.totalQueryBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.totalQueryBindingNavigatorSaveItem.Enabled = false;
            this.totalQueryBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("totalQueryBindingNavigatorSaveItem.Image")));
            this.totalQueryBindingNavigatorSaveItem.Name = "totalQueryBindingNavigatorSaveItem";
            this.totalQueryBindingNavigatorSaveItem.Size = new System.Drawing.Size(34, 28);
            this.totalQueryBindingNavigatorSaveItem.Text = "Save Data";
            // 
            // buttonResetTotalTable
            // 
            this.buttonResetTotalTable.Location = new System.Drawing.Point(570, 15);
            this.buttonResetTotalTable.Name = "buttonResetTotalTable";
            this.buttonResetTotalTable.Size = new System.Drawing.Size(165, 38);
            this.buttonResetTotalTable.TabIndex = 51;
            this.buttonResetTotalTable.Text = "Reset Table";
            this.buttonResetTotalTable.UseVisualStyleBackColor = true;
            this.buttonResetTotalTable.Click += new System.EventHandler(this.buttonResetTotalTable_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(2, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(633, 17);
            this.label1.TabIndex = 52;
            this.label1.Text = "Get total profits from products sold over the past 6 months where price more than" +
    " $15";
            // 
            // buttonQueryOne
            // 
            this.buttonQueryOne.Location = new System.Drawing.Point(399, 15);
            this.buttonQueryOne.Name = "buttonQueryOne";
            this.buttonQueryOne.Size = new System.Drawing.Size(165, 38);
            this.buttonQueryOne.TabIndex = 48;
            this.buttonQueryOne.Text = "Start Query";
            this.buttonQueryOne.UseVisualStyleBackColor = true;
            this.buttonQueryOne.Click += new System.EventHandler(this.buttonQueryOne_Click);
            // 
            // product_NameTextBox
            // 
            this.product_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.totalQueryBindingSource, "Product Name", true));
            this.product_NameTextBox.Location = new System.Drawing.Point(182, 15);
            this.product_NameTextBox.Name = "product_NameTextBox";
            this.product_NameTextBox.Size = new System.Drawing.Size(210, 26);
            this.product_NameTextBox.TabIndex = 60;
            // 
            // total_SoldTextBox
            // 
            this.total_SoldTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.totalQueryBindingSource, "Total Sold", true));
            this.total_SoldTextBox.Location = new System.Drawing.Point(182, 48);
            this.total_SoldTextBox.Name = "total_SoldTextBox";
            this.total_SoldTextBox.Size = new System.Drawing.Size(210, 26);
            this.total_SoldTextBox.TabIndex = 62;
            // 
            // quantityTextBox
            // 
            this.quantityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.totalQueryBindingSource, "Quantity", true));
            this.quantityTextBox.Location = new System.Drawing.Point(182, 78);
            this.quantityTextBox.Name = "quantityTextBox";
            this.quantityTextBox.Size = new System.Drawing.Size(210, 26);
            this.quantityTextBox.TabIndex = 64;
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label7);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.label4);
            this.toolStripContainer1.ContentPanel.Controls.Add(product_NameLabel);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.quantityTextBox);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.product_NameTextBox);
            this.toolStripContainer1.ContentPanel.Controls.Add(quantityLabel);
            this.toolStripContainer1.ContentPanel.Controls.Add(total_SoldLabel);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.total_SoldTextBox);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.buttonQueryOne);
            this.toolStripContainer1.ContentPanel.Controls.Add(this.buttonResetTotalTable);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(810, 117);
            this.toolStripContainer1.Location = new System.Drawing.Point(6, 45);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(810, 150);
            this.toolStripContainer1.TabIndex = 65;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.totalQueryBindingNavigator);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(399, 77);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(266, 17);
            this.label7.TabIndex = 66;
            this.label7.Text = "+ Group by clause + having clause*";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(399, 57);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(248, 17);
            this.label4.TabIndex = 65;
            this.label4.Text = "*Multi-Table Join + Where clause";
            // 
            // toolStripContainer2
            // 
            // 
            // toolStripContainer2.ContentPanel
            // 
            this.toolStripContainer2.ContentPanel.AutoScroll = true;
            this.toolStripContainer2.ContentPanel.Controls.Add(this.label5);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.buttonResetQueryTwo);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.button1);
            this.toolStripContainer2.ContentPanel.Controls.Add(first_NameLabel);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.first_NameTextBox);
            this.toolStripContainer2.ContentPanel.Controls.Add(last_NameLabel);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.last_NameTextBox);
            this.toolStripContainer2.ContentPanel.Controls.Add(product_Service_NameLabel);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.product_Service_NameTextBox);
            this.toolStripContainer2.ContentPanel.Controls.Add(descriptionLabel);
            this.toolStripContainer2.ContentPanel.Controls.Add(this.descriptionTextBox);
            this.toolStripContainer2.ContentPanel.Size = new System.Drawing.Size(810, 160);
            this.toolStripContainer2.Location = new System.Drawing.Point(5, 44);
            this.toolStripContainer2.Name = "toolStripContainer2";
            this.toolStripContainer2.Size = new System.Drawing.Size(810, 193);
            this.toolStripContainer2.TabIndex = 73;
            this.toolStripContainer2.Text = "toolStripContainer2";
            // 
            // toolStripContainer2.TopToolStripPanel
            // 
            this.toolStripContainer2.TopToolStripPanel.Controls.Add(this.bindingNavigator1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(421, 83);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(263, 17);
            this.label5.TabIndex = 54;
            this.label5.Text = "*Multi-Table Join with set operator*";
            // 
            // buttonResetQueryTwo
            // 
            this.buttonResetQueryTwo.Location = new System.Drawing.Point(529, 10);
            this.buttonResetQueryTwo.Name = "buttonResetQueryTwo";
            this.buttonResetQueryTwo.Size = new System.Drawing.Size(100, 55);
            this.buttonResetQueryTwo.TabIndex = 53;
            this.buttonResetQueryTwo.Text = "Reset Table";
            this.buttonResetQueryTwo.UseVisualStyleBackColor = true;
            this.buttonResetQueryTwo.Click += new System.EventHandler(this.buttonResetQueryTwo_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(418, 9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(100, 56);
            this.button1.TabIndex = 49;
            this.button1.Text = "Start Query";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // first_NameTextBox
            // 
            this.first_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shampooServiceBindingSource, "First Name", true));
            this.first_NameTextBox.Location = new System.Drawing.Point(202, 9);
            this.first_NameTextBox.Name = "first_NameTextBox";
            this.first_NameTextBox.Size = new System.Drawing.Size(210, 26);
            this.first_NameTextBox.TabIndex = 1;
            // 
            // shampooServiceBindingSource
            // 
            this.shampooServiceBindingSource.DataMember = "ShampooService";
            this.shampooServiceBindingSource.DataSource = this.barbershopDataSet;
            // 
            // last_NameTextBox
            // 
            this.last_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shampooServiceBindingSource, "Last Name", true));
            this.last_NameTextBox.Location = new System.Drawing.Point(202, 42);
            this.last_NameTextBox.Name = "last_NameTextBox";
            this.last_NameTextBox.Size = new System.Drawing.Size(210, 26);
            this.last_NameTextBox.TabIndex = 3;
            // 
            // product_Service_NameTextBox
            // 
            this.product_Service_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shampooServiceBindingSource, "Product/Service Name", true));
            this.product_Service_NameTextBox.Location = new System.Drawing.Point(202, 74);
            this.product_Service_NameTextBox.Name = "product_Service_NameTextBox";
            this.product_Service_NameTextBox.Size = new System.Drawing.Size(210, 26);
            this.product_Service_NameTextBox.TabIndex = 5;
            // 
            // descriptionTextBox
            // 
            this.descriptionTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shampooServiceBindingSource, "Description", true));
            this.descriptionTextBox.Location = new System.Drawing.Point(202, 106);
            this.descriptionTextBox.Name = "descriptionTextBox";
            this.descriptionTextBox.Size = new System.Drawing.Size(210, 26);
            this.descriptionTextBox.TabIndex = 7;
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = this.toolStripButton1;
            this.bindingNavigator1.BindingSource = this.shampooServiceBindingSource;
            this.bindingNavigator1.CountItem = this.toolStripLabel1;
            this.bindingNavigator1.DeleteItem = this.toolStripButton2;
            this.bindingNavigator1.Dock = System.Windows.Forms.DockStyle.None;
            this.bindingNavigator1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator1,
            this.toolStripTextBox1,
            this.toolStripLabel1,
            this.toolStripSeparator2,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripSeparator3,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton7});
            this.bindingNavigator1.Location = new System.Drawing.Point(4, 0);
            this.bindingNavigator1.MoveFirstItem = this.toolStripButton3;
            this.bindingNavigator1.MoveLastItem = this.toolStripButton6;
            this.bindingNavigator1.MoveNextItem = this.toolStripButton5;
            this.bindingNavigator1.MovePreviousItem = this.toolStripButton4;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.toolStripTextBox1;
            this.bindingNavigator1.Size = new System.Drawing.Size(382, 33);
            this.bindingNavigator1.TabIndex = 49;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.RightToLeftAutoMirrorImage = true;
            this.toolStripButton1.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton1.Text = "Add new";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(54, 28);
            this.toolStripLabel1.Text = "of {0}";
            this.toolStripLabel1.ToolTipText = "Total number of items";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripButton2.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton2.Text = "Delete";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.RightToLeftAutoMirrorImage = true;
            this.toolStripButton3.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton3.Text = "Move first";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.RightToLeftAutoMirrorImage = true;
            this.toolStripButton4.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton4.Text = "Move previous";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AccessibleName = "Position";
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(50, 31);
            this.toolStripTextBox1.Text = "0";
            this.toolStripTextBox1.ToolTipText = "Current position";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.RightToLeftAutoMirrorImage = true;
            this.toolStripButton5.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton5.Text = "Move next";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.RightToLeftAutoMirrorImage = true;
            this.toolStripButton6.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton6.Text = "Move last";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Enabled = false;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton7.Text = "Save Data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(2, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(601, 17);
            this.label2.TabIndex = 74;
            this.label2.Text = "Find employees who performed a service, also find employees who sold shampoo.";
            // 
            // toolStripContainer3
            // 
            // 
            // toolStripContainer3.ContentPanel
            // 
            this.toolStripContainer3.ContentPanel.AutoScroll = true;
            this.toolStripContainer3.ContentPanel.Controls.Add(this.label8);
            this.toolStripContainer3.ContentPanel.Controls.Add(this.label6);
            this.toolStripContainer3.ContentPanel.Controls.Add(this.button2);
            this.toolStripContainer3.ContentPanel.Controls.Add(this.buttonResetQueryThree);
            this.toolStripContainer3.ContentPanel.Controls.Add(this.buttonQueryThree);
            this.toolStripContainer3.ContentPanel.Controls.Add(first_NameLabel1);
            this.toolStripContainer3.ContentPanel.Controls.Add(this.first_NameTextBox1);
            this.toolStripContainer3.ContentPanel.Controls.Add(last_NameLabel1);
            this.toolStripContainer3.ContentPanel.Controls.Add(this.last_NameTextBox1);
            this.toolStripContainer3.ContentPanel.Controls.Add(product_Service_NameLabel1);
            this.toolStripContainer3.ContentPanel.Controls.Add(this.product_Service_NameTextBox1);
            this.toolStripContainer3.ContentPanel.Controls.Add(paymentLabel);
            this.toolStripContainer3.ContentPanel.Controls.Add(this.paymentTextBox);
            this.toolStripContainer3.ContentPanel.Controls.Add(priceLabel);
            this.toolStripContainer3.ContentPanel.Controls.Add(this.priceTextBox);
            this.toolStripContainer3.ContentPanel.Controls.Add(orderDateLabel);
            this.toolStripContainer3.ContentPanel.Controls.Add(this.orderDateDateTimePicker);
            this.toolStripContainer3.ContentPanel.Size = new System.Drawing.Size(810, 241);
            this.toolStripContainer3.ContentPanel.Load += new System.EventHandler(this.toolStripContainer3_ContentPanel_Load);
            this.toolStripContainer3.Location = new System.Drawing.Point(6, 46);
            this.toolStripContainer3.Name = "toolStripContainer3";
            this.toolStripContainer3.Size = new System.Drawing.Size(810, 274);
            this.toolStripContainer3.TabIndex = 75;
            this.toolStripContainer3.Text = "toolStripContainer3";
            // 
            // toolStripContainer3.TopToolStripPanel
            // 
            this.toolStripContainer3.TopToolStripPanel.Controls.Add(this.bindingNavigator2);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(490, 119);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(127, 17);
            this.label8.TabIndex = 55;
            this.label8.Text = "+ Where clause*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(486, 95);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(257, 17);
            this.label6.TabIndex = 54;
            this.label6.Text = "*Multi-Table Join with set operator";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(595, 21);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(100, 59);
            this.button2.TabIndex = 53;
            this.button2.Text = "Debit";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonResetQueryThree
            // 
            this.buttonResetQueryThree.Location = new System.Drawing.Point(701, 22);
            this.buttonResetQueryThree.Name = "buttonResetQueryThree";
            this.buttonResetQueryThree.Size = new System.Drawing.Size(100, 57);
            this.buttonResetQueryThree.TabIndex = 52;
            this.buttonResetQueryThree.Text = "Reset Table";
            this.buttonResetQueryThree.UseVisualStyleBackColor = true;
            this.buttonResetQueryThree.Click += new System.EventHandler(this.buttonResetQueryThree_Click);
            // 
            // buttonQueryThree
            // 
            this.buttonQueryThree.Location = new System.Drawing.Point(489, 21);
            this.buttonQueryThree.Name = "buttonQueryThree";
            this.buttonQueryThree.Size = new System.Drawing.Size(100, 58);
            this.buttonQueryThree.TabIndex = 50;
            this.buttonQueryThree.Text = "Cash + Card";
            this.buttonQueryThree.UseVisualStyleBackColor = true;
            this.buttonQueryThree.Click += new System.EventHandler(this.buttonQueryThree_Click);
            // 
            // first_NameTextBox1
            // 
            this.first_NameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paymentTypesBindingSource, "First Name", true));
            this.first_NameTextBox1.Location = new System.Drawing.Point(218, 22);
            this.first_NameTextBox1.Name = "first_NameTextBox1";
            this.first_NameTextBox1.Size = new System.Drawing.Size(265, 26);
            this.first_NameTextBox1.TabIndex = 1;
            // 
            // paymentTypesBindingSource
            // 
            this.paymentTypesBindingSource.DataMember = "PaymentTypes";
            this.paymentTypesBindingSource.DataSource = this.barbershopDataSet;
            // 
            // last_NameTextBox1
            // 
            this.last_NameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paymentTypesBindingSource, "Last Name", true));
            this.last_NameTextBox1.Location = new System.Drawing.Point(218, 54);
            this.last_NameTextBox1.Name = "last_NameTextBox1";
            this.last_NameTextBox1.Size = new System.Drawing.Size(265, 26);
            this.last_NameTextBox1.TabIndex = 3;
            // 
            // product_Service_NameTextBox1
            // 
            this.product_Service_NameTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paymentTypesBindingSource, "Product/Service Name", true));
            this.product_Service_NameTextBox1.Location = new System.Drawing.Point(218, 86);
            this.product_Service_NameTextBox1.Name = "product_Service_NameTextBox1";
            this.product_Service_NameTextBox1.Size = new System.Drawing.Size(265, 26);
            this.product_Service_NameTextBox1.TabIndex = 5;
            // 
            // paymentTextBox
            // 
            this.paymentTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paymentTypesBindingSource, "Payment", true));
            this.paymentTextBox.Location = new System.Drawing.Point(218, 119);
            this.paymentTextBox.Name = "paymentTextBox";
            this.paymentTextBox.Size = new System.Drawing.Size(265, 26);
            this.paymentTextBox.TabIndex = 7;
            // 
            // priceTextBox
            // 
            this.priceTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.paymentTypesBindingSource, "price", true));
            this.priceTextBox.Location = new System.Drawing.Point(218, 149);
            this.priceTextBox.Name = "priceTextBox";
            this.priceTextBox.Size = new System.Drawing.Size(265, 26);
            this.priceTextBox.TabIndex = 9;
            // 
            // orderDateDateTimePicker
            // 
            this.orderDateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.paymentTypesBindingSource, "OrderDate", true));
            this.orderDateDateTimePicker.Location = new System.Drawing.Point(218, 182);
            this.orderDateDateTimePicker.Name = "orderDateDateTimePicker";
            this.orderDateDateTimePicker.Size = new System.Drawing.Size(265, 26);
            this.orderDateDateTimePicker.TabIndex = 11;
            // 
            // bindingNavigator2
            // 
            this.bindingNavigator2.AddNewItem = this.toolStripButton8;
            this.bindingNavigator2.BindingSource = this.paymentTypesBindingSource;
            this.bindingNavigator2.CountItem = this.toolStripLabel2;
            this.bindingNavigator2.DeleteItem = this.toolStripButton9;
            this.bindingNavigator2.Dock = System.Windows.Forms.DockStyle.None;
            this.bindingNavigator2.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.bindingNavigator2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton10,
            this.toolStripButton11,
            this.toolStripSeparator4,
            this.toolStripTextBox2,
            this.toolStripLabel2,
            this.toolStripSeparator5,
            this.toolStripButton12,
            this.toolStripButton13,
            this.toolStripSeparator6,
            this.toolStripButton8,
            this.toolStripButton9,
            this.toolStripButton14});
            this.bindingNavigator2.Location = new System.Drawing.Point(4, 0);
            this.bindingNavigator2.MoveFirstItem = this.toolStripButton10;
            this.bindingNavigator2.MoveLastItem = this.toolStripButton13;
            this.bindingNavigator2.MoveNextItem = this.toolStripButton12;
            this.bindingNavigator2.MovePreviousItem = this.toolStripButton11;
            this.bindingNavigator2.Name = "bindingNavigator2";
            this.bindingNavigator2.Padding = new System.Windows.Forms.Padding(0, 0, 1, 0);
            this.bindingNavigator2.PositionItem = this.toolStripTextBox2;
            this.bindingNavigator2.Size = new System.Drawing.Size(366, 33);
            this.bindingNavigator2.TabIndex = 49;
            this.bindingNavigator2.Text = "bindingNavigator2";
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.RightToLeftAutoMirrorImage = true;
            this.toolStripButton8.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton8.Text = "Add new";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(54, 28);
            this.toolStripLabel2.Text = "of {0}";
            this.toolStripLabel2.ToolTipText = "Total number of items";
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.RightToLeftAutoMirrorImage = true;
            this.toolStripButton9.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton9.Text = "Delete";
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.RightToLeftAutoMirrorImage = true;
            this.toolStripButton10.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton10.Text = "Move first";
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton11.Image")));
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.RightToLeftAutoMirrorImage = true;
            this.toolStripButton11.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton11.Text = "Move previous";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.AccessibleName = "Position";
            this.toolStripTextBox2.AutoSize = false;
            this.toolStripTextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(35, 31);
            this.toolStripTextBox2.Text = "0";
            this.toolStripTextBox2.ToolTipText = "Current position";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.RightToLeftAutoMirrorImage = true;
            this.toolStripButton12.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton12.Text = "Move next";
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.RightToLeftAutoMirrorImage = true;
            this.toolStripButton13.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton13.Text = "Move last";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 33);
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton14.Enabled = false;
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.Size = new System.Drawing.Size(34, 28);
            this.toolStripButton14.Text = "Save Data";
            // 
            // totalQueryTableAdapter
            // 
            this.totalQueryTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CategoryTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.customerorderTableAdapter = null;
            this.tableAdapterManager.CustomerTableAdapter = null;
            this.tableAdapterManager.EmployeeTableAdapter = null;
            this.tableAdapterManager.order_productsTableAdapter = null;
            this.tableAdapterManager.order_servicesTableAdapter = null;
            this.tableAdapterManager.PersonTableAdapter = null;
            this.tableAdapterManager.productTableAdapter = null;
            this.tableAdapterManager.serviceTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Barber_Shop.barbershopDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VendorTableAdapter = null;
            // 
            // shampooServiceTableAdapter
            // 
            this.shampooServiceTableAdapter.ClearBeforeFill = true;
            // 
            // paymentTypesTableAdapter
            // 
            this.paymentTypesTableAdapter.ClearBeforeFill = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(5, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(685, 17);
            this.label3.TabIndex = 76;
            this.label3.Text = "Get employees who took customer orders where order was paid with cash/card or deb" +
    "it/check";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.toolStripContainer1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(9, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(822, 204);
            this.groupBox1.TabIndex = 77;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Query #1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.toolStripContainer2);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Location = new System.Drawing.Point(9, 219);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(822, 246);
            this.groupBox2.TabIndex = 78;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Query #2";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.toolStripContainer3);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Location = new System.Drawing.Point(9, 465);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(822, 326);
            this.groupBox3.TabIndex = 79;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Query #3";
            // 
            // queries
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(850, 803);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "queries";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QueriesForm";
            this.Load += new System.EventHandler(this.QueriesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.totalQueryBindingNavigator)).EndInit();
            this.totalQueryBindingNavigator.ResumeLayout(false);
            this.totalQueryBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.totalQueryBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barbershopDataSet)).EndInit();
            this.toolStripContainer1.ContentPanel.ResumeLayout(false);
            this.toolStripContainer1.ContentPanel.PerformLayout();
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            this.toolStripContainer2.ContentPanel.ResumeLayout(false);
            this.toolStripContainer2.ContentPanel.PerformLayout();
            this.toolStripContainer2.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer2.TopToolStripPanel.PerformLayout();
            this.toolStripContainer2.ResumeLayout(false);
            this.toolStripContainer2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shampooServiceBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            this.toolStripContainer3.ContentPanel.ResumeLayout(false);
            this.toolStripContainer3.ContentPanel.PerformLayout();
            this.toolStripContainer3.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer3.TopToolStripPanel.PerformLayout();
            this.toolStripContainer3.ResumeLayout(false);
            this.toolStripContainer3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.paymentTypesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator2)).EndInit();
            this.bindingNavigator2.ResumeLayout(false);
            this.bindingNavigator2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private barbershopDataSet barbershopDataSet;
        private System.Windows.Forms.BindingSource totalQueryBindingSource;
        private barbershopDataSetTableAdapters.TotalQueryTableAdapter totalQueryTableAdapter;
        private barbershopDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator totalQueryBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton totalQueryBindingNavigatorSaveItem;
        private System.Windows.Forms.Button buttonResetTotalTable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonQueryOne;
        private System.Windows.Forms.TextBox product_NameTextBox;
        private System.Windows.Forms.TextBox total_SoldTextBox;
        private System.Windows.Forms.TextBox quantityTextBox;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.ToolStripContainer toolStripContainer2;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.BindingSource shampooServiceBindingSource;
        private barbershopDataSetTableAdapters.ShampooServiceTableAdapter shampooServiceTableAdapter;
        private System.Windows.Forms.TextBox first_NameTextBox;
        private System.Windows.Forms.TextBox last_NameTextBox;
        private System.Windows.Forms.TextBox product_Service_NameTextBox;
        private System.Windows.Forms.TextBox descriptionTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripContainer toolStripContainer3;
        private System.Windows.Forms.BindingNavigator bindingNavigator2;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.BindingSource paymentTypesBindingSource;
        private barbershopDataSetTableAdapters.PaymentTypesTableAdapter paymentTypesTableAdapter;
        private System.Windows.Forms.TextBox first_NameTextBox1;
        private System.Windows.Forms.TextBox last_NameTextBox1;
        private System.Windows.Forms.TextBox product_Service_NameTextBox1;
        private System.Windows.Forms.TextBox paymentTextBox;
        private System.Windows.Forms.TextBox priceTextBox;
        private System.Windows.Forms.DateTimePicker orderDateDateTimePicker;
        private System.Windows.Forms.Button buttonQueryThree;
        private System.Windows.Forms.Button buttonResetQueryThree;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonResetQueryTwo;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}