namespace Barbershop_Linq
{
    partial class DataClassesDataContext
    {
    }
}