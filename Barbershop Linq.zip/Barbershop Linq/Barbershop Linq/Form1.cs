﻿using Barbershop_Linq.testDataSetTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.Linq;
using System.Data.Linq.Mapping;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Barbershop_Linq
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'testDataSet.CustomerInformation' table. You can move, or remove it, as needed.
            this.customerInformationTableAdapter.Fill(this.testDataSet.CustomerInformation);

            PersonTable();
            CustomerOrderQuery();
            ProductVendorQuery();

        }

        private void ProductVendorQuery()
        {
            DataClassesDataContext db = new DataClassesDataContext();
            var person = from Person p in db.GetTable<Person>()
                         select p;

            var products = from product p in db.GetTable<product>()
                          select p;

            var orderProduct = from order_product op in db.GetTable<order_product>()
                               select op;

            var queryProducts = from p in person
                                join pr in products on p.PeopleID equals pr.VendorID
                                join op in orderProduct on pr.ProductID equals op.ProductID
                                select new
                                {
                                    VendorID = pr.VendorID,
                                    VendorName = p.FirstName + " " + p.LastName,
                                    VendorContact = p.Phone,
                                    VendorEmail = p.Email,
                                    VendorAddress = p.Address,
                                    VendorState = p.State,
                                    ProductID = pr.ProductID,
                                    WholesalePrice = pr.WholeSaleprice,
                                    RetailPrice = pr.RetailPrice,
                                    ProductName = pr.ProductName,
                                    PossibleProfit = pr.RetailPrice - pr.WholeSaleprice,
                                    OrderID = op.OrderID,
                                    EmployeeID = op.EmployeeID,
                                    ItemQuantitySold = op.Quantity,
                                    ProfitMade = (pr.RetailPrice - pr.WholeSaleprice) * op.Quantity
                                };
            dataGridViewProducts.DataSource = queryProducts;



        }

        private void CustomerOrderQuery()
        {



            DataClassesDataContext db = new DataClassesDataContext();
            var person = from Person p in db.GetTable<Person>()
                         select p;

            var customerOrder = from customerorder co in db.GetTable<customerorder>()
                                select co;

            var orderService = from order_service os in db.GetTable<order_service>()
                               select os;

            var orderProduct = from order_product op in db.GetTable<order_product>()
                               select op;

            var customers = from p in person
                            join co in customerOrder on p.PeopleID equals co.CustomerID into d
                            select d;

            var employee = from p in person
                           join co in customerOrder on p.PeopleID equals co.EmployeeID into d
                           select d;

            


            var resultLinq = from p in person
                             join co in customerOrder on p.PeopleID equals co.CustomerID
                             join os in orderService on co.OrderID equals os.OrderID
                             join pp in person on co.EmployeeID equals pp.PeopleID
                             select new
                             {
                                 CustomerID = p.PeopleID,
                                 OrderID = co.OrderID,
                                 CustomerName = p.FirstName + " " + p.LastName,
                                 EmployeeName = pp.FirstName + " " + pp.LastName,
                                 OrderDate = co.OrderDate,
                                 Total = os.Price,
                                 Quantity = os.Quantity,
                                 OrderTotal = os.Quantity * os.Price,
                                 Purchased = "Service"
                             };

            var resultLinq2 = from p in person
                              join co in customerOrder on p.PeopleID equals co.CustomerID
                              join op in orderProduct on co.OrderID equals op.OrderID
                              join pp in person on co.EmployeeID equals pp.PeopleID
                              select new
                              {
                                  CustomerID = p.PeopleID,
                                  OrderID = co.OrderID,
                                  CustomerName = p.FirstName + " " + p.LastName,
                                  EmployeeName = pp.FirstName + " " + pp.LastName,
                                  OrderDate = co.OrderDate,
                                  Total = op.Price,
                                  Quantity = op.Quantity,
                                  OrderTotal = op.Quantity * op.Price,
                                  Purchased = "Product"
                              };

            var resultLinq3 = resultLinq.Union(resultLinq2);
            dataGridView2.DataSource = resultLinq3;


            var result = from Person p in db.GetTable<Person>()
                         join customerorder co in db.customerorders
                         on p.PeopleID equals co.CustomerID
                         join order_service os in db.order_products
                         on co.OrderID equals os.OrderID
                         join Person pp in db.Persons
                         on co.EmployeeID equals pp.PeopleID
                         join order_product op in db.order_products
                         on co.OrderID equals op.OrderID
                         select new
                         {
                             CustomerID = p.PeopleID,
                             OrderID = co.OrderID,
                             CustomerName = p.FirstName + " " + p.LastName,
                             EmployeeName = pp.FirstName + " " + pp.LastName,
                             OrderDate = co.OrderDate,
                             ProductTotal = op.Price,
                             ServiceTotal = os.Price,
                             ProductQuantity = op.Quantity,
                             ServiceQuantity = os.Quantity
                         };





        }

        private void PersonTable()
        {
            DataClassesDataContext db = new DataClassesDataContext();
            var resultsTwo = from Person p in db.GetTable<Person>()
                             select p;

            dataGridView1.DataSource = resultsTwo;

        }



        private void ClearTextBoxes()
        {
            //Tab Page 1
            textBoxPeopleID.Text = "";
            textBoxAddress.Text = "";
            textBoxCity.Text = "";
            textBoxEmail.Text = "";
            textBoxFirstName.Text = "";
            textBoxLastName.Text = "";
            comboBoxPeopleType.Text = "";
            comboBoxStates.Text = "";
            textBoxZip.Text = "";
            textBoxPhone.Text = "";

            //Tab Page 2
            peopleidTextBox.Text = "";
            peopleidTextBox.Enabled = false;
            first_NameTextBox.Text = "";
            last_NameTextBox.Text = "";
            addressTextBox.Text = "";
            cityTextBox.Text = "";
            stateTextBox.Text = "";
            zipTextBox.Text = "";
            phoneTextBox.Text = "";
            emailTextBox.Text = "";
            peopleTypeTextBox.Text = "";


        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Form 1 Add button
            //Inserting data into rows

            DataClassesDataContext dc = new DataClassesDataContext();
            Person newPerson = new Person();
            if (textBoxPeopleID.Text != "" && textBoxLastName.Text != "" &&
                textBoxAddress.Text != "" && textBoxCity.Text != "" && textBoxFirstName.Text != ""
                && textBoxPhone.Text != "" && comboBoxStates.Text != "" && textBoxZip.Text != ""
                && textBoxEmail.Text != "" && comboBoxPeopleType.Text != "")
            {
                newPerson.PeopleID = int.Parse(textBoxPeopleID.Text);
                newPerson.Email = textBoxEmail.Text;
                newPerson.Address = textBoxAddress.Text;
                newPerson.City = textBoxCity.Text;
                newPerson.FirstName = textBoxFirstName.Text;
                newPerson.LastName = textBoxLastName.Text;
                newPerson.Zip = textBoxZip.Text;
                newPerson.Phone = textBoxPhone.Text;
                newPerson.PeopleType = comboBoxPeopleType.Text;
                newPerson.State = comboBoxStates.Text;

                dc.Persons.InsertOnSubmit(newPerson);
                dc.SubmitChanges();

                MessageBox.Show("New person has been inserted.");

                PersonTable();
                ClearTextBoxes();
            }
            else
            {
                MessageBox.Show("Please enter information in all fields.");
            }

        }


        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //Form 1
            //Reading rows into textboxes
            textBoxPeopleID.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBoxPeopleID.Enabled = false;
            textBoxFirstName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBoxLastName.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBoxAddress.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBoxCity.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            comboBoxStates.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            textBoxZip.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            textBoxPhone.Text = dataGridView1.CurrentRow.Cells[7].Value.ToString();
            textBoxEmail.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            comboBoxPeopleType.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();


        }

        private void customerInformationDataGridView_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            peopleidTextBox.Text = customerInformationDataGridView.CurrentRow.Cells[0].Value.ToString();
            peopleidTextBox.Enabled = false;
            first_NameTextBox.Text = customerInformationDataGridView.CurrentRow.Cells[1].Value.ToString();
            last_NameTextBox.Text = customerInformationDataGridView.CurrentRow.Cells[2].Value.ToString();
            addressTextBox.Text = customerInformationDataGridView.CurrentRow.Cells[3].Value.ToString();
            cityTextBox.Text = customerInformationDataGridView.CurrentRow.Cells[4].Value.ToString();
            stateTextBox.Text = customerInformationDataGridView.CurrentRow.Cells[5].Value.ToString();
            zipTextBox.Text = customerInformationDataGridView.CurrentRow.Cells[6].Value.ToString();
            phoneTextBox.Text = customerInformationDataGridView.CurrentRow.Cells[7].Value.ToString();
            emailTextBox.Text = customerInformationDataGridView.CurrentRow.Cells[8].Value.ToString();
            peopleTypeTextBox.Text = customerInformationDataGridView.CurrentRow.Cells[9].Value.ToString();
            firstEncounterDateTimePicker.Value = (DateTime)customerInformationDataGridView.CurrentRow.Cells[10].Value;
            dobDateTimePicker.Value = (DateTime)customerInformationDataGridView.CurrentRow.Cells[11].Value;


        }


        private void button2_Click(object sender, EventArgs e)
        {
            //Updating rows selected
            DataClassesDataContext dc = new DataClassesDataContext();

            Person p = dc.Persons.FirstOrDefault(p1 => p1.PeopleID.Equals(textBoxPeopleID.Text));
            p.FirstName = textBoxFirstName.Text;
            p.LastName = textBoxLastName.Text;
            p.Address = textBoxAddress.Text;
            p.City = textBoxCity.Text;
            p.State = comboBoxStates.Text;
            p.Zip = textBoxZip.Text;
            p.Phone = textBoxPhone.Text;
            p.Email = textBoxEmail.Text;
            p.PeopleType = comboBoxPeopleType.Text;
            dc.SubmitChanges();

            MessageBox.Show("Person Updated.");
            PersonTable();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Deleting data in rows

            DataClassesDataContext dc = new DataClassesDataContext();
            Person p = dc.Persons.FirstOrDefault
                (p1 => p1.PeopleID.Equals(dataGridView1.CurrentRow.Cells[0].Value));
            dc.Persons.DeleteOnSubmit(p);
            dc.SubmitChanges();
            MessageBox.Show("Record Deleted at: " + dataGridView1.CurrentRow.Cells[0].Value.ToString());
            PersonTable();

        }

        private void buttonClearText_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
            textBoxPeopleID.Enabled = true;
            PersonTable();
        }

        private void buttonCReset_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
            peopleidTextBox.Enabled = true;


        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void buttonSearch_Click_1(object sender, EventArgs e)
        {
            DataClassesDataContext db = new DataClassesDataContext();
            string searchValue = textBoxSearch.Text;
            if (comboBoxSearchParameter.SelectedIndex != -1)
            {
                switch (comboBoxSearchParameter.SelectedIndex)
                {
                    //Search PeopleID
                    case 0:
                        var resultsSearchPI = from Person p in db.GetTable<Person>()
                                              where p.PeopleID.Equals(searchValue)
                                              select p;
                        dataGridView1.DataSource = resultsSearchPI;
                        break;
                    case 1:
                        var resultSearchFN = from Person p in db.GetTable<Person>()
                                             where p.FirstName.Contains(searchValue)
                                             select p;
                        dataGridView1.DataSource = resultSearchFN;
                        break;
                    case 2:
                        var resultSearchLN = from Person p in db.GetTable<Person>()
                                             where p.LastName.Contains(searchValue)
                                             select p;
                        dataGridView1.DataSource = resultSearchLN;
                        break;
                    case 3:
                        var resultSearchA = from Person p in db.GetTable<Person>()
                                            where p.Address.Contains(searchValue)
                                            select p;
                        dataGridView1.DataSource = resultSearchA;
                        break;
                    case 4:
                        var resultSearchC = from Person p in db.GetTable<Person>()
                                            where p.City.Contains(searchValue)
                                            select p;
                        dataGridView1.DataSource = resultSearchC;
                        break;
                    case 5:
                        var resultSearchS = from Person p in db.GetTable<Person>()
                                            where p.State.Contains(searchValue)
                                            select p;
                        dataGridView1.DataSource = resultSearchS;
                        break;
                    case 6:
                        var resultSearchZ = from Person p in db.GetTable<Person>()
                                            where p.Zip.Contains(searchValue)
                                            select p;
                        dataGridView1.DataSource = resultSearchZ;
                        break;
                    case 7:
                        var resultSearchP = from Person p in db.GetTable<Person>()
                                            where p.Phone.Contains(searchValue)
                                            select p;
                        dataGridView1.DataSource = resultSearchP;
                        break;
                    case 8:
                        var resultSearchE = from Person p in db.GetTable<Person>()
                                            where p.Email.Contains(searchValue)
                                            select p;
                        dataGridView1.DataSource = resultSearchE;
                        break;
                    case 9:
                        var resultSearchPT = from Person p in db.GetTable<Person>()
                                             where p.PeopleType.Contains(searchValue)
                                             select p;
                        dataGridView1.DataSource = resultSearchPT;
                        break;

                    default:
                        var resultSearch = from Person p in db.GetTable<Person>()
                                           select p;
                        dataGridView1.DataSource = resultSearch;
                        break;
                }

            }
            else
            {
                MessageBox.Show("Please select a valid column to search.");
            }
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void buttonSearchCustomerOrder_Click(object sender, EventArgs e)
        {
            DataClassesDataContext db = new DataClassesDataContext();

            var person = from Person p in db.GetTable<Person>()
                         select p;

            var customerOrder = from customerorder co in db.GetTable<customerorder>()
                                select co;

            var orderService = from order_service os in db.GetTable<order_service>()
                               select os;

            var orderProduct = from order_product op in db.GetTable<order_product>()
                               select op;

            var resultLinq = from p in person
                             join co in customerOrder on p.PeopleID equals co.CustomerID
                             join os in orderService on co.OrderID equals os.OrderID
                             join pp in person on co.EmployeeID equals pp.PeopleID
                             select new
                             {
                                 CustomerID = p.PeopleID,
                                 OrderID = co.OrderID,
                                 CustomerName = p.FirstName + " " + p.LastName,
                                 EmployeeName = pp.FirstName + " " + pp.LastName,
                                 OrderDate = co.OrderDate,
                                 Total = os.Price,
                                 Quantity = os.Quantity,
                                 OrderTotal = os.Quantity * os.Price,
                                 Purchased = "Service"
                             };

            var resultLinq2 = from p in person
                              join co in customerOrder on p.PeopleID equals co.CustomerID
                              join op in orderProduct on co.OrderID equals op.OrderID
                              join pp in person on co.EmployeeID equals pp.PeopleID
                              select new
                              {
                                  CustomerID = p.PeopleID,
                                  OrderID = co.OrderID,
                                  CustomerName = p.FirstName + " " + p.LastName,
                                  EmployeeName = pp.FirstName + " " + pp.LastName,
                                  OrderDate = co.OrderDate,
                                  Total = op.Price,
                                  Quantity = op.Quantity,
                                  OrderTotal = op.Quantity * op.Price,
                                  Purchased = "Product"
                              };



            string searchValue = textBoxQuerySearch.Text;
            try
            {


                switch (comboBox1.SelectedIndex)
                {

                    //Search PeopleID
                    case 0:

                        var resultLinq3 = resultLinq.Union(resultLinq2)
                            .Where(x => x.CustomerID.Equals(int.Parse(searchValue)));



                        dataGridView2.DataSource = resultLinq3;
                        break;
                    case 1:

                        var resultLinq4 = resultLinq.Union(resultLinq2)
                            .Where(x => x.CustomerName.Contains(searchValue));



                        dataGridView2.DataSource = resultLinq4;
                        break;
                    case 2:

                        var resultLinq5 = resultLinq.Union(resultLinq2)
                            .Where(x => x.EmployeeName.Contains(searchValue));



                        dataGridView2.DataSource = resultLinq5;
                        break;
                    case 3:

                        var resultLinq6 = resultLinq.Union(resultLinq2)
                            .Where(x => x.OrderID == int.Parse(searchValue));

                        dataGridView2.DataSource = resultLinq6;
                        break;
                    case 4:

                        var resultLinq8 = resultLinq.Union(resultLinq2)
                            .Where(x => x.Purchased.Contains(searchValue));

                        dataGridView2.DataSource = resultLinq8;
                        break;
                    case 5:

                        var resultLinq9 = resultLinq.Union(resultLinq2)
                            .Where(x => x.Purchased.Contains(searchValue) || x.EmployeeName.Contains(searchValue) ||
                            x.CustomerID == int.Parse(searchValue) || x.CustomerName.Contains(searchValue) ||
                            x.OrderID == int.Parse(searchValue));

                        dataGridView2.DataSource = resultLinq9;
                        break;

                    default:
                        var resultLinq7 = resultLinq.Union(resultLinq2);
                        dataGridView2.DataSource = resultLinq7;
                        break;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("When entering ID's, use 4 digits -> Format: 1234. Error: " + ex.Message);
            }
        }

        private void buttonSearchPrice_Click(object sender, EventArgs e)
        {

            decimal searchPrice;
            DataClassesDataContext db = new DataClassesDataContext();

            var person = from Person p in db.GetTable<Person>()
                         select p;

            var customerOrder = from customerorder co in db.GetTable<customerorder>()
                                select co;

            var orderService = from order_service os in db.GetTable<order_service>()
                               select os;

            var orderProduct = from order_product op in db.GetTable<order_product>()
                               select op;

            var resultLinq = from p in person
                             join co in customerOrder on p.PeopleID equals co.CustomerID
                             join os in orderService on co.OrderID equals os.OrderID
                             join pp in person on co.EmployeeID equals pp.PeopleID

                             select new
                             {
                                 CustomerID = p.PeopleID,
                                 OrderID = co.OrderID,
                                 CustomerName = p.FirstName + " " + p.LastName,
                                 EmployeeName = pp.FirstName + " " + pp.LastName,
                                 OrderDate = co.OrderDate,
                                 Total = os.Price,
                                 Quantity = os.Quantity,
                                 OrderTotal = os.Quantity * os.Price,
                                 Purchased = "Service"
                             }
                             ;

            var resultLinq2 = from p in person
                              join co in customerOrder on p.PeopleID equals co.CustomerID
                              join op in orderProduct on co.OrderID equals op.OrderID
                              join pp in person on co.EmployeeID equals pp.PeopleID
                              select new
                              {
                                  CustomerID = p.PeopleID,
                                  OrderID = co.OrderID,
                                  CustomerName = p.FirstName + " " + p.LastName,
                                  EmployeeName = pp.FirstName + " " + pp.LastName,
                                  OrderDate = co.OrderDate,
                                  Total = op.Price,
                                  Quantity = op.Quantity,
                                  OrderTotal = op.Quantity * op.Price,
                                  Purchased = "Product"
                              };

            //None selected
            if(comboBoxPriceSearch.SelectedIndex == 3)
            {
                comboBoxProductSearch.SelectedIndex = -1;
            }

            //None Selected
            if(comboBox1.SelectedIndex == 5)
            {
                comboBox1.SelectedIndex = -1;
            }

            if (decimal.TryParse(textBoxPrice.Text, out searchPrice))
            {
                //More than
                if (comboBoxPriceSearch.SelectedIndex == 0)
                {
                    var resultLinq6 = resultLinq.Union(resultLinq2)
                            .Where(x => x.Total > searchPrice)
                            .OrderBy(x => x.Total);
                    dataGridView2.DataSource = resultLinq6;
                }
                //Less than
                else if (comboBoxPriceSearch.SelectedIndex == 1)
                {
                    var resultLinq6 = resultLinq.Union(resultLinq2)
                            .Where(x => x.Total < searchPrice)
                            .OrderBy(x => x.Total);
                    dataGridView2.DataSource = resultLinq6;
                }
                //Equal to
                else if (comboBoxPriceSearch.SelectedIndex == 2)
                {
                    var resultLinq6 = resultLinq.Union(resultLinq2)
                            .Where(x => x.Total == searchPrice)
                            .OrderBy(x => x.Total);
                    dataGridView2.DataSource = resultLinq6;
                }
                
                else
                {
                    MessageBox.Show("Please choose a seach category for price.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a number.");
            }
            
        }

        private void buttonSearchPrices_Click(object sender, EventArgs e)
        {
            DataClassesDataContext db = new DataClassesDataContext();
            var person = from Person p in db.GetTable<Person>()
                         select p;

            var products = from product p in db.GetTable<product>()
                           select p;

            var orderProduct = from order_product op in db.GetTable<order_product>()
                               select op;

            var queryProducts = from p in person
                                join pr in products on p.PeopleID equals pr.VendorID
                                join op in orderProduct on pr.ProductID equals op.ProductID
                                select new
                                {
                                    VendorID = pr.VendorID,
                                    VendorName = p.FirstName + " " + p.LastName,
                                    VendorContact = p.Phone,
                                    VendorEmail = p.Email,
                                    VendorAddress = p.Address,
                                    VendorState = p.State,
                                    ProductID = pr.ProductID,
                                    WholesalePrice = pr.WholeSaleprice,
                                    RetailPrice = pr.RetailPrice,
                                    ProductName = pr.ProductName,
                                    PossibleProfit = pr.RetailPrice - pr.WholeSaleprice,
                                    OrderID = op.OrderID,
                                    EmployeeID = op.EmployeeID,
                                    ItemQuantitySold = op.Quantity,
                                    ProfitMade = (pr.RetailPrice - pr.WholeSaleprice) * op.Quantity
                                };
            decimal priceSearched = decimal.Parse(textBoxProductPriceSearch.Text);

            //Wholesale Price
            if (comboBoxSearchColumn.SelectedIndex == 0)
            {
                //More Than
                if(comboBoxProductPrice.SelectedIndex == 0)
                {
                    var productResultQuery = queryProducts.Where(x => x.WholesalePrice > priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Less Than
                else if(comboBoxProductPrice.SelectedIndex == 1)
                {
                    var productResultQuery = queryProducts.Where(x => x.WholesalePrice < priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Equal to
                else if(comboBoxProductPrice.SelectedIndex == 2)
                {
                    var productResultQuery = queryProducts.Where(x => x.WholesalePrice == priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Not selected
                else if(comboBoxProductPrice.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select both selections.");
                }
                
            }
            //Retail Price
            else if(comboBoxSearchColumn.SelectedIndex == 1)
            {
                //More Than
                if (comboBoxProductPrice.SelectedIndex == 0)
                {
                    var productResultQuery = queryProducts.Where(x => x.RetailPrice > priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Less Than
                else if (comboBoxProductPrice.SelectedIndex == 1)
                {
                    var productResultQuery = queryProducts.Where(x => x.RetailPrice < priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Equal to
                else if (comboBoxProductPrice.SelectedIndex == 2)
                {
                    var productResultQuery = queryProducts.Where(x => x.RetailPrice == priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Not selected
                else if (comboBoxProductPrice.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select both selections.");
                }
            }
            //Possible Profit
            else if(comboBoxSearchColumn.SelectedIndex == 2)
            {
                //More Than
                if (comboBoxProductPrice.SelectedIndex == 0)
                {
                    var productResultQuery = queryProducts.Where(x => x.PossibleProfit > priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Less Than
                else if (comboBoxProductPrice.SelectedIndex == 1)
                {
                    var productResultQuery = queryProducts.Where(x => x.PossibleProfit < priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Equal to
                else if (comboBoxProductPrice.SelectedIndex == 2)
                {
                    var productResultQuery = queryProducts.Where(x => x.PossibleProfit == priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Not selected
                else if (comboBoxProductPrice.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select both selections.");
                }
            }
            //Total Profit
            else if(comboBoxSearchColumn.SelectedIndex == 3)
            {
                //More Than
                if (comboBoxProductPrice.SelectedIndex == 0)
                {
                    var productResultQuery = queryProducts.Where(x => x.ProfitMade > priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Less Than
                else if (comboBoxProductPrice.SelectedIndex == 1)
                {
                    var productResultQuery = queryProducts.Where(x => x.ProfitMade < priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Equal to
                else if (comboBoxProductPrice.SelectedIndex == 2)
                {
                    var productResultQuery = queryProducts.Where(x => x.ProfitMade == priceSearched);
                    dataGridViewProducts.DataSource = productResultQuery;
                }
                //Not selected
                else if (comboBoxProductPrice.SelectedIndex == -1)
                {
                    MessageBox.Show("Please select both selections.");
                }
            }
            //Nothing selected
            else if(comboBoxSearchColumn.SelectedIndex == -1)
            {
                MessageBox.Show("Hey, you gotta select something.");
            }
            
        }

        private void buttonSearchProducts_Click(object sender, EventArgs e)
        {
            decimal priceSearched;

            DataClassesDataContext db = new DataClassesDataContext();
            string searchValue = textBoxSearchProducts.Text;
                
            var person = from Person p in db.GetTable<Person>()
                         select p;

            var products = from product p in db.GetTable<product>()
                           select p;

            var orderProduct = from order_product op in db.GetTable<order_product>()
                               select op;

            var queryProducts = from p in person
                                join pr in products on p.PeopleID equals pr.VendorID
                                join op in orderProduct on pr.ProductID equals op.ProductID
                                select new
                                {
                                    VendorID = pr.VendorID,
                                    VendorName = p.FirstName + " " + p.LastName,
                                    VendorContact = p.Phone,
                                    VendorEmail = p.Email,
                                    VendorAddress = p.Address,
                                    VendorState = p.State,
                                    ProductID = pr.ProductID,
                                    WholesalePrice = pr.WholeSaleprice,
                                    RetailPrice = pr.RetailPrice,
                                    ProductName = pr.ProductName,
                                    PossibleProfit = pr.RetailPrice - pr.WholeSaleprice,
                                    OrderID = op.OrderID,
                                    EmployeeID = op.EmployeeID,
                                    ItemQuantitySold = op.Quantity,
                                    ProfitMade = (pr.RetailPrice - pr.WholeSaleprice) * op.Quantity
                                };
            try
            {


                if (comboBoxSearchColumn.SelectedIndex == 4)
                {
                    comboBoxSearchColumn.SelectedIndex = -1;
                }

                if (comboBoxProductPrice.SelectedIndex == 3)
                {
                    comboBoxProductPrice.SelectedIndex = -1;
                }

                if (comboBoxProductSearch.SelectedIndex == 15)
                {
                    comboBoxProductSearch.SelectedIndex = -1;
                }
                //If all three comboboxes are selected, colum price search, and element search
                if (comboBoxSearchColumn.SelectedIndex != -1 && comboBoxProductPrice.SelectedIndex != -1 && comboBoxProductSearch.SelectedIndex != -1)
                {
                    if (decimal.TryParse(textBoxProductPriceSearch.Text, out priceSearched))
                    {


                        //Wholesale Price
                        if (comboBoxSearchColumn.SelectedIndex == 0)
                        {
                            //More Than
                            if (comboBoxProductPrice.SelectedIndex == 0)
                            {
                                var productResultQuery = queryProducts.Where(x => x.WholesalePrice > priceSearched);


                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }

                            }
                            //Less Than
                            else if (comboBoxProductPrice.SelectedIndex == 1)
                            {
                                var productResultQuery = queryProducts.Where(x => x.WholesalePrice < priceSearched);


                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }
                            //Equal to
                            else if (comboBoxProductPrice.SelectedIndex == 2)
                            {
                                var productResultQuery = queryProducts.Where(x => x.WholesalePrice == priceSearched);

                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }
                            //Not selected
                            else if (comboBoxProductPrice.SelectedIndex == -1)
                            {
                                MessageBox.Show("Please select both selections.");
                            }

                        }
                        //Retail Price
                        else if (comboBoxSearchColumn.SelectedIndex == 1)
                        {
                            //More Than
                            if (comboBoxProductPrice.SelectedIndex == 0)
                            {
                                var productResultQuery = queryProducts.Where(x => x.RetailPrice > priceSearched);
                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }
                            //Less Than
                            else if (comboBoxProductPrice.SelectedIndex == 1)
                            {
                                var productResultQuery = queryProducts.Where(x => x.RetailPrice < priceSearched);

                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }
                            //Equal to
                            else if (comboBoxProductPrice.SelectedIndex == 2)
                            {
                                var productResultQuery = queryProducts.Where(x => x.RetailPrice == priceSearched);

                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }
                            //Not selected
                            else if (comboBoxProductPrice.SelectedIndex == -1)
                            {
                                MessageBox.Show("Please select both selections.");
                            }
                        }
                        //Possible Profit
                        else if (comboBoxSearchColumn.SelectedIndex == 2)
                        {
                            //More Than
                            if (comboBoxProductPrice.SelectedIndex == 0)
                            {
                                var productResultQuery = queryProducts.Where(x => x.PossibleProfit > priceSearched);

                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }
                            //Less Than
                            else if (comboBoxProductPrice.SelectedIndex == 1)
                            {
                                var productResultQuery = queryProducts.Where(x => x.PossibleProfit < priceSearched);

                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }
                            //Equal to
                            else if (comboBoxProductPrice.SelectedIndex == 2)
                            {
                                var productResultQuery = queryProducts.Where(x => x.PossibleProfit == priceSearched);

                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }


                            //Not selected
                            else if (comboBoxProductPrice.SelectedIndex == -1)
                            {
                                MessageBox.Show("Please select both selections.");
                            }
                        }

                        //Total Profit
                        else if (comboBoxSearchColumn.SelectedIndex == 3)
                        {
                            //More Than
                            if (comboBoxProductPrice.SelectedIndex == 0)
                            {
                                var productResultQuery = queryProducts.Where(x => x.ProfitMade > priceSearched);

                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }
                            //Less Than
                            else if (comboBoxProductPrice.SelectedIndex == 1)
                            {
                                var productResultQuery = queryProducts.Where(x => x.ProfitMade < priceSearched);

                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }
                            //Equal to
                            else if (comboBoxProductPrice.SelectedIndex == 2)
                            {
                                var productResultQuery = queryProducts.Where(x => x.ProfitMade == priceSearched);

                                switch (comboBoxProductSearch.SelectedIndex)
                                {
                                    //Search PeopleID
                                    case 0:
                                        var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultsSearchPI;
                                        break;
                                    //Search Vendor Name
                                    case 1:
                                        var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchFN;
                                        break;
                                    //Search Vendor Contact
                                    case 2:
                                        var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchLN;
                                        break;
                                    //Search vendor Email
                                    case 3:
                                        var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchA;
                                        break;
                                    //Search Vendor Address
                                    case 4:
                                        var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchC;
                                        break;
                                    case 5:
                                        var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchS;
                                        break;
                                    //Search ProductID
                                    case 6:
                                        var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchZ;
                                        break;
                                    //Search Wholesale Price
                                    case 7:
                                        var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchP;
                                        break;
                                    //Search Retail Price
                                    case 8:
                                        var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchE;
                                        break;
                                    //Search Product Name
                                    case 9:
                                        var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPT;
                                        break;
                                    //Search Possible Profit
                                    case 10:
                                        var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPP;
                                        break;
                                    //Search OrderID
                                    case 11:
                                        var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchOI;
                                        break;
                                    //Search EmployeeID
                                    case 12:
                                        var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchEI;
                                        break;
                                    //Search Item Quantity Sold
                                    case 13:
                                        var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchIQS;
                                        break;
                                    //Search Profit Made
                                    case 14:
                                        var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                        dataGridViewProducts.DataSource = resultSearchPM;
                                        break;
                                    default:
                                        var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                        dataGridViewProducts.DataSource = resultSearch;
                                        break;
                                }
                            }
                            //Not selected
                            else if (comboBoxProductPrice.SelectedIndex == -1)
                            {
                                MessageBox.Show("Please select both selections.");
                            }
                        }
                        //Nothing selected
                        else if (comboBoxSearchColumn.SelectedIndex == -1)
                        {
                            MessageBox.Show("Hey, you gotta select something.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid number.");

                    }
                }
                /////////////////////////////////////////////
                //If both of the left comboboxes are selected
                /////////////////////////////////////////////
                else if (comboBoxSearchColumn.SelectedIndex != -1 && comboBoxProductPrice.SelectedIndex != -1 && comboBoxProductSearch.SelectedIndex == -1)
                {
                    if (decimal.TryParse(textBoxProductPriceSearch.Text, out priceSearched))
                    {
                        if (comboBoxSearchColumn.SelectedIndex == 0)
                        {


                            //More Than
                            if (comboBoxProductPrice.SelectedIndex == 0)
                            {
                                var productResultQuery = queryProducts.Where(x => x.WholesalePrice > priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Less Than
                            else if (comboBoxProductPrice.SelectedIndex == 1)
                            {
                                var productResultQuery = queryProducts.Where(x => x.WholesalePrice < priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Equal to
                            else if (comboBoxProductPrice.SelectedIndex == 2)
                            {
                                var productResultQuery = queryProducts.Where(x => x.WholesalePrice == priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Not selected
                            else if (comboBoxProductPrice.SelectedIndex == -1)
                            {
                                MessageBox.Show("Please select both selections.");
                            }
                        }


                        //Retail Price
                        else if (comboBoxSearchColumn.SelectedIndex == 1)
                        {
                            //More Than
                            if (comboBoxProductPrice.SelectedIndex == 0)
                            {
                                var productResultQuery = queryProducts.Where(x => x.RetailPrice > priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Less Than
                            else if (comboBoxProductPrice.SelectedIndex == 1)
                            {
                                var productResultQuery = queryProducts.Where(x => x.RetailPrice < priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Equal to
                            else if (comboBoxProductPrice.SelectedIndex == 2)
                            {
                                var productResultQuery = queryProducts.Where(x => x.RetailPrice == priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Not selected
                            else if (comboBoxProductPrice.SelectedIndex == -1)
                            {
                                MessageBox.Show("Please select both selections.");
                            }
                        }
                        //Possible Profit
                        else if (comboBoxSearchColumn.SelectedIndex == 2)
                        {
                            //More Than
                            if (comboBoxProductPrice.SelectedIndex == 0)
                            {
                                var productResultQuery = queryProducts.Where(x => x.PossibleProfit > priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Less Than
                            else if (comboBoxProductPrice.SelectedIndex == 1)
                            {
                                var productResultQuery = queryProducts.Where(x => x.PossibleProfit < priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Equal to
                            else if (comboBoxProductPrice.SelectedIndex == 2)
                            {
                                var productResultQuery = queryProducts.Where(x => x.PossibleProfit == priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Not selected
                            else if (comboBoxProductPrice.SelectedIndex == -1)
                            {
                                MessageBox.Show("Please select both selections.");
                            }
                        }
                        //Total Profit
                        else if (comboBoxSearchColumn.SelectedIndex == 3)
                        {
                            //More Than
                            if (comboBoxProductPrice.SelectedIndex == 0)
                            {
                                var productResultQuery = queryProducts.Where(x => x.ProfitMade > priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Less Than
                            else if (comboBoxProductPrice.SelectedIndex == 1)
                            {
                                var productResultQuery = queryProducts.Where(x => x.ProfitMade < priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Equal to
                            else if (comboBoxProductPrice.SelectedIndex == 2)
                            {
                                var productResultQuery = queryProducts.Where(x => x.ProfitMade == priceSearched);
                                dataGridViewProducts.DataSource = productResultQuery;
                            }
                            //Not selected
                            else if (comboBoxProductPrice.SelectedIndex == -1)
                            {
                                MessageBox.Show("Please select both selections.");
                            }
                        }
                        //Nothing selected
                        else if (comboBoxSearchColumn.SelectedIndex == -1)
                        {
                            MessageBox.Show("Hey, you gotta select something.");
                        }
                        else
                        {
                            MessageBox.Show("Please select a valid column to search.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid number.");
                    }
                }
                //////////////////////////////////////////////////////////////////////////////////////
                //If left and right comboboxes are selected, left->Price < > ==, right->Element lookup
                //////////////////////////////////////////////////////////////////////////////////////
                else if (comboBoxProductSearch.SelectedIndex != -1 && comboBoxProductPrice.SelectedIndex != -1 && comboBoxSearchColumn.SelectedIndex == -1)
                {
                    if (decimal.TryParse(textBoxProductPriceSearch.Text, out priceSearched))
                    {


                        //More Than
                        if (comboBoxProductPrice.SelectedIndex == 0)
                        {
                            var productResultQuery = queryProducts.Where(x => x.PossibleProfit > priceSearched && x.WholesalePrice > priceSearched && x.RetailPrice > priceSearched && x.ProfitMade > priceSearched);

                            switch (comboBoxProductSearch.SelectedIndex)
                            {
                                //Search PeopleID
                                case 0:
                                    var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultsSearchPI;
                                    break;
                                //Search Vendor Name
                                case 1:
                                    var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchFN;
                                    break;
                                //Search Vendor Contact
                                case 2:
                                    var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchLN;
                                    break;
                                //Search vendor Email
                                case 3:
                                    var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchA;
                                    break;
                                //Search Vendor Address
                                case 4:
                                    var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchC;
                                    break;
                                case 5:
                                    var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchS;
                                    break;
                                //Search ProductID
                                case 6:
                                    var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchZ;
                                    break;
                                //Search Wholesale Price
                                case 7:
                                    var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchP;
                                    break;
                                //Search Retail Price
                                case 8:
                                    var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchE;
                                    break;
                                //Search Product Name
                                case 9:
                                    var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchPT;
                                    break;
                                //Search Possible Profit
                                case 10:
                                    var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchPP;
                                    break;
                                //Search OrderID
                                case 11:
                                    var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchOI;
                                    break;
                                //Search EmployeeID
                                case 12:
                                    var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchEI;
                                    break;
                                //Search Item Quantity Sold
                                case 13:
                                    var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchIQS;
                                    break;
                                //Search Profit Made
                                case 14:
                                    var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchPM;
                                    break;
                                default:
                                    var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                    dataGridViewProducts.DataSource = resultSearch;
                                    break;
                            }
                        }
                        //Less Than
                        else if (comboBoxProductPrice.SelectedIndex == 1)
                        {
                            var productResultQuery = queryProducts.Where(x => x.PossibleProfit < priceSearched && x.WholesalePrice < priceSearched && x.RetailPrice < priceSearched && x.ProfitMade < priceSearched);

                            switch (comboBoxProductSearch.SelectedIndex)
                            {
                                //Search PeopleID
                                case 0:
                                    var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultsSearchPI;
                                    break;
                                //Search Vendor Name
                                case 1:
                                    var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchFN;
                                    break;
                                //Search Vendor Contact
                                case 2:
                                    var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchLN;
                                    break;
                                //Search vendor Email
                                case 3:
                                    var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchA;
                                    break;
                                //Search Vendor Address
                                case 4:
                                    var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchC;
                                    break;
                                case 5:
                                    var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchS;
                                    break;
                                //Search ProductID
                                case 6:
                                    var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchZ;
                                    break;
                                //Search Wholesale Price
                                case 7:
                                    var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchP;
                                    break;
                                //Search Retail Price
                                case 8:
                                    var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchE;
                                    break;
                                //Search Product Name
                                case 9:
                                    var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchPT;
                                    break;
                                //Search Possible Profit
                                case 10:
                                    var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchPP;
                                    break;
                                //Search OrderID
                                case 11:
                                    var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchOI;
                                    break;
                                //Search EmployeeID
                                case 12:
                                    var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchEI;
                                    break;
                                //Search Item Quantity Sold
                                case 13:
                                    var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchIQS;
                                    break;
                                //Search Profit Made
                                case 14:
                                    var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchPM;
                                    break;
                                default:
                                    var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                    dataGridViewProducts.DataSource = resultSearch;
                                    break;
                            }
                        }
                        //Equal to
                        else if (comboBoxProductPrice.SelectedIndex == 2)
                        {
                            MessageBox.Show("Price searched is equal to Profit Made column due to combobox selection");
                            var productResultQuery = queryProducts.Where(x => x.ProfitMade == priceSearched);
                            switch (comboBoxProductSearch.SelectedIndex)
                            {
                                //Search PeopleID
                                case 0:
                                    var resultsSearchPI = productResultQuery.Where(x => x.VendorID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultsSearchPI;
                                    break;
                                //Search Vendor Name
                                case 1:
                                    var resultSearchFN = productResultQuery.Where(x => x.VendorName.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchFN;
                                    break;
                                //Search Vendor Contact
                                case 2:
                                    var resultSearchLN = productResultQuery.Where(x => x.VendorContact.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchLN;
                                    break;
                                //Search vendor Email
                                case 3:
                                    var resultSearchA = productResultQuery.Where(x => x.VendorEmail.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchA;
                                    break;
                                //Search Vendor Address
                                case 4:
                                    var resultSearchC = productResultQuery.Where(x => x.VendorAddress.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchC;
                                    break;
                                case 5:
                                    var resultSearchS = productResultQuery.Where(x => x.VendorState.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchS;
                                    break;
                                //Search ProductID
                                case 6:
                                    var resultSearchZ = productResultQuery.Where(x => x.ProductID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchZ;
                                    break;
                                //Search Wholesale Price
                                case 7:
                                    var resultSearchP = productResultQuery.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchP;
                                    break;
                                //Search Retail Price
                                case 8:
                                    var resultSearchE = productResultQuery.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchE;
                                    break;
                                //Search Product Name
                                case 9:
                                    var resultSearchPT = productResultQuery.Where(x => x.ProductName.Contains(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchPT;
                                    break;
                                //Search Possible Profit
                                case 10:
                                    var resultSearchPP = productResultQuery.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchPP;
                                    break;
                                //Search OrderID
                                case 11:
                                    var resultSearchOI = productResultQuery.Where(x => x.OrderID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchOI;
                                    break;
                                //Search EmployeeID
                                case 12:
                                    var resultSearchEI = productResultQuery.Where(x => x.EmployeeID == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchEI;
                                    break;
                                //Search Item Quantity Sold
                                case 13:
                                    var resultSearchIQS = productResultQuery.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchIQS;
                                    break;
                                //Search Profit Made
                                case 14:
                                    var resultSearchPM = productResultQuery.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                                    dataGridViewProducts.DataSource = resultSearchPM;
                                    break;
                                default:
                                    var resultSearch = productResultQuery.OrderBy(x => x.VendorID);
                                    dataGridViewProducts.DataSource = resultSearch;
                                    break;
                            }
                        }
                        //Not selected
                        else if (comboBoxProductPrice.SelectedIndex == -1)
                        {
                            MessageBox.Show("Please select both selections.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid number.");
                    }
                }

                ////////////////////////////////////////////////////////////////
                //If Only Right Select Column is selected, search element column
                ////////////////////////////////////////////////////////////////
                else if (comboBoxProductSearch.SelectedIndex != -1 && comboBoxProductPrice.SelectedIndex == -1 && comboBoxSearchColumn.SelectedIndex == -1)
                {
                    switch (comboBoxProductSearch.SelectedIndex)
                    {
                        //Search PeopleID
                        case 0:
                            var resultsSearchPI = queryProducts.Where(x => x.VendorID == int.Parse(searchValue));
                            dataGridViewProducts.DataSource = resultsSearchPI;
                            break;
                        //Search Vendor Name
                        case 1:
                            var resultSearchFN = queryProducts.Where(x => x.VendorName.Contains(searchValue));
                            dataGridViewProducts.DataSource = resultSearchFN;
                            break;
                        //Search Vendor Contact
                        case 2:
                            var resultSearchLN = queryProducts.Where(x => x.VendorContact.Contains(searchValue));
                            dataGridViewProducts.DataSource = resultSearchLN;
                            break;
                        //Search vendor Email
                        case 3:
                            var resultSearchA = queryProducts.Where(x => x.VendorEmail.Contains(searchValue));
                            dataGridViewProducts.DataSource = resultSearchA;
                            break;
                        //Search Vendor Address
                        case 4:
                            var resultSearchC = queryProducts.Where(x => x.VendorAddress.Contains(searchValue));
                            dataGridViewProducts.DataSource = resultSearchC;
                            break;
                        case 5:
                            var resultSearchS = queryProducts.Where(x => x.VendorState.Contains(searchValue));
                            dataGridViewProducts.DataSource = resultSearchS;
                            break;
                        //Search ProductID
                        case 6:
                            var resultSearchZ = queryProducts.Where(x => x.ProductID == int.Parse(searchValue));
                            dataGridViewProducts.DataSource = resultSearchZ;
                            break;
                        //Search Wholesale Price
                        case 7:
                            var resultSearchP = queryProducts.Where(x => x.WholesalePrice == decimal.Parse(searchValue));
                            dataGridViewProducts.DataSource = resultSearchP;
                            break;
                        //Search Retail Price
                        case 8:
                            var resultSearchE = queryProducts.Where(x => x.RetailPrice == decimal.Parse(searchValue));
                            dataGridViewProducts.DataSource = resultSearchE;
                            break;
                        //Search Product Name
                        case 9:
                            var resultSearchPT = queryProducts.Where(x => x.ProductName.Contains(searchValue));
                            dataGridViewProducts.DataSource = resultSearchPT;
                            break;
                        //Search Possible Profit
                        case 10:
                            var resultSearchPP = queryProducts.Where(x => x.PossibleProfit == decimal.Parse(searchValue));
                            dataGridViewProducts.DataSource = resultSearchPP;
                            break;
                        //Search OrderID
                        case 11:
                            var resultSearchOI = queryProducts.Where(x => x.OrderID == int.Parse(searchValue));
                            dataGridViewProducts.DataSource = resultSearchOI;
                            break;
                        //Search EmployeeID
                        case 12:
                            var resultSearchEI = queryProducts.Where(x => x.EmployeeID == int.Parse(searchValue));
                            dataGridViewProducts.DataSource = resultSearchEI;
                            break;
                        //Search Item Quantity Sold
                        case 13:
                            var resultSearchIQS = queryProducts.Where(x => x.ItemQuantitySold == int.Parse(searchValue));
                            dataGridViewProducts.DataSource = resultSearchIQS;
                            break;
                        //Search Profit Made
                        case 14:
                            var resultSearchPM = queryProducts.Where(x => x.ProfitMade == decimal.Parse(searchValue));
                            dataGridViewProducts.DataSource = resultSearchPM;
                            break;
                        default:
                            var resultSearch = queryProducts.OrderBy(x => x.VendorID);
                            dataGridViewProducts.DataSource = resultSearch;
                            break;
                    }

                }
                ////////////////////////////////////////
                //If only combobox for price is selected
                ////////////////////////////////////////
                else if (comboBoxProductPrice.SelectedIndex != -1 && comboBoxSearchColumn.SelectedIndex == -1 && comboBoxProductSearch.SelectedIndex == -1)
                {
                    if (decimal.TryParse(textBoxProductPriceSearch.Text, out priceSearched))
                    {


                        //More Than
                        if (comboBoxProductPrice.SelectedIndex == 0)
                        {
                            var productResultQuery = queryProducts.Where(x => x.PossibleProfit > priceSearched && x.WholesalePrice > priceSearched && x.RetailPrice > priceSearched && x.ProfitMade > priceSearched);
                            dataGridViewProducts.DataSource = productResultQuery;
                        }
                        //Less Than
                        else if (comboBoxProductPrice.SelectedIndex == 1)
                        {
                            var productResultQuery = queryProducts.Where(x => x.PossibleProfit < priceSearched && x.WholesalePrice < priceSearched && x.RetailPrice < priceSearched && x.ProfitMade < priceSearched);
                            dataGridViewProducts.DataSource = productResultQuery;
                        }
                        //Equal to
                        else if (comboBoxProductPrice.SelectedIndex == 2)
                        {
                            MessageBox.Show("Price searched is equal to Profit Made column due to combobox selection");
                            var productResultQuery = queryProducts.Where(x => x.ProfitMade == priceSearched);
                            dataGridViewProducts.DataSource = productResultQuery;
                        }
                        //Not selected
                        else if (comboBoxProductPrice.SelectedIndex == -1)
                        {
                            MessageBox.Show("Please select both selections.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid number.");
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("If searching for ID -> Use format: 1234 | Or try Error: " + ex.Message);
            }
        }

        private void buttonResetCO_Click(object sender, EventArgs e)
        {
            CustomerOrderQuery();
            textBoxPrice.Text = "";
            textBoxQuerySearch.Text = "";
            comboBoxPriceSearch.SelectedIndex = -1;
            comboBox1.SelectedIndex = -1;
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            ProductVendorQuery();
            textBoxProductPriceSearch.Text = "";
            textBoxSearchProducts.Text = "";
            comboBoxProductPrice.SelectedIndex = -1;
            comboBoxProductSearch.SelectedIndex = -1;
            comboBoxSearchColumn.SelectedIndex = -1;
        }
    }
}
