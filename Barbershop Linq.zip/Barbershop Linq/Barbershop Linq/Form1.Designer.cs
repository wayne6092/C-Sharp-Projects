﻿namespace Barbershop_Linq
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label dobLabel;
            System.Windows.Forms.Label firstEncounterLabel;
            System.Windows.Forms.Label peopleTypeLabel;
            System.Windows.Forms.Label emailLabel;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label zipLabel;
            System.Windows.Forms.Label stateLabel;
            System.Windows.Forms.Label cityLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label last_NameLabel;
            System.Windows.Forms.Label first_NameLabel;
            System.Windows.Forms.Label peopleidLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.customerInformationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.testDataSet = new Barbershop_Linq.testDataSet();
            this.customerInformationTableAdapter = new Barbershop_Linq.testDataSetTableAdapters.CustomerInformationTableAdapter();
            this.tableAdapterManager = new Barbershop_Linq.testDataSetTableAdapters.TableAdapterManager();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.buttonResetCO = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBoxPriceSearch = new System.Windows.Forms.ComboBox();
            this.buttonSearchPrice = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxPrice = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBoxQuerySearch = new System.Windows.Forms.TextBox();
            this.buttonSearchCustomerOrder = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.toolStripContainer1 = new System.Windows.Forms.ToolStripContainer();
            this.customerInformationBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.customerInformationBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.peopleidTextBox = new System.Windows.Forms.TextBox();
            this.first_NameTextBox = new System.Windows.Forms.TextBox();
            this.last_NameTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.cityTextBox = new System.Windows.Forms.TextBox();
            this.stateTextBox = new System.Windows.Forms.TextBox();
            this.zipTextBox = new System.Windows.Forms.TextBox();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.emailTextBox = new System.Windows.Forms.TextBox();
            this.peopleTypeTextBox = new System.Windows.Forms.TextBox();
            this.textBoxCSearch = new System.Windows.Forms.TextBox();
            this.firstEncounterDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.dobDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.customerInformationDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.buttonCSearch = new System.Windows.Forms.Button();
            this.comboBoxCSearch = new System.Windows.Forms.ComboBox();
            this.buttonCReset = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.textBoxSearch = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxPeopleID = new System.Windows.Forms.TextBox();
            this.textBoxLastName = new System.Windows.Forms.TextBox();
            this.textBoxAddress = new System.Windows.Forms.TextBox();
            this.textBoxPhone = new System.Windows.Forms.TextBox();
            this.textBoxZip = new System.Windows.Forms.TextBox();
            this.textBoxCity = new System.Windows.Forms.TextBox();
            this.textBoxFirstName = new System.Windows.Forms.TextBox();
            this.comboBoxSearchParameter = new System.Windows.Forms.ComboBox();
            this.comboBoxPeopleType = new System.Windows.Forms.ComboBox();
            this.comboBoxStates = new System.Windows.Forms.ComboBox();
            this.buttonClearText = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.buttonReset = new System.Windows.Forms.Button();
            this.comboBoxSearchColumn = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.comboBoxProductPrice = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxProductPriceSearch = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.comboBoxProductSearch = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBoxSearchProducts = new System.Windows.Forms.TextBox();
            this.buttonSearchProducts = new System.Windows.Forms.Button();
            this.dataGridViewProducts = new System.Windows.Forms.DataGridView();
            dobLabel = new System.Windows.Forms.Label();
            firstEncounterLabel = new System.Windows.Forms.Label();
            peopleTypeLabel = new System.Windows.Forms.Label();
            emailLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            zipLabel = new System.Windows.Forms.Label();
            stateLabel = new System.Windows.Forms.Label();
            cityLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            last_NameLabel = new System.Windows.Forms.Label();
            first_NameLabel = new System.Windows.Forms.Label();
            peopleidLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.customerInformationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.testDataSet)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.toolStripContainer1.TopToolStripPanel.SuspendLayout();
            this.toolStripContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerInformationBindingNavigator)).BeginInit();
            this.customerInformationBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerInformationDataGridView)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProducts)).BeginInit();
            this.SuspendLayout();
            // 
            // dobLabel
            // 
            dobLabel.AutoSize = true;
            dobLabel.Location = new System.Drawing.Point(13, 322);
            dobLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            dobLabel.Name = "dobLabel";
            dobLabel.Size = new System.Drawing.Size(30, 13);
            dobLabel.TabIndex = 82;
            dobLabel.Text = "Dob:";
            // 
            // firstEncounterLabel
            // 
            firstEncounterLabel.AutoSize = true;
            firstEncounterLabel.Location = new System.Drawing.Point(13, 296);
            firstEncounterLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            firstEncounterLabel.Name = "firstEncounterLabel";
            firstEncounterLabel.Size = new System.Drawing.Size(81, 13);
            firstEncounterLabel.TabIndex = 80;
            firstEncounterLabel.Text = "First Encounter:";
            // 
            // peopleTypeLabel
            // 
            peopleTypeLabel.AutoSize = true;
            peopleTypeLabel.Location = new System.Drawing.Point(13, 272);
            peopleTypeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            peopleTypeLabel.Name = "peopleTypeLabel";
            peopleTypeLabel.Size = new System.Drawing.Size(70, 13);
            peopleTypeLabel.TabIndex = 78;
            peopleTypeLabel.Text = "People Type:";
            // 
            // emailLabel
            // 
            emailLabel.AutoSize = true;
            emailLabel.Location = new System.Drawing.Point(13, 245);
            emailLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            emailLabel.Name = "emailLabel";
            emailLabel.Size = new System.Drawing.Size(35, 13);
            emailLabel.TabIndex = 76;
            emailLabel.Text = "Email:";
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.Location = new System.Drawing.Point(13, 221);
            phoneLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(41, 13);
            phoneLabel.TabIndex = 74;
            phoneLabel.Text = "Phone:";
            // 
            // zipLabel
            // 
            zipLabel.AutoSize = true;
            zipLabel.Location = new System.Drawing.Point(12, 195);
            zipLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            zipLabel.Name = "zipLabel";
            zipLabel.Size = new System.Drawing.Size(25, 13);
            zipLabel.TabIndex = 72;
            zipLabel.Text = "Zip:";
            // 
            // stateLabel
            // 
            stateLabel.AutoSize = true;
            stateLabel.Location = new System.Drawing.Point(13, 171);
            stateLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            stateLabel.Name = "stateLabel";
            stateLabel.Size = new System.Drawing.Size(35, 13);
            stateLabel.TabIndex = 70;
            stateLabel.Text = "State:";
            // 
            // cityLabel
            // 
            cityLabel.AutoSize = true;
            cityLabel.Location = new System.Drawing.Point(12, 147);
            cityLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            cityLabel.Name = "cityLabel";
            cityLabel.Size = new System.Drawing.Size(27, 13);
            cityLabel.TabIndex = 68;
            cityLabel.Text = "City:";
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.Location = new System.Drawing.Point(12, 123);
            addressLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(48, 13);
            addressLabel.TabIndex = 66;
            addressLabel.Text = "Address:";
            // 
            // last_NameLabel
            // 
            last_NameLabel.AutoSize = true;
            last_NameLabel.Location = new System.Drawing.Point(12, 100);
            last_NameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            last_NameLabel.Name = "last_NameLabel";
            last_NameLabel.Size = new System.Drawing.Size(61, 13);
            last_NameLabel.TabIndex = 64;
            last_NameLabel.Text = "Last Name:";
            // 
            // first_NameLabel
            // 
            first_NameLabel.AutoSize = true;
            first_NameLabel.Location = new System.Drawing.Point(12, 76);
            first_NameLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            first_NameLabel.Name = "first_NameLabel";
            first_NameLabel.Size = new System.Drawing.Size(60, 13);
            first_NameLabel.TabIndex = 62;
            first_NameLabel.Text = "First Name:";
            // 
            // peopleidLabel
            // 
            peopleidLabel.AutoSize = true;
            peopleidLabel.Location = new System.Drawing.Point(13, 51);
            peopleidLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            peopleidLabel.Name = "peopleidLabel";
            peopleidLabel.Size = new System.Drawing.Size(50, 13);
            peopleidLabel.TabIndex = 60;
            peopleidLabel.Text = "peopleid:";
            // 
            // customerInformationBindingSource
            // 
            this.customerInformationBindingSource.DataMember = "CustomerInformation";
            this.customerInformationBindingSource.DataSource = this.testDataSet;
            // 
            // testDataSet
            // 
            this.testDataSet.DataSetName = "testDataSet";
            this.testDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // customerInformationTableAdapter
            // 
            this.customerInformationTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.CategoryTableAdapter = null;
            this.tableAdapterManager.Connection = null;
            this.tableAdapterManager.customerorderTableAdapter = null;
            this.tableAdapterManager.CustomerTableAdapter = null;
            this.tableAdapterManager.EmployeeTableAdapter = null;
            this.tableAdapterManager.order_productsTableAdapter = null;
            this.tableAdapterManager.order_servicesTableAdapter = null;
            this.tableAdapterManager.PersonTableAdapter = null;
            this.tableAdapterManager.productTableAdapter = null;
            this.tableAdapterManager.serviceTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Barbershop_Linq.testDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.VendorTableAdapter = null;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.DarkTurquoise;
            this.tabPage3.Controls.Add(this.buttonResetCO);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.comboBoxPriceSearch);
            this.tabPage3.Controls.Add(this.buttonSearchPrice);
            this.tabPage3.Controls.Add(this.label13);
            this.tabPage3.Controls.Add(this.textBoxPrice);
            this.tabPage3.Controls.Add(this.label12);
            this.tabPage3.Controls.Add(this.comboBox1);
            this.tabPage3.Controls.Add(this.label11);
            this.tabPage3.Controls.Add(this.textBoxQuerySearch);
            this.tabPage3.Controls.Add(this.buttonSearchCustomerOrder);
            this.tabPage3.Controls.Add(this.dataGridView2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(476, 342);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Query CustomerOrder";
            // 
            // buttonResetCO
            // 
            this.buttonResetCO.Location = new System.Drawing.Point(13, 266);
            this.buttonResetCO.Name = "buttonResetCO";
            this.buttonResetCO.Size = new System.Drawing.Size(75, 23);
            this.buttonResetCO.TabIndex = 73;
            this.buttonResetCO.Text = "Reset";
            this.buttonResetCO.UseVisualStyleBackColor = true;
            this.buttonResetCO.Click += new System.EventHandler(this.buttonResetCO_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(115, 170);
            this.label16.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(104, 13);
            this.label16.TabIndex = 59;
            this.label16.Text = "Select Condition:";
            // 
            // comboBoxPriceSearch
            // 
            this.comboBoxPriceSearch.FormattingEnabled = true;
            this.comboBoxPriceSearch.Items.AddRange(new object[] {
            "More Than:",
            "Less Than:",
            "Equal To:",
            "None"});
            this.comboBoxPriceSearch.Location = new System.Drawing.Point(118, 189);
            this.comboBoxPriceSearch.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxPriceSearch.Name = "comboBoxPriceSearch";
            this.comboBoxPriceSearch.Size = new System.Drawing.Size(101, 21);
            this.comboBoxPriceSearch.TabIndex = 58;
            // 
            // buttonSearchPrice
            // 
            this.buttonSearchPrice.Location = new System.Drawing.Point(13, 215);
            this.buttonSearchPrice.Name = "buttonSearchPrice";
            this.buttonSearchPrice.Size = new System.Drawing.Size(100, 23);
            this.buttonSearchPrice.TabIndex = 57;
            this.buttonSearchPrice.Text = "Search Price";
            this.buttonSearchPrice.UseVisualStyleBackColor = true;
            this.buttonSearchPrice.Click += new System.EventHandler(this.buttonSearchPrice_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(10, 170);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 13);
            this.label13.TabIndex = 54;
            this.label13.Text = "Total Price search:";
            // 
            // textBoxPrice
            // 
            this.textBoxPrice.Location = new System.Drawing.Point(13, 189);
            this.textBoxPrice.Name = "textBoxPrice";
            this.textBoxPrice.Size = new System.Drawing.Size(100, 20);
            this.textBoxPrice.TabIndex = 53;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(282, 205);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 13);
            this.label12.TabIndex = 52;
            this.label12.Text = "Select Column:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "PeopleID",
            "CustomerName",
            "EmployeeName",
            "OrderID",
            "Purchased",
            "None"});
            this.comboBox1.Location = new System.Drawing.Point(378, 202);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(89, 21);
            this.comboBox1.TabIndex = 49;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(287, 175);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Search Element:";
            // 
            // textBoxQuerySearch
            // 
            this.textBoxQuerySearch.Location = new System.Drawing.Point(378, 172);
            this.textBoxQuerySearch.Name = "textBoxQuerySearch";
            this.textBoxQuerySearch.Size = new System.Drawing.Size(89, 20);
            this.textBoxQuerySearch.TabIndex = 5;
            // 
            // buttonSearchCustomerOrder
            // 
            this.buttonSearchCustomerOrder.Location = new System.Drawing.Point(285, 237);
            this.buttonSearchCustomerOrder.Name = "buttonSearchCustomerOrder";
            this.buttonSearchCustomerOrder.Size = new System.Drawing.Size(182, 23);
            this.buttonSearchCustomerOrder.TabIndex = 1;
            this.buttonSearchCustomerOrder.Text = "Search Customer Order";
            this.buttonSearchCustomerOrder.UseVisualStyleBackColor = true;
            this.buttonSearchCustomerOrder.Click += new System.EventHandler(this.buttonSearchCustomerOrder_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(13, 13);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(454, 150);
            this.dataGridView2.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.tabPage2.Controls.Add(this.toolStripContainer1);
            this.tabPage2.Controls.Add(this.peopleidTextBox);
            this.tabPage2.Controls.Add(this.first_NameTextBox);
            this.tabPage2.Controls.Add(this.last_NameTextBox);
            this.tabPage2.Controls.Add(this.addressTextBox);
            this.tabPage2.Controls.Add(this.cityTextBox);
            this.tabPage2.Controls.Add(this.stateTextBox);
            this.tabPage2.Controls.Add(this.zipTextBox);
            this.tabPage2.Controls.Add(this.phoneTextBox);
            this.tabPage2.Controls.Add(this.emailTextBox);
            this.tabPage2.Controls.Add(this.peopleTypeTextBox);
            this.tabPage2.Controls.Add(this.textBoxCSearch);
            this.tabPage2.Controls.Add(peopleidLabel);
            this.tabPage2.Controls.Add(first_NameLabel);
            this.tabPage2.Controls.Add(last_NameLabel);
            this.tabPage2.Controls.Add(addressLabel);
            this.tabPage2.Controls.Add(cityLabel);
            this.tabPage2.Controls.Add(stateLabel);
            this.tabPage2.Controls.Add(zipLabel);
            this.tabPage2.Controls.Add(phoneLabel);
            this.tabPage2.Controls.Add(emailLabel);
            this.tabPage2.Controls.Add(peopleTypeLabel);
            this.tabPage2.Controls.Add(firstEncounterLabel);
            this.tabPage2.Controls.Add(this.firstEncounterDateTimePicker);
            this.tabPage2.Controls.Add(dobLabel);
            this.tabPage2.Controls.Add(this.dobDateTimePicker);
            this.tabPage2.Controls.Add(this.customerInformationDataGridView);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.buttonCSearch);
            this.tabPage2.Controls.Add(this.comboBoxCSearch);
            this.tabPage2.Controls.Add(this.buttonCReset);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage2.Size = new System.Drawing.Size(476, 342);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Customer Data";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // toolStripContainer1
            // 
            // 
            // toolStripContainer1.ContentPanel
            // 
            this.toolStripContainer1.ContentPanel.Margin = new System.Windows.Forms.Padding(2);
            this.toolStripContainer1.ContentPanel.Size = new System.Drawing.Size(417, 2);
            this.toolStripContainer1.Location = new System.Drawing.Point(15, 4);
            this.toolStripContainer1.Margin = new System.Windows.Forms.Padding(2);
            this.toolStripContainer1.Name = "toolStripContainer1";
            this.toolStripContainer1.Size = new System.Drawing.Size(417, 33);
            this.toolStripContainer1.TabIndex = 5;
            this.toolStripContainer1.Text = "toolStripContainer1";
            // 
            // toolStripContainer1.TopToolStripPanel
            // 
            this.toolStripContainer1.TopToolStripPanel.Controls.Add(this.customerInformationBindingNavigator);
            // 
            // customerInformationBindingNavigator
            // 
            this.customerInformationBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.customerInformationBindingNavigator.BindingSource = this.customerInformationBindingSource;
            this.customerInformationBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.customerInformationBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.customerInformationBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.customerInformationBindingNavigator.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.customerInformationBindingNavigator.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.customerInformationBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.customerInformationBindingNavigatorSaveItem});
            this.customerInformationBindingNavigator.Location = new System.Drawing.Point(3, 0);
            this.customerInformationBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.customerInformationBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.customerInformationBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.customerInformationBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.customerInformationBindingNavigator.Name = "customerInformationBindingNavigator";
            this.customerInformationBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.customerInformationBindingNavigator.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.customerInformationBindingNavigator.Size = new System.Drawing.Size(304, 31);
            this.customerInformationBindingNavigator.TabIndex = 4;
            this.customerInformationBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(28, 28);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 28);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(28, 28);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(28, 28);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(28, 28);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 31);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 20);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(28, 28);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(28, 28);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // customerInformationBindingNavigatorSaveItem
            // 
            this.customerInformationBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.customerInformationBindingNavigatorSaveItem.Enabled = false;
            this.customerInformationBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("customerInformationBindingNavigatorSaveItem.Image")));
            this.customerInformationBindingNavigatorSaveItem.Name = "customerInformationBindingNavigatorSaveItem";
            this.customerInformationBindingNavigatorSaveItem.Size = new System.Drawing.Size(28, 28);
            this.customerInformationBindingNavigatorSaveItem.Text = "Save Data";
            // 
            // peopleidTextBox
            // 
            this.peopleidTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerInformationBindingSource, "peopleid", true));
            this.peopleidTextBox.Location = new System.Drawing.Point(94, 44);
            this.peopleidTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.peopleidTextBox.Name = "peopleidTextBox";
            this.peopleidTextBox.Size = new System.Drawing.Size(79, 20);
            this.peopleidTextBox.TabIndex = 61;
            // 
            // first_NameTextBox
            // 
            this.first_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerInformationBindingSource, "First Name", true));
            this.first_NameTextBox.Location = new System.Drawing.Point(94, 69);
            this.first_NameTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.first_NameTextBox.Name = "first_NameTextBox";
            this.first_NameTextBox.Size = new System.Drawing.Size(79, 20);
            this.first_NameTextBox.TabIndex = 63;
            // 
            // last_NameTextBox
            // 
            this.last_NameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerInformationBindingSource, "Last Name", true));
            this.last_NameTextBox.Location = new System.Drawing.Point(93, 93);
            this.last_NameTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.last_NameTextBox.Name = "last_NameTextBox";
            this.last_NameTextBox.Size = new System.Drawing.Size(79, 20);
            this.last_NameTextBox.TabIndex = 65;
            // 
            // addressTextBox
            // 
            this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerInformationBindingSource, "Address", true));
            this.addressTextBox.Location = new System.Drawing.Point(93, 116);
            this.addressTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(79, 20);
            this.addressTextBox.TabIndex = 67;
            // 
            // cityTextBox
            // 
            this.cityTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerInformationBindingSource, "City", true));
            this.cityTextBox.Location = new System.Drawing.Point(93, 140);
            this.cityTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.cityTextBox.Name = "cityTextBox";
            this.cityTextBox.Size = new System.Drawing.Size(79, 20);
            this.cityTextBox.TabIndex = 69;
            // 
            // stateTextBox
            // 
            this.stateTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerInformationBindingSource, "State", true));
            this.stateTextBox.Location = new System.Drawing.Point(93, 164);
            this.stateTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.stateTextBox.Name = "stateTextBox";
            this.stateTextBox.Size = new System.Drawing.Size(79, 20);
            this.stateTextBox.TabIndex = 71;
            // 
            // zipTextBox
            // 
            this.zipTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerInformationBindingSource, "Zip", true));
            this.zipTextBox.Location = new System.Drawing.Point(93, 188);
            this.zipTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.zipTextBox.Name = "zipTextBox";
            this.zipTextBox.Size = new System.Drawing.Size(79, 20);
            this.zipTextBox.TabIndex = 73;
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerInformationBindingSource, "Phone", true));
            this.phoneTextBox.Location = new System.Drawing.Point(94, 214);
            this.phoneTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(79, 20);
            this.phoneTextBox.TabIndex = 75;
            // 
            // emailTextBox
            // 
            this.emailTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerInformationBindingSource, "Email", true));
            this.emailTextBox.Location = new System.Drawing.Point(93, 238);
            this.emailTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.emailTextBox.Name = "emailTextBox";
            this.emailTextBox.Size = new System.Drawing.Size(79, 20);
            this.emailTextBox.TabIndex = 77;
            // 
            // peopleTypeTextBox
            // 
            this.peopleTypeTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.customerInformationBindingSource, "PeopleType", true));
            this.peopleTypeTextBox.Location = new System.Drawing.Point(94, 265);
            this.peopleTypeTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.peopleTypeTextBox.Name = "peopleTypeTextBox";
            this.peopleTypeTextBox.Size = new System.Drawing.Size(79, 20);
            this.peopleTypeTextBox.TabIndex = 79;
            // 
            // textBoxCSearch
            // 
            this.textBoxCSearch.Location = new System.Drawing.Point(219, 271);
            this.textBoxCSearch.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxCSearch.Name = "textBoxCSearch";
            this.textBoxCSearch.Size = new System.Drawing.Size(118, 20);
            this.textBoxCSearch.TabIndex = 49;
            // 
            // firstEncounterDateTimePicker
            // 
            this.firstEncounterDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.customerInformationBindingSource, "FirstEncounter", true));
            this.firstEncounterDateTimePicker.Location = new System.Drawing.Point(94, 290);
            this.firstEncounterDateTimePicker.Margin = new System.Windows.Forms.Padding(2);
            this.firstEncounterDateTimePicker.Name = "firstEncounterDateTimePicker";
            this.firstEncounterDateTimePicker.Size = new System.Drawing.Size(79, 20);
            this.firstEncounterDateTimePicker.TabIndex = 81;
            // 
            // dobDateTimePicker
            // 
            this.dobDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.customerInformationBindingSource, "Dob", true));
            this.dobDateTimePicker.Location = new System.Drawing.Point(94, 316);
            this.dobDateTimePicker.Margin = new System.Windows.Forms.Padding(2);
            this.dobDateTimePicker.Name = "dobDateTimePicker";
            this.dobDateTimePicker.Size = new System.Drawing.Size(79, 20);
            this.dobDateTimePicker.TabIndex = 83;
            // 
            // customerInformationDataGridView
            // 
            this.customerInformationDataGridView.AutoGenerateColumns = false;
            this.customerInformationDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customerInformationDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12});
            this.customerInformationDataGridView.DataSource = this.customerInformationBindingSource;
            this.customerInformationDataGridView.Location = new System.Drawing.Point(219, 44);
            this.customerInformationDataGridView.Margin = new System.Windows.Forms.Padding(2);
            this.customerInformationDataGridView.Name = "customerInformationDataGridView";
            this.customerInformationDataGridView.RowHeadersWidth = 62;
            this.customerInformationDataGridView.RowTemplate.Height = 28;
            this.customerInformationDataGridView.Size = new System.Drawing.Size(240, 170);
            this.customerInformationDataGridView.TabIndex = 60;
            this.customerInformationDataGridView.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.customerInformationDataGridView_CellContentDoubleClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "peopleid";
            this.dataGridViewTextBoxColumn1.HeaderText = "peopleid";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "First Name";
            this.dataGridViewTextBoxColumn2.HeaderText = "First Name";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Last Name";
            this.dataGridViewTextBoxColumn3.HeaderText = "Last Name";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 150;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn4.HeaderText = "Address";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "City";
            this.dataGridViewTextBoxColumn5.HeaderText = "City";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "State";
            this.dataGridViewTextBoxColumn6.HeaderText = "State";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 150;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Zip";
            this.dataGridViewTextBoxColumn7.HeaderText = "Zip";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 150;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Phone";
            this.dataGridViewTextBoxColumn8.HeaderText = "Phone";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 150;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Email";
            this.dataGridViewTextBoxColumn9.HeaderText = "Email";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 150;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "PeopleType";
            this.dataGridViewTextBoxColumn10.HeaderText = "PeopleType";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 150;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "FirstEncounter";
            this.dataGridViewTextBoxColumn11.HeaderText = "FirstEncounter";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Width = 150;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Dob";
            this.dataGridViewTextBoxColumn12.HeaderText = "Dob";
            this.dataGridViewTextBoxColumn12.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.Width = 150;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(216, 248);
            this.label21.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(121, 13);
            this.label21.TabIndex = 52;
            this.label21.Text = "Enter Search Value:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(351, 248);
            this.label22.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(92, 13);
            this.label22.TabIndex = 51;
            this.label22.Text = "Select Column:";
            // 
            // buttonCSearch
            // 
            this.buttonCSearch.Location = new System.Drawing.Point(363, 302);
            this.buttonCSearch.Margin = new System.Windows.Forms.Padding(2);
            this.buttonCSearch.Name = "buttonCSearch";
            this.buttonCSearch.Size = new System.Drawing.Size(80, 27);
            this.buttonCSearch.TabIndex = 50;
            this.buttonCSearch.Text = "Search";
            this.buttonCSearch.UseVisualStyleBackColor = true;
            // 
            // comboBoxCSearch
            // 
            this.comboBoxCSearch.FormattingEnabled = true;
            this.comboBoxCSearch.Items.AddRange(new object[] {
            "PeopleID",
            "First Name",
            "Last Name",
            "Address",
            "City",
            "State",
            "Zip",
            "Phone",
            "Email",
            "People Type"});
            this.comboBoxCSearch.Location = new System.Drawing.Point(354, 270);
            this.comboBoxCSearch.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxCSearch.Name = "comboBoxCSearch";
            this.comboBoxCSearch.Size = new System.Drawing.Size(89, 21);
            this.comboBoxCSearch.TabIndex = 48;
            // 
            // buttonCReset
            // 
            this.buttonCReset.Location = new System.Drawing.Point(219, 218);
            this.buttonCReset.Margin = new System.Windows.Forms.Padding(2);
            this.buttonCReset.Name = "buttonCReset";
            this.buttonCReset.Size = new System.Drawing.Size(75, 28);
            this.buttonCReset.TabIndex = 47;
            this.buttonCReset.Text = "Reset";
            this.buttonCReset.UseVisualStyleBackColor = true;
            this.buttonCReset.Click += new System.EventHandler(this.buttonCReset_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.BackColor = System.Drawing.Color.RosyBrown;
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.buttonSearch);
            this.tabPage1.Controls.Add(this.textBoxSearch);
            this.tabPage1.Controls.Add(this.textBoxEmail);
            this.tabPage1.Controls.Add(this.textBoxPeopleID);
            this.tabPage1.Controls.Add(this.textBoxLastName);
            this.tabPage1.Controls.Add(this.textBoxAddress);
            this.tabPage1.Controls.Add(this.textBoxPhone);
            this.tabPage1.Controls.Add(this.textBoxZip);
            this.tabPage1.Controls.Add(this.textBoxCity);
            this.tabPage1.Controls.Add(this.textBoxFirstName);
            this.tabPage1.Controls.Add(this.comboBoxSearchParameter);
            this.tabPage1.Controls.Add(this.comboBoxPeopleType);
            this.tabPage1.Controls.Add(this.comboBoxStates);
            this.tabPage1.Controls.Add(this.buttonClearText);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.dataGridView1);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(2);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(2);
            this.tabPage1.Size = new System.Drawing.Size(476, 342);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Person Data";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(219, 190);
            this.label14.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 13);
            this.label14.TabIndex = 33;
            this.label14.Text = "Enter Search Value:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(358, 190);
            this.label15.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(92, 13);
            this.label15.TabIndex = 32;
            this.label15.Text = "Select Column:";
            // 
            // buttonSearch
            // 
            this.buttonSearch.Location = new System.Drawing.Point(390, 233);
            this.buttonSearch.Margin = new System.Windows.Forms.Padding(2);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(60, 29);
            this.buttonSearch.TabIndex = 31;
            this.buttonSearch.Text = "Search";
            this.buttonSearch.UseVisualStyleBackColor = true;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click_1);
            // 
            // textBoxSearch
            // 
            this.textBoxSearch.Location = new System.Drawing.Point(222, 208);
            this.textBoxSearch.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxSearch.Name = "textBoxSearch";
            this.textBoxSearch.Size = new System.Drawing.Size(118, 20);
            this.textBoxSearch.TabIndex = 30;
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(81, 204);
            this.textBoxEmail.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(61, 20);
            this.textBoxEmail.TabIndex = 20;
            // 
            // textBoxPeopleID
            // 
            this.textBoxPeopleID.Location = new System.Drawing.Point(81, 7);
            this.textBoxPeopleID.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPeopleID.Name = "textBoxPeopleID";
            this.textBoxPeopleID.Size = new System.Drawing.Size(61, 20);
            this.textBoxPeopleID.TabIndex = 18;
            // 
            // textBoxLastName
            // 
            this.textBoxLastName.Location = new System.Drawing.Point(81, 56);
            this.textBoxLastName.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxLastName.Name = "textBoxLastName";
            this.textBoxLastName.Size = new System.Drawing.Size(61, 20);
            this.textBoxLastName.TabIndex = 17;
            // 
            // textBoxAddress
            // 
            this.textBoxAddress.Location = new System.Drawing.Point(81, 80);
            this.textBoxAddress.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxAddress.Name = "textBoxAddress";
            this.textBoxAddress.Size = new System.Drawing.Size(61, 20);
            this.textBoxAddress.TabIndex = 16;
            // 
            // textBoxPhone
            // 
            this.textBoxPhone.Location = new System.Drawing.Point(81, 180);
            this.textBoxPhone.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxPhone.Name = "textBoxPhone";
            this.textBoxPhone.Size = new System.Drawing.Size(61, 20);
            this.textBoxPhone.TabIndex = 15;
            // 
            // textBoxZip
            // 
            this.textBoxZip.Location = new System.Drawing.Point(81, 153);
            this.textBoxZip.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxZip.Name = "textBoxZip";
            this.textBoxZip.Size = new System.Drawing.Size(61, 20);
            this.textBoxZip.TabIndex = 14;
            // 
            // textBoxCity
            // 
            this.textBoxCity.Location = new System.Drawing.Point(81, 104);
            this.textBoxCity.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxCity.Name = "textBoxCity";
            this.textBoxCity.Size = new System.Drawing.Size(61, 20);
            this.textBoxCity.TabIndex = 13;
            // 
            // textBoxFirstName
            // 
            this.textBoxFirstName.Location = new System.Drawing.Point(81, 31);
            this.textBoxFirstName.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxFirstName.Name = "textBoxFirstName";
            this.textBoxFirstName.Size = new System.Drawing.Size(61, 20);
            this.textBoxFirstName.TabIndex = 12;
            // 
            // comboBoxSearchParameter
            // 
            this.comboBoxSearchParameter.FormattingEnabled = true;
            this.comboBoxSearchParameter.Items.AddRange(new object[] {
            "PeopleID",
            "First Name",
            "Last Name",
            "Address",
            "City",
            "State",
            "Zip",
            "Phone",
            "Email",
            "People Type"});
            this.comboBoxSearchParameter.Location = new System.Drawing.Point(361, 208);
            this.comboBoxSearchParameter.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSearchParameter.Name = "comboBoxSearchParameter";
            this.comboBoxSearchParameter.Size = new System.Drawing.Size(86, 21);
            this.comboBoxSearchParameter.TabIndex = 29;
            // 
            // comboBoxPeopleType
            // 
            this.comboBoxPeopleType.FormattingEnabled = true;
            this.comboBoxPeopleType.Items.AddRange(new object[] {
            "Customer",
            "Employee",
            "Vendor"});
            this.comboBoxPeopleType.Location = new System.Drawing.Point(81, 232);
            this.comboBoxPeopleType.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxPeopleType.Name = "comboBoxPeopleType";
            this.comboBoxPeopleType.Size = new System.Drawing.Size(61, 21);
            this.comboBoxPeopleType.TabIndex = 28;
            // 
            // comboBoxStates
            // 
            this.comboBoxStates.FormattingEnabled = true;
            this.comboBoxStates.Items.AddRange(new object[] {
            "AL",
            "AK",
            "AZ",
            "AR",
            "CA",
            "CO",
            "CT",
            "DE",
            "FL",
            "GA",
            "HI",
            "ID",
            "IL",
            "IN",
            "IA",
            "KS",
            "KY",
            "LA",
            "ME",
            "MD",
            "MA",
            "MI",
            "MN",
            "MS",
            "MO",
            "MT",
            "NE",
            "NV",
            "NH",
            "NJ",
            "NM",
            "NY",
            "NC",
            "ND",
            "OH",
            "OK",
            "OR",
            "PA",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "UT",
            "VT",
            "VA",
            "WA",
            "WV",
            "WI",
            "WY"});
            this.comboBoxStates.Location = new System.Drawing.Point(81, 128);
            this.comboBoxStates.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxStates.Name = "comboBoxStates";
            this.comboBoxStates.Size = new System.Drawing.Size(61, 21);
            this.comboBoxStates.TabIndex = 27;
            // 
            // buttonClearText
            // 
            this.buttonClearText.Location = new System.Drawing.Point(197, 153);
            this.buttonClearText.Margin = new System.Windows.Forms.Padding(2);
            this.buttonClearText.Name = "buttonClearText";
            this.buttonClearText.Size = new System.Drawing.Size(60, 31);
            this.buttonClearText.TabIndex = 26;
            this.buttonClearText.Text = "Reset";
            this.buttonClearText.UseVisualStyleBackColor = true;
            this.buttonClearText.Click += new System.EventHandler(this.buttonClearText_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(261, 153);
            this.button3.Margin = new System.Windows.Forms.Padding(2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(60, 31);
            this.button3.TabIndex = 25;
            this.button3.Text = "Add";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(326, 154);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 31);
            this.button2.TabIndex = 24;
            this.button2.Text = "Update";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(390, 153);
            this.button1.Margin = new System.Windows.Forms.Padding(2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 31);
            this.button1.TabIndex = 23;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 240);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(70, 13);
            this.label10.TabIndex = 21;
            this.label10.Text = "People Type:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(7, 211);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Email:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 159);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "Zip:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(7, 183);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Phone:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 136);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "State:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 110);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(27, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "City:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(197, 7);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(248, 142);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentDoubleClick);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 83);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Address:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 59);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Last Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "PeopleID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 38);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "First Name:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(2, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(484, 368);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.SlateBlue;
            this.tabPage4.Controls.Add(this.buttonReset);
            this.tabPage4.Controls.Add(this.comboBoxSearchColumn);
            this.tabPage4.Controls.Add(this.label17);
            this.tabPage4.Controls.Add(this.comboBoxProductPrice);
            this.tabPage4.Controls.Add(this.label18);
            this.tabPage4.Controls.Add(this.textBoxProductPriceSearch);
            this.tabPage4.Controls.Add(this.label19);
            this.tabPage4.Controls.Add(this.comboBoxProductSearch);
            this.tabPage4.Controls.Add(this.label20);
            this.tabPage4.Controls.Add(this.textBoxSearchProducts);
            this.tabPage4.Controls.Add(this.buttonSearchProducts);
            this.tabPage4.Controls.Add(this.dataGridViewProducts);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(476, 342);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Query Products Sold";
            // 
            // buttonReset
            // 
            this.buttonReset.Location = new System.Drawing.Point(355, 288);
            this.buttonReset.Name = "buttonReset";
            this.buttonReset.Size = new System.Drawing.Size(101, 23);
            this.buttonReset.TabIndex = 72;
            this.buttonReset.Text = "Reset";
            this.buttonReset.UseVisualStyleBackColor = true;
            this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
            // 
            // comboBoxSearchColumn
            // 
            this.comboBoxSearchColumn.FormattingEnabled = true;
            this.comboBoxSearchColumn.Items.AddRange(new object[] {
            "Wholesale Price",
            "Retail Price",
            "Possible Profit",
            "Total Profit",
            "None"});
            this.comboBoxSearchColumn.Location = new System.Drawing.Point(355, 185);
            this.comboBoxSearchColumn.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxSearchColumn.Name = "comboBoxSearchColumn";
            this.comboBoxSearchColumn.Size = new System.Drawing.Size(101, 21);
            this.comboBoxSearchColumn.TabIndex = 71;
            this.comboBoxSearchColumn.Text = "Price Column";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(352, 167);
            this.label17.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(92, 13);
            this.label17.TabIndex = 70;
            this.label17.Text = "Select Column:";
            // 
            // comboBoxProductPrice
            // 
            this.comboBoxProductPrice.FormattingEnabled = true;
            this.comboBoxProductPrice.Items.AddRange(new object[] {
            "More Than: >",
            "Less Than: <",
            "Equal To: ==",
            "None"});
            this.comboBoxProductPrice.Location = new System.Drawing.Point(355, 211);
            this.comboBoxProductPrice.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxProductPrice.Name = "comboBoxProductPrice";
            this.comboBoxProductPrice.Size = new System.Drawing.Size(101, 21);
            this.comboBoxProductPrice.TabIndex = 69;
            this.comboBoxProductPrice.Text = "< / > / ==";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(219, 167);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 13);
            this.label18.TabIndex = 67;
            this.label18.Text = "Price Search:";
            // 
            // textBoxProductPriceSearch
            // 
            this.textBoxProductPriceSearch.Location = new System.Drawing.Point(222, 186);
            this.textBoxProductPriceSearch.Name = "textBoxProductPriceSearch";
            this.textBoxProductPriceSearch.Size = new System.Drawing.Size(89, 20);
            this.textBoxProductPriceSearch.TabIndex = 66;
            this.textBoxProductPriceSearch.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(352, 244);
            this.label19.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(92, 13);
            this.label19.TabIndex = 65;
            this.label19.Text = "Select Column:";
            // 
            // comboBoxProductSearch
            // 
            this.comboBoxProductSearch.FormattingEnabled = true;
            this.comboBoxProductSearch.Items.AddRange(new object[] {
            "VendorID",
            "VendorName",
            "VendorContact",
            "VendorEmail",
            "VendorAddress",
            "VendorState",
            "ProductID",
            "WholesalePrice",
            "RetailPrice",
            "ProductName",
            "PossibleProfit",
            "OrderID",
            "EmployeeID",
            "ItemQuantitySold",
            "ProfitMade",
            "None"});
            this.comboBoxProductSearch.Location = new System.Drawing.Point(355, 259);
            this.comboBoxProductSearch.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxProductSearch.Name = "comboBoxProductSearch";
            this.comboBoxProductSearch.Size = new System.Drawing.Size(101, 21);
            this.comboBoxProductSearch.TabIndex = 64;
            this.comboBoxProductSearch.Text = "Search Column";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(219, 244);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(85, 13);
            this.label20.TabIndex = 63;
            this.label20.Text = "Search Element:";
            // 
            // textBoxSearchProducts
            // 
            this.textBoxSearchProducts.Location = new System.Drawing.Point(222, 260);
            this.textBoxSearchProducts.Name = "textBoxSearchProducts";
            this.textBoxSearchProducts.Size = new System.Drawing.Size(89, 20);
            this.textBoxSearchProducts.TabIndex = 62;
            // 
            // buttonSearchProducts
            // 
            this.buttonSearchProducts.Location = new System.Drawing.Point(222, 288);
            this.buttonSearchProducts.Name = "buttonSearchProducts";
            this.buttonSearchProducts.Size = new System.Drawing.Size(89, 23);
            this.buttonSearchProducts.TabIndex = 61;
            this.buttonSearchProducts.Text = "Search Products Sold";
            this.buttonSearchProducts.UseVisualStyleBackColor = true;
            this.buttonSearchProducts.Click += new System.EventHandler(this.buttonSearchProducts_Click);
            // 
            // dataGridViewProducts
            // 
            this.dataGridViewProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProducts.Location = new System.Drawing.Point(13, 14);
            this.dataGridViewProducts.Name = "dataGridViewProducts";
            this.dataGridViewProducts.Size = new System.Drawing.Size(454, 150);
            this.dataGridViewProducts.TabIndex = 60;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(485, 368);
            this.Controls.Add(this.tabControl1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "Barbershop Linq Database";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customerInformationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.testDataSet)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.toolStripContainer1.TopToolStripPanel.ResumeLayout(false);
            this.toolStripContainer1.TopToolStripPanel.PerformLayout();
            this.toolStripContainer1.ResumeLayout(false);
            this.toolStripContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerInformationBindingNavigator)).EndInit();
            this.customerInformationBindingNavigator.ResumeLayout(false);
            this.customerInformationBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.customerInformationDataGridView)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProducts)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private testDataSet testDataSet;
        private System.Windows.Forms.BindingSource customerInformationBindingSource;
        private testDataSetTableAdapters.CustomerInformationTableAdapter customerInformationTableAdapter;
        private testDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ToolStripContainer toolStripContainer1;
        private System.Windows.Forms.BindingNavigator customerInformationBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton customerInformationBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox peopleidTextBox;
        private System.Windows.Forms.TextBox first_NameTextBox;
        private System.Windows.Forms.TextBox last_NameTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox cityTextBox;
        private System.Windows.Forms.TextBox stateTextBox;
        private System.Windows.Forms.TextBox zipTextBox;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.TextBox emailTextBox;
        private System.Windows.Forms.TextBox peopleTypeTextBox;
        private System.Windows.Forms.TextBox textBoxCSearch;
        private System.Windows.Forms.DateTimePicker firstEncounterDateTimePicker;
        private System.Windows.Forms.DateTimePicker dobDateTimePicker;
        private System.Windows.Forms.DataGridView customerInformationDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button buttonCSearch;
        private System.Windows.Forms.ComboBox comboBoxCSearch;
        private System.Windows.Forms.Button buttonCReset;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.TextBox textBoxSearch;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxPeopleID;
        private System.Windows.Forms.TextBox textBoxLastName;
        private System.Windows.Forms.TextBox textBoxAddress;
        private System.Windows.Forms.TextBox textBoxPhone;
        private System.Windows.Forms.TextBox textBoxZip;
        private System.Windows.Forms.TextBox textBoxCity;
        private System.Windows.Forms.TextBox textBoxFirstName;
        private System.Windows.Forms.ComboBox comboBoxSearchParameter;
        private System.Windows.Forms.ComboBox comboBoxPeopleType;
        private System.Windows.Forms.ComboBox comboBoxStates;
        private System.Windows.Forms.Button buttonClearText;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBoxQuerySearch;
        private System.Windows.Forms.Button buttonSearchCustomerOrder;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBoxPriceSearch;
        private System.Windows.Forms.Button buttonSearchPrice;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox comboBoxProductPrice;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBoxProductPriceSearch;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBoxProductSearch;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBoxSearchProducts;
        private System.Windows.Forms.Button buttonSearchProducts;
        private System.Windows.Forms.DataGridView dataGridViewProducts;
        private System.Windows.Forms.ComboBox comboBoxSearchColumn;
        private System.Windows.Forms.Button buttonResetCO;
        private System.Windows.Forms.Button buttonReset;
    }
}

