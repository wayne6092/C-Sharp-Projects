﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Query_Data_Source_Linq
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataProductsClassesDataContext db = new DataProductsClassesDataContext();

            var results = from product in db.Products
                          select product;

            productDataGridView.DataSource = results;

            //Update
            Product prod = db.Products.FirstOrDefault(item => 
                                    item.Product_Number == "10-04");

            if(prod != null )
            {
                prod.Price = 99.99m;
                db.SubmitChanges();
            }

            //Update
            var resultsTwo = from prods in db.Products
                             where prods.Product_Number.Contains("10-")
                             select prods;

            foreach(Product p in resultsTwo )
            {
                p.Units_On_Hand = 0;
            }
            db.SubmitChanges();

            //Insert
            Product prodsTwo = new Product();
            prodsTwo.Product_Number = "40-01";
            prodsTwo.Description = "Hiking Boots";
            prodsTwo.Units_On_Hand = 10;
            prodsTwo.Price = 299m;

            db.Products.InsertOnSubmit(prodsTwo);
            db.SubmitChanges();

            //Delete 
            Product prodds = db.Products.FirstOrDefault(item =>
                                    item.Product_Number == "10-04");
            if( prodds != null )
            {
                db.Products.DeleteOnSubmit(prodds); 
                db.SubmitChanges();
            }

        }
    }
}
