﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Team_Players_Linq
{
    public partial class Form1 : Form
    {
        //Baseball team members
        List<string> baseball = new List<string>()
        {
            "Jodi", "Carmen", "Alicia", "Aida"
        };

        //Basketball team members
        List<string> basketball = new List<string>()
        {
            "Eva", "Carmen", "Alicia", "Sarah"
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Get baseball players sorted in ascending order
            var baseballPlayers = baseball.OrderBy(str => str);

            //Get basketball players sorted in ascending order
            var basketballPlayers = basketball.OrderBy(str => str);

            //Display baseball players
            foreach(string player in baseballPlayers)
            {
                listBoxBaseball.Items.Add(player);
            }

            //Display basketball players
            foreach(string player in basketballPlayers)
            {
                listBoxBasketball.Items.Add(player);
            }
        }

        private void buttonBothIntersection_Click(object sender, EventArgs e)
        {
            //Get the elements that are in both lists, sorted
            var result = baseball.Intersect(basketball)
                .OrderBy(str => str);

            //clear the results Listbox
            listBoxResults.Items.Clear();

            //Display results
            foreach(string player in result)
            {
                listBoxResults.Items.Add(player);
            }
        }

        private void buttonDiff1_Click(object sender, EventArgs e)
        {
            //Get the elements that are in the baseball list but not
            //in the basketball list, sorted
            var result = baseball.Except(basketball)
                .OrderBy(str => str);

            //clear the results listbox
            listBoxResults.Items.Clear();

            //Display the results 
            foreach(string player in result)
            {
                listBoxResults.Items.Add(player);
            }
        }

        private void buttonDiff2_Click(object sender, EventArgs e)
        {
            //Get the elements that are in the basketball list but not in
            //the baseball list, sorted
            var result = basketball.Except(baseball)
                .OrderBy(str => str);

            //Clear the results listbox
            listBoxResults.Items.Clear();

            //Display results
            foreach(string player in result)
            {
                listBoxResults.Items.Add(player);
            }
        }

        private void buttonUnion_Click(object sender, EventArgs e)
        {
            //Get elements that are in either list, sorted
            var result = baseball.Union(basketball)
                .OrderBy(str => str);
            listBoxResults.Items.Clear();
            foreach(string player in result)
            {
                listBoxResults.Items.Add(player);
            }


        }
    }
}
