﻿namespace Team_Players_Linq
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonBothIntersection = new System.Windows.Forms.Button();
            this.buttonUnion = new System.Windows.Forms.Button();
            this.buttonDiff1 = new System.Windows.Forms.Button();
            this.buttonDiff2 = new System.Windows.Forms.Button();
            this.listBoxBaseball = new System.Windows.Forms.ListBox();
            this.listBoxBasketball = new System.Windows.Forms.ListBox();
            this.listBoxResults = new System.Windows.Forms.ListBox();
            this.buttonClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonBothIntersection
            // 
            this.buttonBothIntersection.Location = new System.Drawing.Point(198, 66);
            this.buttonBothIntersection.Name = "buttonBothIntersection";
            this.buttonBothIntersection.Size = new System.Drawing.Size(138, 52);
            this.buttonBothIntersection.TabIndex = 0;
            this.buttonBothIntersection.Text = "Both Baseball and Basketball";
            this.buttonBothIntersection.UseVisualStyleBackColor = true;
            this.buttonBothIntersection.Click += new System.EventHandler(this.buttonBothIntersection_Click);
            // 
            // buttonUnion
            // 
            this.buttonUnion.Location = new System.Drawing.Point(342, 66);
            this.buttonUnion.Name = "buttonUnion";
            this.buttonUnion.Size = new System.Drawing.Size(134, 52);
            this.buttonUnion.TabIndex = 1;
            this.buttonUnion.Text = "Either Baseball Or Basketball";
            this.buttonUnion.UseVisualStyleBackColor = true;
            this.buttonUnion.Click += new System.EventHandler(this.buttonUnion_Click);
            // 
            // buttonDiff1
            // 
            this.buttonDiff1.Location = new System.Drawing.Point(197, 124);
            this.buttonDiff1.Name = "buttonDiff1";
            this.buttonDiff1.Size = new System.Drawing.Size(139, 55);
            this.buttonDiff1.TabIndex = 2;
            this.buttonDiff1.Text = "Baseball But Not Basketball";
            this.buttonDiff1.UseVisualStyleBackColor = true;
            this.buttonDiff1.Click += new System.EventHandler(this.buttonDiff1_Click);
            // 
            // buttonDiff2
            // 
            this.buttonDiff2.Location = new System.Drawing.Point(342, 124);
            this.buttonDiff2.Name = "buttonDiff2";
            this.buttonDiff2.Size = new System.Drawing.Size(134, 55);
            this.buttonDiff2.TabIndex = 3;
            this.buttonDiff2.Text = "Basketball But Not Baseball";
            this.buttonDiff2.UseVisualStyleBackColor = true;
            this.buttonDiff2.Click += new System.EventHandler(this.buttonDiff2_Click);
            // 
            // listBoxBaseball
            // 
            this.listBoxBaseball.FormattingEnabled = true;
            this.listBoxBaseball.ItemHeight = 20;
            this.listBoxBaseball.Location = new System.Drawing.Point(12, 36);
            this.listBoxBaseball.Name = "listBoxBaseball";
            this.listBoxBaseball.Size = new System.Drawing.Size(179, 164);
            this.listBoxBaseball.TabIndex = 4;
            // 
            // listBoxBasketball
            // 
            this.listBoxBasketball.FormattingEnabled = true;
            this.listBoxBasketball.ItemHeight = 20;
            this.listBoxBasketball.Location = new System.Drawing.Point(482, 36);
            this.listBoxBasketball.Name = "listBoxBasketball";
            this.listBoxBasketball.Size = new System.Drawing.Size(180, 164);
            this.listBoxBasketball.TabIndex = 5;
            // 
            // listBoxResults
            // 
            this.listBoxResults.FormattingEnabled = true;
            this.listBoxResults.ItemHeight = 20;
            this.listBoxResults.Location = new System.Drawing.Point(244, 226);
            this.listBoxResults.Name = "listBoxResults";
            this.listBoxResults.Size = new System.Drawing.Size(179, 164);
            this.listBoxResults.TabIndex = 6;
            // 
            // buttonClose
            // 
            this.buttonClose.Location = new System.Drawing.Point(288, 396);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(89, 34);
            this.buttonClose.TabIndex = 7;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 20);
            this.label1.TabIndex = 8;
            this.label1.Text = "Baseball Team";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(502, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 20);
            this.label2.TabIndex = 9;
            this.label2.Text = "Basketball Team";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(297, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "Results";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 505);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.listBoxResults);
            this.Controls.Add(this.listBoxBasketball);
            this.Controls.Add(this.listBoxBaseball);
            this.Controls.Add(this.buttonDiff2);
            this.Controls.Add(this.buttonDiff1);
            this.Controls.Add(this.buttonUnion);
            this.Controls.Add(this.buttonBothIntersection);
            this.Name = "Form1";
            this.Text = "Team Players Linq";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonBothIntersection;
        private System.Windows.Forms.Button buttonUnion;
        private System.Windows.Forms.Button buttonDiff1;
        private System.Windows.Forms.Button buttonDiff2;
        private System.Windows.Forms.ListBox listBoxBaseball;
        private System.Windows.Forms.ListBox listBoxBasketball;
        private System.Windows.Forms.ListBox listBoxResults;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}

