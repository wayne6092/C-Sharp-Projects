﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Student_Roster_Linq_app
{
    public partial class Form1 : Form
    {
        List<Student> students = new List<Student>()
        {
            new Student("Adams", "Susan"),
            new Student("Adams", "James"),
            new Student("Watson", "Earl"),
            new Student("Lee", "Tina"),
            new Student("Brooks", "Gary"),
            new Student("Brooks", "Lisa"),
            new Student("Campbell", "Patrick"),
            new Student("Gonzalez", "Annie"),
            new Student("Anderson", "Ashley"),
            new Student("Williams", "Wayne")
        };

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonDisplay_Click(object sender, EventArgs e)
        {
            //Get all Student objects in the list ordered by last name
            var results = from student in students
                          orderby student.LastName
                          select student;

            //OR USE Where method
            var resultsTwo = results.Where
                (item => item.LastName == textBoxSearch.Text);

            //OR USE Orderby method
            var resultsThree = resultsTwo.OrderBy(item => item.LastName);

            //OR USE OrderbyDescending
            var resultsFour = students.OrderByDescending(item => item.LastName); 

            //OR USE both methods together
            var resultsFive = students.Where(item => item.LastName == textBoxSearch.Text)
                                      .OrderBy(item => item.LastName);

            //Select method
            var selectResults = students.Where(item => item.FullName.Contains("ay"))
                                        .OrderBy(item => item.FullName)
                                        .Select(item => item.FullName.ToUpper());

            //Display the results in the ListBox
            foreach (Student s in resultsThree)
            {
                listBoxStudent.Items.Add(s.FullName);
            }

            //Quantifier methods
            //Any | All | Contains | Count | Max | Min | Sum
            //All -> Returns true if all elements in collection match condition
            //collection.All(FuncDelegate)

            //Any -> Returns true is any elements match condition
            //collection.Any(FuncDelegate)

            //Contains -> Returns true if collection contains particular element
            //collection.Contains(FuncDelegate)

            //Average -> Returns average of collection of numeric values
            //collection.Any() -> returns average from collection
            //collection.Average(FuncDelegate) -> returns average from FuncDelegate

            //Count -> Count # of elements in collection and/or match condition
            //collection.Count() -> returns # of elements in collection
            //collection.Count(FuncDelegate) -> returns # of elements from FuncDelegate

            //Max -> Returns largest value from collection/delegate
            //collection.Max() -> returns largest number from collection
            //collection.Max(FuncDelegate) -> returns largest number from FuncDelegate

            //Min -> Returns smallest value from collection/delegate
            //collection.Min() -> returns smallest number from collection
            //collection.Min(FuncDelegate) -> returns smallest number from FuncDelegate

            //Sum -> Returns the sum of elements in collection
            //collection.Sum() -> Returns sum from collection
            //collection.Sum(FuncDelegate) -> Returns sum from FuncDelegate

            //Demonstration:
            int[] numbers = { 1, 2, 3, 4, 5 };
            MessageBox.Show("Average: " + numbers.Average());
            MessageBox.Show("Count: " + numbers.Count());
            MessageBox.Show("Max: " + numbers.Max());
            MessageBox.Show("Min: " + numbers.Min());
            MessageBox.Show("Sum: " + numbers.Sum());

            //Element methods
            //ElementAt | ElementAtOrDefault | First | FirstORDefault
            //Last | LastOrDefault | Single | SingleOrDefault

            //ElementAt: Returns element at specific position in collection
            //collection.ElementAt(index)

            //ElementAtOrDefault: Returns element at a specific position in collection
            //or if pos invalid -> returns default value
            //collection.ElementAtOrDefault(index)

            //First: Returns first element of a collection and/or matches condition
            //collection.First() -> returns first element from collection
            //collection.First(FuncDelegate) -> returns first element from FuncDelegate

            //FirstOrDefault: Returns first element in collection/condition and
            //returns defualt if collection empty/no elements match condition
            //collection.FirstOrDefault()
            //collection.FirstOrDefault(FuncDelegate)

            //LastOrDefault: Returns last element in collection/condition and
            //if collection empty/no elements match condition -> returns default value
            //collection.LastOrDefault()
            //collection.LastOrDefault(FuncDelegate)

            //Single: Returns single element in collection/condition
            //collection.Single()
            //collection.Single(FuncDelegate)
            //If collection is empty/has more than one element -> death
            //If condition is false for all elements or condition returns
            //true for more than one element -> death

            //SingleOrDefault: Returns single element in collection/condition and
            //returns default value when noe element matches condition
            //If more than one element returns true -> exception thrown
            //collection.SingleOrDefault()
            //collection.SingleOrDefault(FuncDelegate)

            //GENERATION METHODS -> Generates a new collection of values
            //DefaultIfEmpty | Enumerable.Empty\Range\Repeat

            //DefaultIfEmpty -> Returns elements as they currently exist,
            //unless collection is empty. If empty -> method returns one 
            //default value

            //collection.DefaultIfEmpty() -> If collection contains one or more elements
            //the method returns a copy of the collection | if empty, returns one element
            //set to default value for element data type (0/null)

            //collection.DefaultIfEmpty(defaultValue) -> If collection has one or more elements
            //method returns copy of collection | if empty, returns collection
            //containing one element set to defaultValue

            //Enumerable.Empty -> Returns an empty IEnumerable<T> collection of 
            //a specified data type
            //Enumerable.Empty<T>() -> T is the desired data type, and
            //returns an empty IEnumerable<T> collection 

            //Enumerable.Range -> Returns an IEnumerable<int> collection
            //containing a specified number of sequential integers that start 
            //at a specific value
            //Enumerable.Range(start, size) -> start is the start value of sequence
            //size is the # of elements to generate. Method returns IEnumerable<int> collection

            //Enumerable.Repeat -> Returns cllection of specified data type and size,
            //containing one value that is repeated for each element
            //Enumerable.Repeat<T> (value, size) -> T is desired data type, value
            //is the value to repeat and size is the # of elements to generate | Method
            //returns IEnumerable<T> collection

            //Demonstration: 
            //Create an empty int collection
            var numbersEmpty = Enumerable.Empty<int>();

            //Create another empty int collection
            var nums = numbersEmpty.DefaultIfEmpty();

            //Create an int collection with 1 element
            //Set value to 99
            var defaultNums = numbersEmpty.DefaultIfEmpty(99);

            //Demonstrate Enumerable.Range method
            //Collection will have values: 100, 101, 102, 103, and 104
            var numbersRange = Enumerable.Range(100, 5);

            //Demonstrate Enumerable.Repeat | values = 10 elements of 99's
            var numbersRepeat = Enumerable.Repeat<int>(99, 10);

            //SET METHODS | works with: Prim. data types & collections
            //Method that performs a math set operation on two collections
            //of values | Distinct works with only one collection
            //Distinct | Except | Intersect | Union

            //Distinct -> Returns a copy of a collection with duplicates removed
            //collection.Distinct()

            //Except -> Returns a collection that contains the elements of first
            //collection that are not in the second collection
            //collection1.Except(collection2)

            //Intersect -> Returns a collection that contains only elements that
            // are found in two collections
            //collection1.Intersect(collection2)

            //Union -> Returns a collection that contains all the distinct elements of two sets
            //collection1.Union(collection2)

            //Demonstrations:
            //Distinct
            int[] set1 = { 1, 2, 2, 3, 3, 3, 4, 4, 4, 4 };
            var distinctResult = set1.Distinct();

            //Except
            int[] sets1 = { 1, 2, 3, 4 };
            int[] sets2 = { 3, 4, 5, 6 };
            var exceptResult = sets1.Except(sets2);

            //Intersect
            var intersectResult = sets1.Union(sets2);

            //PARTITIONING METHODS
            //Divides collectino into two sections and returns one of
            //the sections
            //Skip | SkipWhile | Take | TakeWhile | 

            //Skip -> Skips specified number of elements, starts at first
            //element in collection. Remaining elements returned
            //collection.Skip(count)

            //SkipWhile -> Skips elements, starts at first element that matches
            //condition. Returns remaining elements 
            //collection.SkipWhile(FuncDelegate) -> element passed to FuncDelegate
            //if returns true -> element is skipped, if returns true, method stops and
            //returns remainding elements in collection

            //Take -> Returns specified number of elements from collection,
            //starts at first element
            //collection.Take(count)

            //TakeWhile -> Returns elements, starts at first element that matches condition
            //collection.TakeWhile(FuncDelegate) -> elemetn passed to FuncDelegate
            //returns IEnumerable<T> collection that contains elements from start
            //of collection up to the first element that causes FuncDelegate to return false

            //Demonstration:
            //Skip
            var skipResult = set1.Skip(2); //->
            //Converts int[] set1 = { 1, 2, 2, 3, 3, 3, 4, 4, 4, 4 } to
            //int[] set1 = { 2, 3, 3, 3, 4, 4, 4, 4 } - Removes first two elements

            //SkipWhile
            //Skips items less than (3)
            var skipWhileResult = set1.SkipWhile(item => item < 3);

            //Take
            //Start: set1 = { 1, 2, 2, 3, 3, 3, 4, 4, 4, 4 };
            //Result: takeResult = {1, 2};
            var takeResult = set1.Take(2);

            //TakeWhile
            //Start: set1 = { 1, 2, 2, 3, 3, 3, 4, 4, 4, 4 };
            //Return: set1 = { 1, 2, 2, 3, 3, 3};
            var takeWhileResult = set1.TakeWhile(item => item < 4);

            //Miscellaneous Methods | Works with prim. data types & collections
            //Concat | SequenceEqual

            //Concat -> Returns IEnumerable<T> collection that concatenates
            //two collections together
            //collection1.Concat(collection2)

            //SequenceEqual -> Compares two collections & returns true
            //if they are equal / false otherwise
            //collection1.SequenceEqual(collection2)

            //Demonstration:
            //Concat
            var concatResult = set1.Concat(sets2);
            MessageBox.Show(concatResult.ToString());

            int[] numbers1 = { 1, 2, 3 };
            int[] numbers2 = { 1, 2, 3 };
            int[] numbers3 = { 1, 2, 3 };

            if (numbers1.SequenceEqual(numbers2))
            {
                MessageBox.Show("Numbers1 and numbers2 are the same");
            }

            if (!numbers1.SequenceEqual(numbers3))
            {
                MessageBox.Show("numbers1 and numbers3 are NOT the same");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Get all the student objects with the specified last name
            //ordered by first name
            var results = from student in students
                          where student.LastName == textBoxSearch.Text
                          orderby student.FirstName
                          select student;

            listBoxStudent.Items.Clear();

            foreach(Student s in results)
            {
                listBoxStudent.Items.Add(s.FullName);
            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
